#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json
import tornado
from mimetypes import guess_type

from notebook.base.handlers import APIHandler

import informatica.infacore.internal.logger as logger
from informatica.infacore.internal.utils import list_functions

_logger = logger.get_logger(__name__)

class InfacoreDQFunctionsRouteHandler(APIHandler):

    @tornado.web.authenticated
    def get(self):
        try:
            functions = list_functions()
            self.finish(json.dumps(functions))
        except Exception as e:
            _logger.error('Could not get DQ function details from SDK:')
            _logger.exception(e)
            self.finish(json.dumps({'status': 503, 'message':'unable to DQ function details from SDK'}))