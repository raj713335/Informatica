#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json

from notebook.base.handlers import APIHandler

import tornado
from informatica.infacore import session
from informatica.infacore.internal.exceptions import InfacoreSessionError, InfacoreClientError
import informatica.infacore.internal.logger as logger
_logger = logger.get_logger(__name__)


class InfacoreLogoutRouteHandler(APIHandler):
    """Handler for /infacore/logout routes.

    Provides methods for handling POST request.
    """
    
    @tornado.web.authenticated
    def post(self):
        try:
            session.logout()
            description = 'logout success'
            status = 200
            _logger.debug("Logout success from SDK")
        except Exception as e:
            status = e.error_code
            description = 'logout failed'
            _logger.error("Logout failed from SDK")
            _logger.exception(e)
        data = {
            'status': status, 
            'data': {
                'description': description
            }
        }
        self.finish(json.dumps(data))