#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json
import tornado
from mimetypes import guess_type

from notebook.base.handlers import APIHandler

import informatica.infacore.internal.logger as logger

_logger = logger.get_logger(__name__)

class InfacoreLogsRouteHandler(APIHandler):

    @tornado.web.authenticated
    def get(self):
        try:
            log_file_path = self._get_log_file_path(_logger)
            content_type, _ = guess_type(log_file_path)
            self.add_header('Content-Type', 'text/plain')
            with open(log_file_path) as source_file:
                self.write(source_file.read())
                self.flush()
        except Exception as e:
            _logger.exception('Could not get log file details from SDK:' + e)
            self.finish(json.dumps({'status': 503, 'message':'unable to get log file details from SDK'}))

    
    @tornado.web.authenticated
    def post(self):
        try:
            # log_file_path = self._get_log_file_path(_logger)
            log_details = self.get_json_body()
            msg = log_details["message"]
            level = log_details["level"]
            msg = "JLE::" + msg
            if level == "info":
                _logger.info(msg=msg)
            elif level == "debug":
                _logger.debug(msg=msg)
            elif level == "error":
                _logger.error(msg=msg)
            self.finish(json.dumps('ok'))
        except Exception as e:
            _logger.error('Could not get log message through SDK')
            _logger.exception(e)
            self.finish(json.dumps({'status': 503, 'message':'unable to log message to log file through SDK'}))

    def _get_log_file_path(self, logger_obj):
        if logger_obj:
            handlers = logger_obj.parent.handlers
            if handlers:
                for one_handler in handlers:
                    if 'baseFilename' in dir(one_handler):
                        return one_handler.baseFilename