#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json
from notebook.base.handlers import APIHandler

import tornado

import informatica.infacore as ic
import informatica.infacore.datasource.datasource as ds
import informatica.infacore.internal.logger as logger
import informatica.infacore.internal.exceptions as ex

_logger = logger.get_logger(__name__)


class InfaCoreUpdateConnectionHandler(APIHandler):
    """Handler for /infacore/updateconnection routes.
    Provides methods for handling POST request for Updating connection details.
    """
    
    @tornado.web.authenticated
    def post(self):
        conn_attrs_payload = self.get_json_body()
        status = 200
        message = "Connection updated successfully"
        try:
            conn_attrs = dict(conn_attrs_payload['connectionAttributes'])
            connector_name = conn_attrs_payload['connectorType']
            ds_obj = ds.get_data_source(connector_name)
            connection_obj = ds_obj.get_connection(conn_attrs_payload['oldConnectionName'])
            connection_obj = connection_obj.edit(conn_attrs_payload['connectionName'],conn_attrs)
        except ex.InfacoreClientError as e:
            status = e.error_code
            message = e.message[e.message.find('{') : len(e.message)]
            _logger.error("Update connection failed from SDK: " + e.message)
            _logger.exception(e)
        except Exception as e:
            status = 503
            message = "Update connection failed from SDK"
            _logger.error("Update connection failed from SDK")
            _logger.exception(e)
        data = {
            'status': status, 
            'data': {
                'connectionId': 'dummyId',
                'message': message
            }
        }
        self.finish(json.dumps(data))
        