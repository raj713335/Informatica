#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json
from notebook.base.handlers import APIHandler

import tornado

import informatica.infacore.datasource.datasource as ds
import informatica.infacore.internal.logger as logger


_logger = logger.get_logger(__name__)


class InfaCoreConnectorsConnectionsHandler(APIHandler):
    """Handler for /infacore/connector/connector_name/connections routes.
    Provides methods for handling GET request for fetching all connections of connector.
    """
 
    @tornado.web.authenticated
    def get(self,connector_name):
        connections = []
        try:
            ds_obj = ds.get_data_source(connector_name)
            connections = ds_obj.list_connections()
            _logger.debug("connections list: " + str(connections))
            self.finish(json.dumps(connections))
        except ValueError as e:
            msg = e.__str__()
            _logger.error("Could not get connections list from SDK")
            _logger.exception(e)
            if "Mandatory compute engine setup not performed" in msg:
                self.finish(json.dumps({'status': 410, 'message':'Agent is not installed'}))
            else:
                self.finish(json.dumps({'status': 401, 'message':'Could not get connections list from SDK'}))
        except Exception as e:
            _logger.exception(e)
            self.finish(json.dumps({'status': 503, 'message':'Could not get connections list from SDK'}))
        

        