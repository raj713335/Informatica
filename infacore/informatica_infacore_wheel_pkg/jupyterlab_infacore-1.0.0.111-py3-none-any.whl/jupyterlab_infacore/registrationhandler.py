#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json

from notebook.base.handlers import APIHandler

import tornado


class InfacoreRegistrationRouteHandler(APIHandler):
    """Handler for /infacore/register routes.

    Provides methods for handling POST request.
    """
    
    @tornado.web.authenticated
    def get(self):
        self.finish(json.dumps({"data": "This is infacore route handler endpoint!"}))

    @tornado.web.authenticated
    def post(self):
        reg_details = self.get_json_body()
        data = {
            'status':403, 
            'data': {
                'sessionId': 'dummtSessionId', 
                'firstName': reg_details['firstName'], 
                'lastName': reg_details['lastName'],
                'description': 'First name invalid'
            }
        }
        self.finish(json.dumps(data))