#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json

from notebook.base.handlers import APIHandler

import tornado
from informatica.infacore import session
from informatica.infacore.internal.exceptions import InfacoreSessionError, InfacoreClientError
import informatica.infacore.internal.logger as logger


_logger = logger.get_logger(__name__)

class InfacoreLoginRouteHandler(APIHandler):
    """Handler for /infacore/login routes.

    Provides methods for handling POST request.
    """
    
    @tornado.web.authenticated
    def get(self):
        self.finish(json.dumps({"data": "This is infacore route handler endpoint!"}))

    @tornado.web.authenticated
    def post(self):
        login_details = self.get_json_body()
        login_dict = {
            "login":{"username": login_details['username'], "password":login_details['password'], "cloud_provider":login_details['cloudProvider'], "region": login_details['region']},
        }

        if 'iicsUrl' in login_details:
            login_dict['login']['env_type'] = 'test'
            login_dict['login']['url'] = login_details['iicsUrl']
        else:
            login_dict['login']['env_type'] = 'prod'
        status = 200
        description = ''
        try:
            session.logout()
            session.setup(config=login_dict)
            description = 'login success'
            _logger.debug("login successful")
        # Error description will be same as SDK exception
        except InfacoreClientError or InfacoreSessionError as e:
            _logger.exception(e)
            status = e.error_code
            message = e.message[e.message.find('{') : len(e.message)]
            description = json.loads(message)["error"]["message"]
            _logger.error("Login failed from SDK: " + description)
        # If exception has error_code and message then error description will be same as SDK otherwise 500
        except Exception as e:
            _logger.exception(e)
            if e.error_code and e.message:
                status = e.error_code
                message = e.message[e.message.find('{') : len(e.message)]
                description = json.loads(message)["error"]["message"]
            else:
                status = '500'
                description = 'Internal server error'
            _logger.error("Login failed from SDK: " + description)
        data = {
            'status': status, 
            'data': {
                'description': description
            }
        }
        self.finish(json.dumps(data))
