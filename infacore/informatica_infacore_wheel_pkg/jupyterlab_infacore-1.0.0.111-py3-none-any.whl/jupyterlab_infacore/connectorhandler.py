#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json
from notebook.base.handlers import APIHandler

import tornado
import informatica.infacore.datasource.datasource as ds
import informatica.infacore.internal.logger as logger
from informatica.infacore.internal.exceptions import InfacoreClientError, InfacoreSessionError

_logger = logger.get_logger(__name__)

class InfaCoreConnectorsHandler(APIHandler):
    """Handler for /infacore/connectors routes.
    Provides methods for handling GET request for fetching connectors.
    """
    @tornado.web.authenticated
    def get(self):
        try:
            data_sources = ds.list_data_sources()
            _logger.debug("Obtained DataSources list: " + str(data_sources))
            self.finish(json.dumps(data_sources))
        except InfacoreSessionError as e:
            _logger.error("Could not get DataSources from SDK")
            _logger.exception(e)
            msg = e.message
            if "code is 401" in msg:
                self.finish(json.dumps({'status': 401, 'message':'unable to get DataSources from SDK'}))
        except ValueError as e:
            _logger.error("Could not get DataSources from SDK")
            _logger.exception(e)
            self.finish(json.dumps({'status': 401, 'message':'unable to get DataSources from SDK'}))
        except Exception as e:
            _logger.error("Could not get DataSources from SDK")
            _logger.exception(e)
            self.finish(json.dumps({'status': 503, 'message':'unable to get DataSources from SDK'}))