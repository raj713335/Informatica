#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#

import json

from notebook.base.handlers import APIHandler

import tornado
import informatica.infacore as ic
import informatica.infacore.internal.logger as logger
import informatica.infacore.internal.exceptions as ex

_logger = logger.get_logger(__name__)

class InfacoreConnectionActionsHandler(APIHandler):
    """Handler for connections/actions route.
    Provides methods for handling request to test the connection of a connector.
    """
    @tornado.web.authenticated
    def put(self):
        conn_payload = self.get_json_body()
        connector_name = conn_payload['connectorType']
        connection_name = conn_payload['connectionName']
        try:
            test_result = ic.get_data_source(connector_name).get_connection(connection_name).test()
            _logger.debug("connection test result: " + test_result)
            self.finish(json.dumps({'status': 200, 'message': {'description': test_result}}))
        except ValueError as e:
            msg = e.__str__()
            _logger.error("Could not test the connection")
            _logger.exception(e)
            if "Mandatory compute engine setup not performed" in msg:
                self.finish(json.dumps({'status': 410, 'message': {'description': 'Agent is not installed'}}))
            else:
                self.finish(json.dumps({'status': 401, 'message': {'description': 'There was an unauthorized error while testing connection'}}))
        except ex.InfacoreClientError as e:
            _logger.exception(e)
            self.finish(json.dumps({'status': e.error_code, 'message': e.message[e.message.find('{') : len(e.message)]}))
        except Exception as e:
            _logger.exception(e)
            self.finish(json.dumps({'status': 500, 'message': {'description': 'Could not test the connection'}}))