#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import os

from tornado.web import StaticFileHandler

from notebook.utils import url_path_join
from jupyterlab_infacore.loginhandler import InfacoreLoginRouteHandler
from jupyterlab_infacore.registrationhandler import InfacoreRegistrationRouteHandler
from jupyterlab_infacore.connectorhandler import InfaCoreConnectorsHandler
from jupyterlab_infacore.connectorattributeshandler import InfacoreConnectorAttributesHandler
from jupyterlab_infacore.connectionshandler import InfaCoreConnectorsConnectionsHandler
from jupyterlab_infacore.newconnectionhandler import InfacoreNewConnectionRouteHandler
from jupyterlab_infacore.loghandler import InfacoreLogsRouteHandler
from jupyterlab_infacore.feedbackhandler import InfacoreFeedbackRouteHandler
from jupyterlab_infacore.runtimeenvironmenthandler import InfaCoreRuntimeEnvironmentHandler
from jupyterlab_infacore.forgotpasswordhandler import InfacoreForgotPasswordHandler
from jupyterlab_infacore.logouthandler import InfacoreLogoutRouteHandler
from jupyterlab_infacore.activityloghandler import InfacoreActivityLogsRouteHandler
from jupyterlab_infacore.functionshandler import InfacoreDQFunctionsRouteHandler
from jupyterlab_infacore.fetchuser import InfacoreLoggedUserHandler
from jupyterlab_infacore.connectionactionshandler import InfacoreConnectionActionsHandler
from jupyterlab_infacore.fetchconnectiondetails import InfaCoreConnectorConnectionDetailsHandler
from jupyterlab_infacore.updateconnection import InfaCoreUpdateConnectionHandler

def setup_handlers(web_app, url_path):
    host_pattern = ".*$"
    base_url = web_app.settings["base_url"]

    # Prepend the base_url so that it works in a JupyterHub setting
    infacore_login_route_pattern = url_path_join(base_url, url_path, "login")
    infacore_registration_route_pattern = url_path_join(base_url, url_path, "register")
    infacore_connector_route_pattern = url_path_join(base_url, url_path, "connectors")
    infacore_connector_attr_route_pattern = url_path_join(base_url, url_path, r"connectors/([^/]+)/attributes")
    infacore_connector_connections_route_pattern = url_path_join(base_url, url_path, r"connectors/([^/]+)/connections")
    infacore_connector_connections_action_route_pattern = url_path_join(base_url, url_path, "connections/actions")
    infacore_newconnection_route_pattern = url_path_join(base_url, url_path, "newconnection")
    infacore_logs_route_pattern = url_path_join(base_url, url_path, "logs")
    infacore_feedback_route_pattern = url_path_join(base_url, url_path, "feedback")
    infacore_agent_route_pattern = url_path_join(base_url, url_path, r"runtime/([^/]+)")
    infacore_forgot_password_route_pattern = url_path_join(base_url, url_path, "forgotpassword")
    infacore_logout_route_pattern = url_path_join(base_url, url_path, "logout")
    infacore_activity_log_route_pattern = url_path_join(base_url, url_path, "activitylogs")
    infacore_functions_route_pattern = url_path_join(base_url, url_path, "dqfunctions")
    infacore_fetch_user_route_pattern = url_path_join(base_url, url_path, "user")
    infacore_connection_details_route_pattern = url_path_join(base_url, url_path, r"connectiondetails/([^/]+)/([^/]+)")
    infacore_update_connection_route_pattern = url_path_join(base_url, url_path, "editconnection")
    handlers = [
        (infacore_login_route_pattern, InfacoreLoginRouteHandler),
        (infacore_registration_route_pattern, InfacoreRegistrationRouteHandler),
        (infacore_connector_route_pattern,InfaCoreConnectorsHandler),
        (infacore_connector_attr_route_pattern,InfacoreConnectorAttributesHandler),
        (infacore_connector_connections_route_pattern,InfaCoreConnectorsConnectionsHandler),
        (infacore_newconnection_route_pattern, InfacoreNewConnectionRouteHandler),
        (infacore_logs_route_pattern, InfacoreLogsRouteHandler),
        (infacore_feedback_route_pattern, InfacoreFeedbackRouteHandler),
        (infacore_logs_route_pattern, InfacoreLogsRouteHandler),
        (infacore_agent_route_pattern,InfaCoreRuntimeEnvironmentHandler),
        (infacore_forgot_password_route_pattern, InfacoreForgotPasswordHandler),
        (infacore_logout_route_pattern, InfacoreLogoutRouteHandler),
        (infacore_activity_log_route_pattern,InfacoreActivityLogsRouteHandler),
        (infacore_functions_route_pattern,InfacoreDQFunctionsRouteHandler),
        (infacore_fetch_user_route_pattern,InfacoreLoggedUserHandler),
        (infacore_connector_connections_action_route_pattern, InfacoreConnectionActionsHandler),
        (infacore_connection_details_route_pattern,InfaCoreConnectorConnectionDetailsHandler),
        (infacore_update_connection_route_pattern,InfaCoreUpdateConnectionHandler)
    ]
    web_app.add_handlers(host_pattern, handlers)

    # Prepend the base_url so that it works in a JupyterHub setting
    doc_url = url_path_join(base_url, url_path, "public")
    doc_dir = os.getenv(
        "JLAB_SERVER_EXAMPLE_STATIC_DIR",
        os.path.join(os.path.dirname(__file__), "public"),
    )
    handlers = [("{}/(.*)".format(doc_url), StaticFileHandler, {"path": doc_dir})]
    web_app.add_handlers(".*$", handlers)