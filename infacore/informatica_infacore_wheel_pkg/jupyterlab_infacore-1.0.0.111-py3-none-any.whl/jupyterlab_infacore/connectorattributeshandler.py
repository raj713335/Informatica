#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json
from notebook.base.handlers import APIHandler

import tornado
import informatica.infacore.datasource.datasource as ds
import informatica.infacore.internal.logger as logger

_logger = logger.get_logger(__name__)

class InfacoreConnectorAttributesHandler(APIHandler):
    """Handler for /infacore/connector/attributes/{name} routes.
    Provides methods for handling GET request for fetching connectors .
    """
    @tornado.web.authenticated
    def get(self, conn_name):
        try:
            ds_obj = ds.get_data_source(conn_name)
            conn_details = ds_obj.config("RAW")
            _logger.debug("Connector attributes obtained")
            self.finish(json.dumps({'status': 200, 'details': conn_details}))
        except Exception as e:
            _logger.error("Could not get connector attributes")
            _logger.exception(e)
            self.finish(json.dumps({'status': 503}))