#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json
import tornado
from mimetypes import guess_type

from notebook.base.handlers import APIHandler

import informatica.infacore.internal.logger as logger
from informatica.infacore.internal.utils import get_cloud_provider, get_region

_logger = logger.get_logger(__name__)

class InfacoreForgotPasswordHandler(APIHandler):

    @tornado.web.authenticated
    def get(self):
        try:
            cloud_provider = get_cloud_provider("login", "cloud_provider")
            region = get_region("login", "region")
            cloud_provider_region = cloud_provider + "-" + region
            base_url = f"https://{cloud_provider_region}.informaticacloud.com"
            _logger.debug('base url from SDK: ' + base_url)
            password_reset_url = base_url + "/identity-service/forget"
            data = {'password_reset_url': password_reset_url}
            self.finish(json.dumps(data))
        except Exception as e:
            _logger.error("Could not get base url details from SDK")
            _logger.exception(e)
            self.finish(json.dumps({'status': 503, 'message':'unable to get base url details from SDK'}))
    
    