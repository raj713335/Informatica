#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json
import tornado
from operator import length_hint

from notebook.base.handlers import APIHandler

import informatica.infacore.internal.logger as logger

_logger = logger.get_logger(__name__)

class InfacoreActivityLogsRouteHandler(APIHandler):

    @tornado.web.authenticated
    def get(self):
        log_file_path = self._get_log_file_path(_logger)
        activityList = []

        with open(log_file_path) as source_file:
            line = source_file.readline()
            
            activity = ''
            while line:
                words_list = []
                TimeStamp = ''
                line = source_file.readline()
                index = line.find("INFACore :: Entering")
                if index != -1:
                    words_list = line.split()
                    TimeStamp = words_list[0] + " " + words_list[1]
                    indexOfEntering = line.index("INFACore :: Entering")
                    activity = line[indexOfEntering+len("INFACore :: Entering"):len(line)]
                    activityData = {
                        'TimeStamp': TimeStamp,
                        'Activity': activity.strip()
                        }
                    
                    activityList.append(activityData)
        activityList.reverse()
        tempList = activityList[0:30]
        self.finish(json.dumps(tempList))

    def _get_log_file_path(self, logger_obj):
        if logger_obj:
            handlers = logger_obj.parent.handlers
            if handlers:
                for one_handler in handlers:
                    if 'baseFilename' in dir(one_handler):
                        return one_handler.baseFilename