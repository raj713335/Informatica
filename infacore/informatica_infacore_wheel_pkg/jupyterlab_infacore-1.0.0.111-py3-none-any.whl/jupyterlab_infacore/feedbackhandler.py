#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json

from notebook.base.handlers import APIHandler

import tornado
from informatica.infacore import session
from informatica.infacore.internal.exceptions import InfacoreSessionError, InfacoreClientError
import informatica.infacore.internal.logger as logger
from informatica.infacore.internal.utils import get_firstname,get_lastname,get_email
from informatica.infacore.common.survey import create_survey
from informatica.infacore.common.constants import SurveyType
_logger = logger.get_logger(__name__)

class InfacoreFeedbackRouteHandler(APIHandler):
    """Handler for /infacore/feedback routes.

    Provides methods for handling POST request.
    """
    
    @tornado.web.authenticated
    def post(self):
        feedback_details = self.get_json_body()
        survey_dict = {}
        user_full_name = get_firstname()+' '+get_lastname()
        email = get_email()
        feedback_type = feedback_details['type']
        feedback_data = feedback_details['data']
        survey_dict['email'] = email
        survey_dict['name'] = user_full_name
        message = feedback_type
        try:
            if feedback_type == 'Feedback':
                survey_dict['feedback'] = feedback_data
                create_survey(survey_dict,SurveyType.FEEDBACK)
            elif feedback_type == 'Suggestion':
                survey_dict['newFunctionalitySuggestion'] = feedback_data['Request']
                survey_dict['description'] = feedback_data['Description']
                create_survey(survey_dict,SurveyType.SUGGESTION)
            elif feedback_type == 'Referral':
                survey_dict['referralName'] = feedback_data['referralName']
                survey_dict['referralEmail'] = feedback_data['referralEmail']
                survey_dict['referralCompany'] = feedback_data['referralCompany']
                survey_dict['message'] = feedback_data['message']
                create_survey(survey_dict,SurveyType.REFERRAL)
            _logger.debug('feedback submitted successfully')
            data = {
            'status': 200,
            'message': message+' submitted successfully' 
            }
        except Exception as e:
            data = {
            'status': 500,
            'message': message+' failed to submit' 
            }
        self.finish(json.dumps(data))