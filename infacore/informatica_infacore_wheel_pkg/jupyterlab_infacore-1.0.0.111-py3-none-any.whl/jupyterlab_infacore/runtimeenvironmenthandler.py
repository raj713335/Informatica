#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json
import threading
from notebook.base.handlers import APIHandler

import tornado
from informatica.infacore import session
from informatica.infacore.internal.exceptions import  InfacoreClientError
from informatica.infacore.compute_engine.compute_engine_factory import ComputeEngineFactory
import informatica.infacore.internal.logger as logger

_logger = logger.get_logger(__name__)
install_status = 'NOT_INSTALLED'

class InfaCoreRuntimeEnvironmentHandler(APIHandler):
    """Handler for /infacore/runtimeagent/download routes.
    Provides methods for handling runtime agent actions.
    """

    @tornado.web.authenticated
    def post(self,action):
        status = 200
        description = ''
        if action == "install":
            login_dict = {"compute_engine": {"type":"local","install":True}}
            # self.start_agent_setup(config=login_dict)
            t = threading.Thread(target=self.start_agent_setup, kwargs={'config':login_dict})
            t.start()
            self.finish(json.dumps({'status':202}))
        elif action == "stop":
            try:
                computeEng = ComputeEngineFactory.build_compute_engine("local",{})
                computeEng.stop()
                description = 'stopped successfully'
                _logger.debug("Compute engine stopped successfully")
                data = {'status': status, 'data': {'description': description}}
                self.finish(json.dumps(data))
            except Exception as e:
                description = 'error while stopping'
                _logger.exception("Compute engine stop failed: " + e)
        elif action == "start":
            try:
                computeEng = ComputeEngineFactory.build_compute_engine("local",{})
                computeEng.start()
                description = 'started successfully'
                _logger.debug("Compute engine started successfully")
                data = {'status': status, 'data': {'description': description}}
                self.finish(json.dumps(data))
            except Exception as e:
                description = 'error while starting'
                _logger.exception("Could not start compute engine: " + e)
        
   
    def start_agent_setup(self, config):
        global install_status
        install_status = 'INSTALLING'
        _logger.info('conig:' + str(config))
        try:
            session.setup(config=config)
            description = 'installed successfully'
            install_status = 'INSTALLED'
            _logger.debug("Compute engine setup completed successfully")
        except Exception as e:
            status = 503
            _logger.error("Compute engine setup failed")
            _logger.exception(e)
            install_status = 'FAILED'
            description = 'installation failed'
        pass

    @tornado.web.authenticated
    def get(self, action):
        if action == "status":
            try:
                if install_status == 'INSTALLING':
                    self.finish(json.dumps({'status': 200, 'agent_status': 'INSTALLING'}))
                else:
                    computeEng = ComputeEngineFactory.build_compute_engine("local",{})
                    agent_status = computeEng.get_status()
                    _logger.debug("Compute engine status from SDK: " + agent_status)
                    self.finish(json.dumps({'status': 200, 'agent_status': agent_status}))
            except ValueError as e:
                _logger.error("Could not get compute engine status from SDK")
                _logger.exception(e)
                self.finish(json.dumps({'status': 401, 'message':'Could not get compute engine status from SDK'}))
            except Exception as e:
                _logger.error("Could not get compute engine status from SDK: ")
                _logger.exception(e)
                self.finish(json.dumps({'status': 503}))




