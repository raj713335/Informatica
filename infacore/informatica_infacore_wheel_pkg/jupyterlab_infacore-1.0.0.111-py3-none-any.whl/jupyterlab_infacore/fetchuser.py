#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import json

from notebook.base.handlers import APIHandler

import tornado

from informatica.infacore.internal.utils import get_username, get_firstname, get_lastname
from informatica.infacore.internal.exceptions import InfacoreSessionError, InfacoreClientError
import informatica.infacore.internal.logger as logger



class InfacoreLoggedUserHandler(APIHandler):
    """Handler for /infacore/username routes.

    Provides methods for handling GET request.
    """
    
    @tornado.web.authenticated
    def get(self):
        username = get_username()
        first_name = get_firstname()
        last_name = get_lastname()
        self.finish(json.dumps({"username": username, "first_name": first_name, "last_name": last_name}))
