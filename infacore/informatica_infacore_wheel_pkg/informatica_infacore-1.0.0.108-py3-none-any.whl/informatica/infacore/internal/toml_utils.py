#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
TOML utility module for INFACore python SDK.

For internal use only.
"""
import os
import pathlib

import toml

from informatica.infacore.common.constants import (
    CONFIG_FILE_ENV_VAR,
    INFACORE_CONFIG_TEMPLATE_FILE,
    LOG_CONFIG_FILE,
)
from informatica.infacore.common.constants import INFACORE_CONFIG_FILE

# Utils methods for log_conf.toml file.
def load_log_config() -> dict:
    return toml.load(LOG_CONFIG_FILE)


# Utils methods for infacore_conf.toml file.
def load_infacore_config() -> dict:
    config_file = get_config_file_path()
    return toml.load(config_file)


def dump_infacore_config(ic_config: dict) -> None:
    config_file = get_config_file_path()
    with open(config_file, "w+", encoding="utf-8") as toml_file:
        toml.dump(ic_config, toml_file)


def load_infacore_base_config() -> dict:
    return toml.load(INFACORE_CONFIG_TEMPLATE_FILE)


def get_config_value(table: str, key: str) -> str:
    """
    Get value for asked key from toml file
    """
    config_file = get_config_file_path()
    config = toml.load(config_file)
    return config[table][key]


def get_config_file_path():
    ic_config_file_path = ""
    user_config_file_path = os.getenv(CONFIG_FILE_ENV_VAR)
    if user_config_file_path:
        file_extension = pathlib.Path(user_config_file_path).suffix
        if file_extension == ".toml":
            ic_config_file_path = user_config_file_path
        else:
            raise ValueError("Please provide a valid TOML config file.")
    else:
        ic_config_file_path = INFACORE_CONFIG_FILE
    return ic_config_file_path
