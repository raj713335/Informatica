#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
Utility module for INFACore python SDK.

For internal use only.
"""
import json
import os
import platform
import time
import pathlib

import keyring

from informatica.infacore.common.constants import (
    TEMPLATES_DIR,
    NATIVE_DATASOURCES,
)
import informatica.infacore.internal.logger as logger
from informatica.infacore.internal.toml_utils import get_config_value
from informatica.infacore.version import __version__ as infacore_version


def get_version() -> str:
    """Return infacore version."""
    return infacore_version


def get_python_version() -> str:
    """Return python version."""
    return platform.python_version()


def get_os_name() -> str:
    """Return operating system name."""
    return platform.system()


def get_host_name() -> str:
    """_summary_"""
    return platform.node()


def get_app_name() -> str:
    """Return's application name."""
    return "INFACore"


def is_user_logged_in() -> bool:
    """Checks if user is logged in or not."""
    session_id = get_session_id()
    if not session_id:
        return False
    return True


def is_compute_engine_installed() -> bool:
    """Checks if compute engine setup is completed or not."""
    compute_engine_type = get_config_value("compute_engine", "type")
    if not compute_engine_type:
        return False
    return True


def is_asset_setup_done() -> bool:
    """Checks if asset setup is completed or not."""
    project_id = get_config_value("asset", "project_id")
    if not project_id:
        return False
    return True


def is_ecosystem_staging_done() -> bool:
    if not get_staging_type():
        return False
    return True


def get_password() -> str:
    """Get password from keyring."""
    password = keyring.get_password("INFACore", get_username())
    return password


def set_password(username: str, password: str):
    """Set password in keyring."""
    keyring.set_password("INFACore", username, password)


def generate_random_name(key: str) -> str:
    """Return random name."""
    cur_time = str(round(time.time() * 1000))
    random_name = key + "_" + cur_time
    return random_name


def get_env_var(env_var: str) -> str:
    return os.getenv(env_var)


def get_tmp_dir() -> str:
    os_name = get_os_name()
    if os_name == "Windows":
        tmp_dir = "C:/Windows/Temp/infacore/"
    elif os_name == "Linux":
        tmp_dir = "/tmp/infacore/"
    return tmp_dir


def construct_payload(template_name: str, parameter_values: dict) -> dict:
    template_file_path = TEMPLATES_DIR + os.sep + template_name
    with open(template_file_path, "r", encoding="utf-8") as template_file:
        payload = json.load(template_file)
        payload_str = json.dumps(payload)
        for key, value in parameter_values.items():
            payload_str = payload_str.replace("<<" + key + ">>", str(value))
        payload = json.loads(payload_str)
        return payload


def sanitize_col_name(col_name: str) -> str:
    return "".join([c if c.isalnum() else "_" for c in col_name])


def get_agent_root_dir() -> str:
    os_name = get_os_name()
    if os_name == "Windows":
        agent_root_dir = "C:/Program Files/Informatica Cloud Secure Agent/"
    elif os_name == "Linux":
        agent_root_dir = str(pathlib.Path.home()) + "/infaagent/"
    return agent_root_dir


def get_log_filepath():
    _logger = logger.get_logger(__name__)
    file_path = _logger.root.handlers[0].baseFilename
    return file_path


def list_functions():
    functions = construct_payload("list_functions_template.json", {})
    return functions


def get_env_type():
    return get_config_value("login", "env_type")


def get_cloud_provider():
    return get_config_value("login", "cloud_provider")


def get_region():
    return get_config_value("login", "region")


def get_url():
    return get_config_value("login", "url")


def get_username() -> str:
    return get_config_value("login", "username")


def get_firstname():
    return get_config_value("user", "firstname")


def get_lastname():
    return get_config_value("user", "lastname")


def get_email() -> str:
    return get_config_value("user", "email")


def get_session_id() -> str:
    """Get valid session id."""
    return get_config_value("session", "id")


def get_org_id():
    return get_config_value("session", "org_id")


def get_base_url():
    return get_config_value("session", "base_url")


def get_compute_engine_type():
    return get_config_value("compute_engine", "type")


def get_runtime_env_name():
    return get_config_value("compute_engine", "runtime_env_name")


def get_runtime_env_id():
    return get_config_value("compute_engine", "runtime_env_id")


def get_agent_name():
    return get_config_value("compute_engine", "agent_name")


def get_agent_id():
    return get_config_value("compute_engine", "agent_id")


def get_project_id():
    return get_config_value("asset", "project_id")


def get_mapping_id(mapping_name):
    return get_config_value("asset", mapping_name)


def delete_tmp_file(fname: str):
    """deletes the file from temp folder"""
    tmp_dir = get_tmp_dir()
    fname = tmp_dir + os.sep + fname
    if os.path.isfile(fname):
        os.remove(fname)


def get_staging_type():
    return get_config_value("staging", "type")


def get_staging_connection_name():
    return get_config_value("staging", "connection_name")


def get_staging_connection_id():
    return get_config_value("staging", "connection_id")


def get_staging_config():
    return get_config_value("staging", "config")


def upsert_mct_parameter(parameters: list, new_parameter: dict):
    """
    Insert the new parameter in mct parameters list, if already exist. Else append it to the last.
    """
    new_type = new_parameter.get("type")
    is_param_exist = False
    for i in range(len(parameters)):
        exisiting_parameter_type = parameters[i].get("type")
        if new_type == exisiting_parameter_type:
            parameters[i] = new_parameter
            is_param_exist = True
            break

    if not is_param_exist:
        parameters.append(new_parameter)


def get_type_system(connector_type: str) -> str:
    """
    Return the type system of the connector. For native connectors, it should return as is it. For CTK and CCI connectors, will return type as TOOLKIT
    """
    if connector_type in NATIVE_DATASOURCES:
        return connector_type
    else:
        return "TOOLKIT"
