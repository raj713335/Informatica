#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
from informatica.infacore.internal.exceptions import (
    _InfacoreInternalError,
    InfacoreClientError,
    InfacoreSessionError,
)


class InfacoreClientErrorMessages:
    """
    Holds all of the error messages that could be used in the InfacoreClientError Class.
    IMPORTANT: keep this file in numerical order of the error-code.
    """

    # Internal Error messages 001X

    @staticmethod
    def internal_test_message(message: str) -> _InfacoreInternalError:
        """to do"""
        return _InfacoreInternalError(f"internal test message: {message}.", "1010")

    # Session Error Messages 11XX
    @staticmethod
    def mandatory_setup_config_missing() -> InfacoreClientError:
        """
        to do
        """
        return InfacoreClientError(
            "Mandatory INFACore setup config not provided.", "1101"
        )

    @staticmethod
    def mandatory_login_key_missing() -> InfacoreClientError:
        """
        to do
        """
        return InfacoreClientError(
            "Mandatory login key missing from INFACore setup config.", "1102"
        )

    @staticmethod
    def mandatory_login_detail_missing(message: str) -> InfacoreClientError:
        """
        to do
        """
        return InfacoreClientError(
            f"Mandatory login detail {message} not provided.", "1103"
        )

    @staticmethod
    def invalid_login_details_provided(message: str) -> InfacoreClientError:
        """
        to do
        """
        return InfacoreClientError(
            f"Failed to login to Informatica. The error is: {message}", "1104"
        )

    @staticmethod
    def unsupported_setup_config_provided(
        key: str, value: str, supported_values: list
    ) -> InfacoreClientError:
        """
        to do
        """
        return InfacoreClientError(
            f"Unsupported value {value} provided for attribute {key}. Supported values are: {supported_values}",
            "1105",
        )

    @staticmethod
    def mandatory_compute_engine_detail_missing(message: str) -> InfacoreClientError:
        """
        to do
        """
        return InfacoreClientError(
            f"Mandatory compute engine detail {message} not provided.", "1106"
        )

    # Server Error Messages 12XX
    @staticmethod
    def iics_api_failed(code: str, message: str) -> InfacoreSessionError:
        """
        to do
        """
        return InfacoreSessionError(
            f"Informatica SAAS API execution failed. The code is {code} error is: {message}",
            "1201",
        )
