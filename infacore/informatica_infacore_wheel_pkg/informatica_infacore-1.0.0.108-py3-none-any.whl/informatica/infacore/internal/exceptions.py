#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
This module contains all INFACore client-side exceptions.

For internal use only.
"""


class InfacoreClientError(Exception):
    """Base Infacore exception class"""

    def __init__(self, message: str, error_code: str = None) -> None:
        self.message: str = message
        self.error_code: str = error_code

        self._pretty_msg = (
            f"({self.error_code}): {self.message}" if self.error_code else self.message
        )

    def __repr__(self):
        return f"{self.__class__.__name__}({self.message!r}, {self.error_code!r})"

    def __str__(self):
        return self._pretty_msg


class _InfacoreInternalError(InfacoreClientError):
    """
    Exception for internal errors. For internal use only.
    Includes all error codes in 10XX (where XX is 0-9).
    """

    pass


class InfacoreSessionError(InfacoreClientError):
    """
    Exception for any session related errors.
    Includes all error codes in range 11XX (where XX is 0-9).
    """


class InfacoreServerError(InfacoreClientError):
    """
    Exception for miscellaneous related errors.
    Includes all error codes in range 12XX (where XX is 0-9).
    """

    pass


class InfacoreGeneralError(InfacoreClientError):
    """
    Exception for general exceptions.
    Includes all error codes in range 13XX (where XX is 0-9).
    """

    pass
