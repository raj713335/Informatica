#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
Logging utility module for INFACore python SDK.

For internal use only.
"""
import logging
import logging.config

from informatica.infacore.internal.toml_utils import load_log_config

log_config = load_log_config()
logging.config.dictConfig(log_config)


def get_logger(module_name):
    """
    Return INFACore logger object.
    """
    return logging.getLogger(module_name)
