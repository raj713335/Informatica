#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
Utility functions used for creating a common http client from requests lib.

For internal use only.
"""
import requests
from requests_toolbelt import sessions
from requests.adapters import HTTPAdapter, Retry
from informatica.infacore.internal.error_message import InfacoreClientErrorMessages
import informatica.infacore.internal.logger as logger
from informatica.infacore.common.constants import (
    DEFAULT_TIMEOUT_IN_SEC,
    ApiUrl,
    ApiVersion,
    EnvType,
    SessionIdHeader,
)
from informatica.infacore.internal.utils import (
    get_base_url,
    get_cloud_provider,
    get_env_type,
    get_region,
    get_session_id,
    get_url,
)


_logger = logger.get_logger(__name__)


def get(api_name: str, additional_path: str = ""):
    """
    INFACore HTTP GET API.
    """
    try:
        api_version = ApiVersion[api_name].value
        sess = _create_session(api_version)
        resp = sess.get(
            ApiUrl[api_name].value + additional_path, timeout=DEFAULT_TIMEOUT_IN_SEC
        )
        return resp
    except Exception as ex:
        _logger.error(ex)
        raise


def post(
    api_name: str,
    payload: dict = None,
    login_api: bool = False,
    additional_path: str = "",
    additional_headers: dict = None,
):
    """
    INFACore HTTP POST API.
    """
    try:
        api_version = ApiVersion[api_name].value
        sess = _create_session(api_version, login_api, additional_headers)
        resp = sess.post(
            ApiUrl[api_name].value + additional_path,
            json=payload,
            timeout=DEFAULT_TIMEOUT_IN_SEC,
        )
        return resp
    except Exception as ex:
        _logger.exception(ex)
        raise


def put(
    api_name: str,
    payload: dict = None,
    additional_path: str = "",
    additional_headers: dict = None,
):
    """
    INFACore HTTP PUT API.
    """
    try:
        api_version = ApiVersion[api_name].value
        sess = _create_session(api_version, additional_headers=additional_headers)
        resp = sess.put(
            ApiUrl[api_name].value + additional_path,
            json=payload,
            timeout=DEFAULT_TIMEOUT_IN_SEC,
        )
        return resp
    except Exception as ex:
        _logger.exception(ex)
        raise


def delete(api_name: str, additional_path: str = ""):
    """
    INFACore HTTP GET API.
    """
    try:
        api_version = ApiVersion[api_name].value
        sess = _create_session(api_version)
        resp = sess.delete(
            ApiUrl[api_name].value + additional_path, timeout=DEFAULT_TIMEOUT_IN_SEC
        )
        return resp
    except Exception as ex:
        _logger.error(ex)
        raise


def download_file(download_url):
    resp = requests.get(download_url, stream=True)
    return resp


def _create_session(
    api_version: str, is_login_api: bool = False, additional_headers: dict = None
):
    """
    Create requests session object.
    """
    try:
        base_url = _get_base_url(is_login_api, api_version)
        sess = sessions.BaseUrlSession(base_url)

        if is_login_api:
            sess.headers.update(
                {"Content-Type": "application/json", "Accept": "application/json"}
            )
        else:
            sess.headers.update(
                {
                    _get_session_header(api_version): get_session_id(),
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                }
            )

        if additional_headers:
            sess.headers.update(additional_headers)

        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST", "HEAD", "OPTIONS"],
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)
        sess.mount("https://", adapter)
        sess.mount("http://", adapter)

        sess.hooks["response"] = [check_for_error, log_response_text]
        return sess
    except Exception as ex:
        _logger.exception(ex)
        raise


def _get_base_url(is_login_api: bool, api_version: str) -> str:
    """
    Get base url as required by IDMC REST API's
    """
    env_type = get_env_type()
    cloud_provider = get_cloud_provider()
    region = get_region()

    if is_login_api:
        if env_type == EnvType.PROD.value:
            cloud_provider_region = cloud_provider + "-" + region
            base_url = f"https://{cloud_provider_region}.informaticacloud.com"
        elif env_type == EnvType.TEST.value:
            base_url = get_url()
    else:
        base_url = get_base_url()
        if _is_infacore_api(api_version):
            base_url = base_url.replace(".", "-infacore" + ".", 1)

    _logger.debug("Base URL value is : %s", base_url)
    return base_url


def _get_session_header(api_version: str) -> str:
    """
    Get session header as required by IDMC REST API's.
    """
    # In enum with duplicate values, the usage should be in below manner
    session_header = SessionIdHeader[api_version].value 
    return session_header


def _is_infacore_api(api_version: str) -> bool:
    if api_version.startswith("INFACORE"):
        return True
    return False


# Hook Functions
def check_for_error(resp, *args, **kwargs):
    """check for error"""
    if not is_special_scenario(resp):
        if resp.status_code in range(400, 600):
            raise InfacoreClientErrorMessages.iics_api_failed(
                resp.status_code, resp.text
            )
        # resp.raise_for_status()


def is_special_scenario(resp, *args, **kwargs) -> bool:
    error_scenarios = [
        {
            "url": ApiUrl.RUNTIME_ENV.value,
            "response_text": "Agent Group Selections not supported for",
            "status_code": 400,
            "info_msg": "Runtime Environment Selections license is not present",
        },
        {
            "url": ApiUrl.LOOKUP.value,
            "response_text": "Cannot find the following objects: [[type: Project, location: INFACore]]",
            "status_code": 400,
            "info_msg": "Creating an INFACore project as it doesn't exist",
        },
    ]
    for error in error_scenarios:
        if (
            error.get("status_code") == resp.status_code
            and error.get("url") in resp.url
            and error.get("response_text") in resp.text
        ):
            _logger.info(error.get("info_msg"))
            return True
    return False


def log_response_text(resp, *args, **kwargs):
    """log resp text"""
    _logger.debug("Got response %r from %s", resp.text, resp.url)
