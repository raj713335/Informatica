#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
from __future__ import annotations

import json
from informatica.infacore.common.decorators import log_activity
from informatica.infacore.common.native_connection import construct_connection_payload
from informatica.infacore.dataframe.dataobject import DataObject
from informatica.infacore.common.constants import (
    NATIVE_DATASOURCES,
    DataObjectScopes,
    InfacoreDataSources,
)
import informatica.infacore.common.iics_rest_api as iics_api
import informatica.infacore.internal.logger as logger
from informatica.infacore.internal.utils import (
    get_agent_id,
    get_org_id,
    get_runtime_env_id,
)

_logger = logger.get_logger(__name__)


class Connection:
    """
    Represents the connection to the data source instance that INFACore uses for the read or write operation.

    You can call test() to validate the connection,
    or you can call list_data_objects() to fetch the available objects.
    """

    def __init__(
        self,
        connection_name: str,
        connector_type: str,
        connection_parameters: dict,
        connection_id: str,
        status_message: str,
    ) -> None:
        self._connection_name = connection_name
        self._connnector_type = connector_type
        self._connection_parameters = connection_parameters
        self._connection_id = connection_id
        self._status_message = status_message

    @log_activity
    def test(self) -> str:
        """
        Tests the connection and validates the connection details you specified.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_cnx = ic.get_datasource("Oracle").get_connection("Oracle Prod")
        >>> orcl_cnx.test()
        """
        resp = iics_api.test_connection(self._connection_id)
        message = resp.json()["description"]
        return message

    @log_activity
    def config(self) -> dict:
        """
        Returns the details of the connection attributes for an existing connection.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_cnx = ic.get_datasource("Oracle").get_connection("Oracle Prod")
        >>> orcl_cnx.config()
        """
        resp = iics_api.get_connection_details(self._connection_name)
        connection_details = Connection._parse_connection_details(
            resp.json(), self._connnector_type
        )
        return connection_details

    @log_activity
    def list_data_objects(self, path: str = None) -> list[str]:
        """
        Lists the available data objects in the specified connection instance.

        Parameters
        ----------
        path : str, optional
            The path to the data object. Default is False.

            For example, if the data source is a Cloud Data Warehouse,
            you might need to provide the database name and the schema name in the following format:
            <DatabaseName>/<SchemaName>

            If the data source is a Cloud Data Lake,
            you might need to enter the bucket name and folder name in the following format:
            <BucketName>/<FolderName>  

        Returns
        -------
        list[str]
            A list of data objects with the read and write scopes.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_cnx = ic.get_datasource("Oracle").get_connection("Oracle Prod")
        >>> orcl_cnx.list_data_objects()

        """
        query = self._connection_name
        if path:
            query = self._connection_name + "?path=" + path
        read_resp = iics_api.get_source_objects(query)
        write_resp = iics_api.get_target_objects(query)
        dataobjects = self._parse_object_resp(read_resp.json(), write_resp.json())
        return dataobjects

    @log_activity
    def get_data_object(self, object_name: str) -> DataObject:
        """
        Fetches the DataObject instance corresponding to the data object name you specified.

        Parameters
        ----------
        object_name : str
            The name of the data object, or the complete path of the data object.

        Returns
        -------
        DataObject
            Instance of the DataObject for which you want to perform the read or write operation.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_cnx = ic.get_datasource("Oracle").get_connection("Oracle Prod")
        >>> orcl_cnx.get_data_object("Customers")
        """
        return DataObject(self, object_name, None)

    @log_activity
    def edit(
        self, new_connection_name: str = None, connection_parameters: dict = None
    ) -> Connection:
        """
        Edits the connection name and attributes of an existing connection.

        Parameters
        ----------
        new_connection_name : str, optional
            The new name for the connection.

        connection_parameters : dict, optional
            The updated connection attributes in "key, value" pairs.

        Returns
        -------
        Connection
            The updated connection object.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_cnx = ic.get_datasource("Oracle").get_connection("Oracle Prod")
        >>> orcl_params = {
                "username": "<New Username of Oracle database>",
                "password": "<New Password of Oracle database>",
            }
        >>> orcl_cnx = orcl_cnx.edit("Oracle Prod Connection", orcl_params)
        """
        iics_type = Connection._get_iics_type(self._connnector_type)
        if connection_parameters:
            self._connection_parameters = connection_parameters
        try:
            if new_connection_name == "":
                raise ValueError("Connection name cannot be empty.")

            Connection._upsert_connection(
                iics_type=iics_type,
                connection=self,
                edit_flag=True,
                new_connection_name=new_connection_name,
            )
            if new_connection_name:
                self._connection_name = new_connection_name

            self._status_message = self.test()
            return self
        except Exception as ex:
            _logger.error(ex)
            raise

    @staticmethod
    def _parse_connection_details(
        raw_connection_details: dict, connector_type: str
    ) -> dict:
        """
        Parse get_connectors REST response and frame a list of attributes
        """
        connection_details: dict = raw_connection_details.get("connParams")
        if "CCM_CONN_PRESENTATION" in connection_details:
            ccm_pres_str = connection_details["CCM_CONN_PRESENTATION"]
            ccm_pres = json.loads(ccm_pres_str)
            connection_details["CCM_CONN_PRESENTATION"] = ccm_pres

        if connector_type in NATIVE_DATASOURCES:
            connection_details = construct_connection_payload(
                connector_type, raw_connection_details, True
            )
        return connection_details

    @staticmethod
    def _parse_object_resp(read_objects: list, write_objects: list) -> list:
        """
        find common object from source and target list, and return object with type
        """
        dataobjects: list[dict] = []
        for objects in read_objects:
            del objects["id"]
        for objects in write_objects:
            del objects["id"]

        read_write_objects = [
            object for object in read_objects if object in write_objects
        ]
        read_only_objects = [
            object for object in read_objects if object not in read_write_objects
        ]
        write_only_objects = [
            object for object in write_objects if object not in read_write_objects
        ]
        Connection._populate_do_dict(
            dataobjects, read_only_objects, DataObjectScopes.READ_ONLY.value
        )
        Connection._populate_do_dict(
            dataobjects, write_only_objects, DataObjectScopes.WRITE_ONLY.value
        )
        Connection._populate_do_dict(
            dataobjects, read_write_objects, DataObjectScopes.READ_AND_WRITE.value
        )
        return dataobjects

    @staticmethod
    def _populate_do_dict(dataobjects: list, objects: list, scope: str):
        """
        Iterate object list and add scope to it
        """
        for object in objects:
            dataobject = {}
            dataobject["name"] = object["name"]
            dataobject["scope"] = scope
            dataobjects.append(dataobject)

    @staticmethod
    def _upsert_connection(
        iics_type: str,
        connection: Connection,
        edit_flag: bool = False,
        new_connection_name: str = None,
    ) -> int:
        """Creates / Updates a connection

        Parameters
        ----------
        iics_type : str
            IICS type of the connection (NATIVE/CCI/CTK)
        connection : Connection
            Connection object which you want to create or update
        edit_flag : bool
            Boolean flag to edit the connection
        new_connection_name : str, optional
            New name for the connection

        Returns
        -------
        int
            http status code
        """
        connection_name = connection._connection_name
        connector_type = connection._connnector_type
        connection_parameters = connection._connection_parameters
        org_id = get_org_id()
        runtime_env_id = get_runtime_env_id()
        agent_id = get_agent_id()

        if iics_type == "NATIVE":
            if connector_type == "SqlServer":
                subtype = connection_parameters.get("subType", "SqlServer2000")
                if subtype == "SqlServer2000":
                    connection_parameters["subType"] = "SqlServer"

            default_params = connection_parameters
            default_params["org_id"] = org_id
            default_params["name"] = connection_name
            default_params["agent_id"] = agent_id
            default_params["runtime_env_id"] = runtime_env_id
            connection_payload = construct_connection_payload(
                connector_type, default_params
            )
        else:
            if iics_type == "CCI":
                type = "TOOLKIT_CCI"
            elif iics_type == "CTK":
                type = "TOOLKIT"
            connection_parameters["agentGroupId"] = runtime_env_id
            connection_payload = {
                "@type": "connection",
                "orgId": org_id,
                "name": connection_name,
                "runtimeEnvironmentId": runtime_env_id,
                "instanceName": connector_type,
                "type": type,
                "connParams": connection_parameters,
            }
        if edit_flag:
            if new_connection_name:
                connection_payload["name"] = new_connection_name
            resp = iics_api.edit_connection(
                connection._connection_id, connection_payload
            )
        else:
            resp = iics_api.create_connection(connection_payload)
        return resp.status_code

    @staticmethod
    def _get_iics_type(connector_name: str) -> str:
        """Returns IICS type when connector type is specified
        Parameters
        ----------
        connector_type: str
            Infacore connector name

        Returns
        --------
        str
            Type of the connector (CCI/CTK/NATIVE)
        """
        for ids in InfacoreDataSources:
            if ids.value[1] == connector_name:
                return ids.value[2]

    def __str__(self) -> str:
        return f"Connection object of {self._connection_name}."
