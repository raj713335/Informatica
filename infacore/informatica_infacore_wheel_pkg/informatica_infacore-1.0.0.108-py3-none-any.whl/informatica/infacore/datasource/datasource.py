#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
from __future__ import annotations
import json
from informatica.infacore.compute_engine.compute_engine import ComputeEngine
from informatica.infacore.compute_engine.compute_engine_factory import (
    ComputeEngineFactory,
)
from informatica.infacore.datasource.connection import Connection
from informatica.infacore.common.constants import (
    NATIVE_DATASOURCES,
    DataSourceConfigModes,
    InfacoreDataSources,
)
import informatica.infacore.common.iics_rest_api as iics_api
import informatica.infacore.internal.logger as logger
from informatica.infacore.common.decorators import log_activity
from informatica.infacore.internal.utils import (
    get_compute_engine_type,
    get_org_id,
    get_runtime_env_id,
    get_runtime_env_name,
    is_compute_engine_installed,
)

_logger = logger.get_logger(__name__)


class DataSource:
    """
    Represents the data source or target from which you want to extract or load data.

    You can choose from the following categories of data sources:
        - Relational Databases: For example, Oracle, MySQL, MS SQL, and PostgreSQL.
        - Cloud Data Warehouses: For example, Amazon Redshift, Databricks Delta, Google BigQuery, Hive, and Snowflake.
        - Cloud Data Lakes: For example, Amazon S3, Microsoft Azure Data Lake Store Gen1, Microsoft Azure Data Lake Store Gen2, and Google Cloud Storage.
        - SAAS Applications: For example, Marketo, Salesforce, SAP, and Zendesk.

    For details about all the available data sources, see the following documentation:
    https://onlinehelp.informatica.com/IICS/dev/infacore/en/index.htm
    """

    def __init__(
        self,
        infacore_name: str,
        iics_name: str,
        iics_type: str,
        compute_engine: ComputeEngine,
    ) -> None:
        self._infacore_name = infacore_name
        self._iics_name = iics_name
        self._iics_type = iics_type
        self._compute_engine = compute_engine

    @log_activity
    def list_connections(self) -> list[str]:
        """
        Returns the list of existing connections in your
        Informatica Intelligent Cloud Services organization
        for the data source you selected.

        Returns
        -------
        list[str]
            The list of existing connections from your
            Informatica Intelligent Cloud Services organization
            for the data source you selected.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_ds = ic.get_data_source("Oracle")
        >>> orcl_ds.list_connections()
        """
        resp = iics_api.get_connections()
        connections = self._parse_connection_list(resp.json())
        return connections

    @log_activity
    def get_connection(self, connection_name: str) -> Connection:
        """
        Gets the connection object of the specified connection from the selected data source.

        Parameters
        ----------
        connection_name : str
            Name of connection from where you want to fetch the connection object.

        Returns
        -------
        Connection
            The connection object with the data source instance.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_ds = ic.get_datasource("Oracle")
        >>> orcl_cnx = orcl_ds.get_connection("Oracle Prod")
        """
        available_connections = self.list_connections()
        if connection_name not in available_connections:
            raise ValueError(
                "Connection name provided does not exist or not valid for this datasource."
            )
        connection_id = DataSource._get_connection_id(connection_name)
        connection = Connection(connection_name, self._iics_name, {}, connection_id, "")
        return connection

    @log_activity
    def config(self, mode: str = DataSourceConfigModes.BASIC.value) -> dict:
        """
        Returns the connection attribute details required for creating the connection.

        Parameters
        ----------
        mode : str
            The value to assign to retrieve the corresponding connection attribute details.

            You can specify the following values:
                - SIMPLIFIED: Gets only the mandatory fields, with default values wherever applicable.
                - BASIC: Gets only the connection attribute keys.
                - RAW: Gets the details of the connection attributes such as the data type, tool tips, isMandatory and other details.

            The default value is BASIC.


        Returns
        -------
        dict
            Connection attribute details as the "key, value" pair.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_ds = ic.get_datasource("Oracle")
        >>> orcl_config = orcl_ds.config()
        """
        resp = iics_api.get_connector_details(self._iics_name)
        datasource_config = DataSource._parse_connector_details(resp.json(), mode)
        return datasource_config

    @log_activity
    def connect(self, connection_name: str, connection_parameters: dict):
        """
        Creates a live connection with the data source instance you specified to read from or to write data.

        Parameters
        ----------
        connection_name : str
            A name for the connection that you want to create.
        connection_parameters : dict
            The connection attributes in “key, value” pairs to create a connection with the data source instance.

        Returns
        -------
        Connection
            A newly created connection object for the data source.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_ds = ic.get_datasource("Oracle")
        >>> orcl_params = {
                "oracleSubType": "oracleonpremise",
                "username": "<Username of Oracle database>",
                "password": "<Password of Oracle database>",
                "host": "<Hostname of Oracle database>",
                "port": "1521",
                "database": "<Database name>",
                "codePage": "UTF-8",
                "encryptionMethod": "NoEncryption",
                "CryptoProtocolVersion": "TLSv1",
                "ValidateServerCertificate": "False"
            }
        >>> orcl_cnx = orcl_ds.connect(connection_name="Oracle Sandbox", connection_parameters=orcl_params)
        """
        connection = Connection(
            connection_name, self._iics_name, connection_parameters, "", ""
        )
        connection_id = ""
        if self._is_connection_present(connection_name):
            connection_id = DataSource._get_connection_id(connection_name)
            connection._connection_id = connection_id
            status_message = connection.test()
            connection._status_message = status_message
            return connection

        resp_code = Connection._upsert_connection(self._iics_type, connection)
        if resp_code == 200:
            connection_id = DataSource._get_connection_id(connection_name)
            connection._connection_id = connection_id
            status_message = connection.test()
            connection._status_message = status_message
        else:
            # Raise error
            pass

        return connection

    @staticmethod
    def _parse_connector_details(connector_details_resp: list, mode: str):
        """
        Parse get_connectors REST response and frame a list of connectors
        """
        is_cci = False
        if "cciMeta" in connector_details_resp[0]:
            is_cci = True
        if is_cci:
            cci_meta_str = connector_details_resp[0]["cciMeta"]
            cci_meta = json.loads(cci_meta_str)
            if mode == "SIMPLIFIED":
                config = DataSource._get_simplified_cci_attributes(cci_meta)
            elif mode == "BASIC":
                config = DataSource._get_basic_cci_attributes(cci_meta)
            elif mode == "RAW":
                config = cci_meta
        else:
            attributes = connector_details_resp[0]["attributes"]
            if mode == DataSourceConfigModes.SIMPLIFIED.value:
                config = DataSource._get_simplified_ctk_attributes(attributes)
            elif mode == "BASIC":
                config = DataSource._get_basic_ctk_attributes(attributes)
            elif mode == "RAW":
                config = attributes
        return config

    @staticmethod
    def _get_simplified_ctk_attributes(attributes):
        """Return minimal key value dict."""
        config = {}
        for attribute in attributes:
            name = attribute["name"]
            is_mandatory = attribute["isMandatory"]
            value = attribute["value"]
            if name != "agentGroupId" and is_mandatory:
                config[name] = value
        return config

    @staticmethod
    def _get_basic_ctk_attributes(attributes):
        """Return minimal key value dict."""
        config = {}
        for attribute in attributes:
            name = attribute["name"]
            if name != "agentGroupId":
                config[name] = ""
        return config

    @staticmethod
    def _get_simplified_cci_attributes(cci_meta: dict) -> dict:
        config = {}
        connections = cci_meta["connections"][0]
        groups = connections["pages"][0]["groups"]
        for group in groups:
            for conn_attributes in group["connAttributePresentation"]:
                attribute_type = conn_attributes["attributeType"]
                if not conn_attributes["hidden"] and (
                    attribute_type["mandatory"] or attribute_type["validList"]
                ):
                    attributes_conf = {}
                    attributes_conf["mandatory"] = attribute_type["mandatory"]
                    attributes_conf["defaultValue"] = attribute_type["defaultValue"]
                    config[attribute_type["attributeName"]] = attributes_conf

        for dynamic_attribute_name, dynamic_attribute_value in connections[
            "dynamic"
        ].items():
            if dynamic_attribute_name in config:
                if bool(dynamic_attribute_value):
                    dependency_attributes = dynamic_attribute_value[
                        config[dynamic_attribute_name]["defaultValue"]
                    ]["attributes"]
                    if (
                        len(dependency_attributes) == 0
                        and not config[dynamic_attribute_name]["mandatory"]
                    ):
                        del config[dynamic_attribute_name]
                    else:
                        for dependency_attribute in dependency_attributes:
                            dependency_attribute_type = dependency_attribute[
                                "attributeType"
                            ]
                            attribute_name = dependency_attribute_type["attributeName"]
                            is_config_present = attribute_name in config
                            if (
                                not dependency_attribute["hidden"]
                                and dependency_attribute_type["mandatory"]
                            ):
                                if is_config_present:
                                    availableConfig = config[attribute_name]
                                    availableConfig[
                                        "mandatory"
                                    ] = dependency_attribute_type["mandatory"]
                                    availableConfig[
                                        "defaultValue"
                                    ] = dependency_attribute_type["defaultValue"]
                                else:
                                    attributes_conf = {}
                                    attributes_conf[
                                        "mandatory"
                                    ] = dependency_attribute_type["mandatory"]
                                    attributes_conf[
                                        "defaultValue"
                                    ] = dependency_attribute_type["defaultValue"]
                                    config[
                                        dependency_attribute_type["attributeName"]
                                    ] = attributes_conf
                            elif is_config_present:
                                del config[attribute_name]
                elif (
                    config[dynamic_attribute_name]["defaultValue"]
                    and not config[dynamic_attribute_name]["mandatory"]
                ):
                    del config[dynamic_attribute_name]
        for configName, configValue in config.items():
            config[configName] = configValue["defaultValue"]
        return config

    @staticmethod
    def _get_basic_cci_attributes(cci_meta: dict) -> dict:
        config = {}
        groups = cci_meta["connections"][0]["pages"][0]["groups"]
        for group in groups:
            for connAttributes in group["connAttributePresentation"]:
                config[connAttributes["attributeType"]["attributeName"]] = ""
        return config

    def _parse_connection_list(self, detailed_connections: list) -> list:
        """Parse get_connectors RESt response and frame a list of connectors

        Parameters
        ----------
        detailed_connections : list
            _description_

        Returns
        -------
        list
            _description_
        """
        connections = []
        for detailed_connection in detailed_connections:
            connector_type = detailed_connection.get("instanceName")
            type = detailed_connection.get("type")
            connection_runtime_env_id = detailed_connection.get("runtimeEnvironmentId")
            compute_engine_runtime_env_id = self._compute_engine._config[
                "runtime_env_id"
            ]
            if (
                (self._iics_name == connector_type) or (self._iics_name in type)
            ) and connection_runtime_env_id == compute_engine_runtime_env_id:
                connections.append(detailed_connection.get("name"))
        return connections

    def _is_connection_present(self, connection_name: str) -> bool:
        """
        Check if connection is already present
        """
        connections = self.list_connections()
        if connection_name in connections:
            return True
        return False

    @staticmethod
    def _get_connection_id(connection_name: str) -> str:
        """Get connection id of given connection name

        Parameters
        ----------
        connection_name : str
            Name of connection whose id is required.

        Returns
        -------
        str
            conection id
        """
        resp = iics_api.get_connection_details(connection_name)
        conn_details = resp.json()
        connection_id = conn_details["id"]
        return connection_id

    def __str__(self) -> str:
        return f"DataSource object of {self._infacore_name}"


@log_activity
def list_data_sources() -> list[str]:
    """
    Lists the available data sources to extract or load data.

    Returns
    -------
    list[str]
        A list of data source names.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> ic.list_data_sources()
    """
    infacore_datasources = [ids.value[1] for ids in InfacoreDataSources]
    licensed_datasources = _list_licensed_datasources()
    _logger.debug("Infacore supported data sources are: %s", infacore_datasources)
    _logger.debug(
        "User has license to following data sources: %s", licensed_datasources
    )
    common_datasources = [i for i in infacore_datasources if i in licensed_datasources]

    common_datasources = common_datasources + NATIVE_DATASOURCES

    datasources = []
    infacore_ds_details = [ids.value for ids in InfacoreDataSources]
    for ids in infacore_ds_details:
        if ids[1] in common_datasources:
            datasources.append(ids[0])

    return datasources


@log_activity
def get_data_source(datasource_name: str) -> DataSource:
    """
    Fetches the data source object for the data source name you specified.

    Parameters
    ----------
    datasource_name : str
        The name of the data source for which you want to extract or load data.

    Returns
    -------
    DataSource
        Object of class DataSource.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> ic.get_data_source("Oracle")

    Raises
    ------
    ValueError
        A ValueError if you specified an unsupported data source name.
    """
    datasources = list_data_sources()
    if datasource_name in datasources:
        iics_name: str = ""
        for ids in InfacoreDataSources:
            if ids.value[0] == datasource_name:
                iics_name = ids.value[1]
                iics_type = ids.value[2]
                break
        compute_engine = get_compute_engine()
        return DataSource(datasource_name, iics_name, iics_type, compute_engine)
    else:
        raise ValueError("Unsupported data source value provided.")


@log_activity
def get_compute_engine() -> ComputeEngine:
    """
    Fetches the compute engine object, and allows you to manage operations such as to start or stop the engine.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> ic.get_compute_engine()

    Returns
    -------
    ComputeEngine
        Object of class ComputeEngine.
    """
    if is_compute_engine_installed():
        org_id = get_org_id()
        compute_engine_type = get_compute_engine_type()
        runtime_env_id = get_runtime_env_id()
        runtime_env_name = get_runtime_env_name()
        config = {
            "org_id": org_id,
            "runtime_env_id": runtime_env_id,
            "runtime_env_name": runtime_env_name,
        }
        compute_engine = ComputeEngineFactory.build_compute_engine(
            compute_engine_type, config
        )
        return compute_engine
    else:
        raise ValueError("Mandatory compute engine setup not performed.")


def _list_licensed_datasources() -> list:
    """
    Returns list of licensed data sources.
    """
    resp = iics_api.get_connectors()
    ds_details = resp.json()
    licensed_data_sources = []
    for data_source in ds_details:
        licensed_data_sources.append(data_source.get("name"))
    return licensed_data_sources
