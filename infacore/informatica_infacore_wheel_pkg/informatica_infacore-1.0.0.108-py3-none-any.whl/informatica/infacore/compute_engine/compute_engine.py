#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
from abc import ABC, abstractmethod


class ComputeEngine(ABC):
    """
    Base class for ComputeEngine.

    ComputeEngine is logical abstraction for runtime environment where data is processed.
    Main functionalities of compute engine are -
        setup()
        config()
        get_status()
        start()
        stop()
    """

    @abstractmethod
    def __init__(self, type: str, config: dict) -> None:
        pass

    @abstractmethod
    def setup(self):
        """Performs the compute engine setup."""
        pass

    @abstractmethod
    def config(self):
        """Returns compute engine details."""
        pass

    @abstractmethod
    def start(self):
        """Starts the compute engine."""
        pass

    @abstractmethod
    def stop(self):
        """Stops the compute engine."""
        pass

    @abstractmethod
    def get_status(self) -> str:
        """Returns status of the compute engine."""
        pass
