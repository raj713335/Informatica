#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import time
import subprocess
import sys
import pathlib
from informatica.infacore.common.decorators import log_activity

from informatica.infacore.compute_engine.compute_engine import ComputeEngine
from informatica.infacore.common.constants import (
    INFACORE_CONFIG_FILE,
    ComputeEngineStatus,
    InfacoreDataSources,
)
from informatica.infacore.internal.error_message import InfacoreClientErrorMessages
from informatica.infacore.internal.http_client import download_file
import informatica.infacore.internal.logger as logger
import informatica.infacore.common.iics_rest_api as iics_api
from informatica.infacore.internal.toml_utils import (
    dump_infacore_config,
    load_infacore_config,
)
from informatica.infacore.internal.utils import (
    get_agent_id,
    get_agent_name,
    get_compute_engine_type,
    get_host_name,
    get_runtime_env_id,
    get_runtime_env_name,
    get_username,
    is_compute_engine_installed,
)
from informatica.infacore.internal.utils import get_os_name

_logger = logger.get_logger(__name__)


class LocalComputeEngine(ComputeEngine):
    """
    Represents the compute engine installed locally on the machine where the INFACore library is installed.
    The compute engine is the runtime environment where data is processed.
    The compute engine that installs locally is also called the Informatica Secure Agent.
    """

    def __init__(self, type: str, config: dict) -> None:
        self._type = type
        self._config = config
        self._download_url = ""
        self._install_token = ""
        self._checksum_url = ""

    @log_activity
    def setup(self):
        """
        Sets up the compute engine locally.

        As part of the set up, INFACore performs the following operations:
            1. Fetches the download URL of the compute engine installer file and the secure token details to perform the installation.
            2. Downloads the agent installer from the Point of Deployment (POD).
            3. Installs the agent.
            4. Registers the agent with the logged-in user details.
            5. Enables all the INFACore data sources and the Data Integration Service.
            6. Polls the agent till the status changes to up and running.
        """
        install = self._config["install"]
        if install:
            self._get_installer_details()
            self._download_agent()
            self._install_agent()
            self._register_agent()
            self._enable_connectors()  # When DIS is not enabled readyToRun flag will not be true, hence enabling DIS prior to agent status
            self._get_agent_status()
        else:
            self._enable_connectors()
        self._save_agent_details()
        _logger.info("Compute engine setup completed successfully.")

    @log_activity
    def config(self):
        """
        Returns details of the compute engine installed locally.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> local_ce = ic.get_compute_engine()
        >>> local_ce.config()
        """
        compute_engine_config = {
            "Compute Engine Type:": get_compute_engine_type(),
            "Runtime Environment Name:": get_runtime_env_name(),
            "Runtime Environment Id:": get_runtime_env_id(),
            "Secure Agent Name:": get_agent_name(),
            "Secure Agent Id:": get_agent_id(),
        }
        return compute_engine_config

    @log_activity
    def get_status(self) -> str:
        """
        Fetches the current status of the local compute engine.

        Returns
        -------
        str
            The status of the local compute engine. The function returns "NOT INSTALLED", "RUNNING," or "STOPPED".

        Example
        -------
        >>> import informatica.infacore as ic
        >>> local_ce = ic.get_compute_engine()
        >>> local_ce.get_status()
        """
        if is_compute_engine_installed():
            agent_name = get_agent_name()
            resp = iics_api.get_agent_details(agent_name)
            resp_dict = resp.json()
            is_ready_to_run = resp_dict["readyToRun"]
            if is_ready_to_run == False:
                return ComputeEngineStatus.STOPPED.value
            else:
                return ComputeEngineStatus.RUNNING.value
        else:
            return ComputeEngineStatus.NOT_INSTALLED.value

    @log_activity
    def start(self):
        """
        Starts the local compute engine.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> local_ce = ic.get_compute_engine()
        >>> local_ce.start()
        """
        if self.get_status() == ComputeEngineStatus.RUNNING.value:
            _logger.info("Compute engine is already in running state.")
            return
        os_name = get_os_name()
        if os_name == "Windows":
            subprocess.run(
                ["net", "start", "InformaticaCloudSecureAgent"],
                shell=True,
            )
        elif os_name == "Linux":
            subprocess.run(
                ["./infaagent.sh", "startup"],
                cwd=str(pathlib.Path.home()) + "/infaagent/apps/agentcore",
                shell=False,
            )
        time.sleep(15.0)
        while self.get_status() != ComputeEngineStatus.RUNNING.value:
            _logger.info("Compute engine starting up.")
            time.sleep(60)
        _logger.info("Compute engine started.")

    @log_activity
    def stop(self):
        """
        Stops the local compute engine.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> local_ce = ic.get_compute_engine()
        >>> local_ce.stop()
        """
        if self.get_status() == ComputeEngineStatus.STOPPED.value:
            _logger.info("Compute engine is already in stopped state.")
            return
        os_name = get_os_name()
        if os_name == "Windows":
            subprocess.run(
                ["net", "stop", "InformaticaCloudSecureAgent"],
                shell=True,
            )
        elif os_name == "Linux":
            subprocess.run(
                ["./infaagent.sh", "shutdown"],
                cwd=str(pathlib.Path.home()) + "/infaagent/apps/agentcore",
                shell=False,
            )
        time.sleep(15.0)
        while self.get_status() != ComputeEngineStatus.STOPPED.value:
            _logger.info("Compute engine shutting down.")
            time.sleep(60)
        _logger.info("Compute engine stopped.")

    def _enable_connectors(self):
        """
        Enable DIS and all the infacore connectors.
        """
        try:
            runtime_env_name = get_host_name()
            runtime_env_id, agent_id = self._get_agent_details(runtime_env_name)
            selections_resp = iics_api.get_runtime_env_details(
                runtime_env_id + "/selections/details"
            )
            if selections_resp.ok:
                response = selections_resp.json()
                services = response.get("services", {}).get("selections", {})
                update_selection_req = False
                for service in services:
                    service_name = service.get("name")
                    is_service_disabled = not service.get("enabled")
                    if (
                        service_name in ["Data Integration", "Data Quality"]
                        and is_service_disabled
                    ):
                        service["enabled"] = True
                        update_selection_req = True
                infacore_datasources = set()
                for ids in InfacoreDataSources:
                    infacore_datasources.add(ids.value[1])

                # Selections API will return connectors with display name only. So we are calling, connectors API to get INFAcore connectors display name
                licensed_connectors = iics_api.get_connectors().json()
                connector_display_names = set()
                for connector in licensed_connectors:
                    if connector.get("name") in infacore_datasources:
                        connector_display_names.add(connector.get("displayName"))

                connectors = response.get("connectors", {}).get("selections", {})
                for connector in connectors:
                    if (
                        connector.get("name") in connector_display_names
                        and connector.get("enabled") == False
                    ):
                        connector["enabled"] = True
                        update_selection_req = True

                if update_selection_req:
                    iics_api.update_selections(runtime_env_id + "/selections", response)
                    _logger.info(
                        "Data Integration Service and INFACore Data Sources (detailed list can be found at https://onlinehelp.informatica.com/IICS/prod/infacore/en/index.htm#page/ff-connections/Connections_to_source_and_target_endpoints.html ) are enabled successfully for this compute engine"
                    )
                else:
                    _logger.info(
                        "INFACore Data Sources and Data Integration Service are already enabled for this compute engine"
                    )
                self._get_service_status("Data_Integration_Server", agent_id)
        except Exception as e:
            _logger.exception("Exception while enabling connectors, %s", str(e))

    def _get_installer_details(self):
        os_name = get_os_name()
        if os_name == "Windows":
            platform = "win64"
        elif os_name == "Linux":
            platform = "linux64"
        resp = iics_api.get_installer_info(platform)
        self._download_url = resp.json()["downloadUrl"]
        self._install_token = resp.json()["installToken"]
        self._checksum_url = resp.json()["checksumDownloadUrl"]

    def _download_agent(self):
        _logger.info("Starting compute engine installer download.")
        os_name = get_os_name()
        if os_name == "Windows":
            filename = "agent64_install_ng_ext.exe"
        elif os_name == "Linux":
            filename = "agent64_install_ng_ext.bin"
        with open(filename, "wb") as f:
            _logger.info("Downloading %s", filename)
            response = download_file(self._download_url)
            total_length = response.headers.get("content-length")
            if total_length is None:  # no content length header
                f.write(response.content)
            else:
                dl = 0
                total_length = int(total_length)
                for data in response.iter_content(chunk_size=4096):
                    dl += len(data)
                    f.write(data)
                    done = int(50 * dl / total_length)
                    sys.stdout.write("\r[%s%s]" % ("=" * done, " " * (50 - done)))
                    sys.stdout.flush()
        print()
        _logger.info("Completed compute engine installer download.")

    def _install_agent(self):
        _logger.info("Starting compute engine installation.")
        os_name = get_os_name()
        if os_name == "Windows":
            subprocess.run(
                [
                    "agent64_install_ng_ext.exe",
                    "-i",
                    "silent",
                    "-DUSER_INSTALL_DIR=C:\Program Files\Informatica Cloud Secure Agent",
                ],
                shell=True,
            )
        elif os_name == "Linux":
            subprocess.run(["chmod", "+x", "agent64_install_ng_ext.bin"])
            installation_path = (
                "-DUSER_INSTALL_DIR=" + str(pathlib.Path.home()) + "/infaagent"
            )
            subprocess.run(
                [
                    "./agent64_install_ng_ext.bin",
                    "-i",
                    "silent",
                    installation_path,
                ]
            )
        _logger.info("Completed compute engine installation.")

    def _register_agent(self):
        _logger.info("Starting compute engine registration.")
        os_name = get_os_name()
        username = get_username()
        installation_token = self._install_token
        if os_name == "Windows":
            time.sleep(30.0)
            subprocess.run(
                [
                    "consoleAgentManager.bat",
                    "configureToken",
                    username,
                    installation_token,
                ],
                shell=True,
                cwd="C:/Program Files/Informatica Cloud Secure Agent/apps/agentcore",
            )
        elif os_name == "Linux":
            subprocess.run(
                ["./infaagent.sh", "startup"],
                cwd=str(pathlib.Path.home()) + "/infaagent/apps/agentcore",
            )
            time.sleep(30.0)
            subprocess.run(
                [
                    "./consoleAgentManager.sh",
                    "configureToken",
                    username,
                    installation_token,
                ],
                cwd=str(pathlib.Path.home()) + "/infaagent/apps/agentcore",
            )
        _logger.info("Completed compute engine registration.")

    def _get_agent_status(self):
        MAX_WAIT_TIME = 3600.0  # 60 mins
        agent_name = get_host_name()
        runtime = 0.0
        while True:
            resp = iics_api.get_agent_details(agent_name)
            resp_dict = resp.json()
            is_ready_to_run = resp_dict["readyToRun"]
            if is_ready_to_run == True:
                _logger.info("Compute engine started.")
                break
            else:
                _logger.info("Compute engine starting.")
                runtime += 60.0
                time.sleep(60.0)
                if runtime >= MAX_WAIT_TIME:
                    raise ValueError(
                        "Compute engine didnt start. Please contact Informatica global customer support."
                    )

    def _save_agent_details(self):
        runtime_env_id, agent_id = self._get_agent_details(get_host_name())

        ic_config = load_infacore_config()
        ic_config["compute_engine"]["type"] = self._type
        ic_config["compute_engine"]["runtime_env_name"] = get_host_name()
        ic_config["compute_engine"]["runtime_env_id"] = runtime_env_id
        ic_config["compute_engine"]["agent_id"] = agent_id
        ic_config["compute_engine"]["agent_name"] = get_host_name()

        dump_infacore_config(ic_config)

    def _get_agent_details(self, agent_name: str):
        runtime_env_id = ""
        agent_id = ""
        resp = iics_api.get_agent_details(agent_name)
        agent_details = resp.json()
        runtime_env_id = agent_details["agentGroupId"]
        agent_id = agent_details["id"]
        return runtime_env_id, agent_id

    def _get_service_status(self, service_name: str, runtime_env_id: str):
        """
        Check the DIS service status.
        We will check the latest dis version and then check, status and desiredStatus is running
        """
        MAX_WAIT_TIME = 3600.0  # 60 mins
        runtime = 0.0
        while True:
            resp = iics_api.get_agent_service_details(runtime_env_id)
            resp = resp.json()
            latest_service_status = None
            latest_version = tuple("0.0.0".split("."))
            for service in resp.get("agentEngines", []):
                service_status = service.get("agentEngineStatus")
                if service_status.get("appname") == service_name:
                    current_version = tuple(service_status.get("appversion").split("."))
                    if current_version > latest_version:
                        latest_version = current_version
                        latest_service_status = service_status

            if (
                latest_service_status.get("desiredStatus") == "RUNNING"
                and latest_service_status.get("status") == "RUNNING"
            ):
                _logger.info(latest_service_status.get("appDisplayName") + " started.")
                break
            else:
                _logger.info(latest_service_status.get("appDisplayName") + " starting.")
            runtime += 60.0
            time.sleep(60.0)
            if runtime >= MAX_WAIT_TIME:
                raise ValueError(
                    "Data Integration Service not starting. Please contact Informatica global customer support."
                )
