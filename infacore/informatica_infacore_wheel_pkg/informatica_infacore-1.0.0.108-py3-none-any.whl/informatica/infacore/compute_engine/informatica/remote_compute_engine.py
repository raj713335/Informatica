#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import time
from informatica.infacore.common.decorators import log_activity

import informatica.infacore.common.iics_rest_api as iics_api
from informatica.infacore.compute_engine.compute_engine import ComputeEngine
import informatica.infacore.internal.logger as logger
from informatica.infacore.common.constants import (
    ComputeEngineStatus,
    InfacoreDataSources,
)
from informatica.infacore.internal.error_message import InfacoreClientErrorMessages
from informatica.infacore.internal.toml_utils import (
    dump_infacore_config,
    load_infacore_config,
)
from informatica.infacore.internal.utils import (
    get_agent_id,
    get_agent_name,
    get_compute_engine_type,
    get_runtime_env_id,
    get_runtime_env_name,
    is_compute_engine_installed,
)

_logger = logger.get_logger(__name__)


class RemoteComputeEngine(ComputeEngine):
    """
    Representation of the compute engine installed in a remote machine.
    """

    def __init__(self, type: str, config: dict) -> None:
        self._type = type
        self._config = config

    @log_activity
    def setup(self):
        """Sets up the remote compute engine.

        As part of the set up, INFACore performs the following operations:
            1. Enables all the INFACore data sources and the Data Integration Service.
            2. Polls the agent till the status changes to up and running.
        """
        self._enable_connectors()
        self._save_agent_details()
        _logger.info("Compute engine setup completed successfully.")

    @log_activity
    def config(self):
        """
        Returns the remote compute engine details.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> remote_ce = ic.get_compute_engine()
        >>> remote_ce.config()
        """
        compute_engine_config = {
            "Compute Engine Type:": get_compute_engine_type(),
            "Runtime Environment Name:": get_runtime_env_name(),
            "Runtime Environment Id:": get_runtime_env_id(),
            "Secure Agent Name:": get_agent_name(),
            "Secure Agent Id:": get_agent_id(),
        }
        return compute_engine_config

    @log_activity
    def get_status(self) -> str:
        """
        Fetches the current state of the remote compute engine.

        Returns
        -------
        str
            One of three values "NOT INSTALLED",  "RUNNING", or  "STOPPED".


        Example
        -------
        >>> import informatica.infacore as ic
        >>> remote_ce = ic.get_compute_engine()
        >>> remote_ce.get_status()
        """
        if is_compute_engine_installed():
            agent_name = get_agent_name()
            resp = iics_api.get_agent_details(agent_name)
            resp_dict = resp.json()
            is_ready_to_run = resp_dict["readyToRun"]
            if is_ready_to_run == False:
                return ComputeEngineStatus.STOPPED.value
            else:
                return ComputeEngineStatus.RUNNING.value
        else:
            return ComputeEngineStatus.NOT_INSTALLED.value

    @log_activity
    def start(self):
        """
        Starts the Data Integration Service of the remote compute engine.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> remote_ce = ic.get_compute_engine()
        >>> remote_ce.start()
        """
        agent_id = get_agent_id()
        iics_api.perform_agent_service("Data Integration Server", "start", agent_id)
        while self.get_status() != ComputeEngineStatus.RUNNING.value:
            time.sleep(60)
            _logger.info("Compute engine starting up.")
        _logger.info("Compute engine started.")

    @log_activity
    def stop(self):
        """
        Stops the Data Integration Service of the remote compute engine.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> local_ce = ic.get_compute_engine()
        >>> local_ce.stop()
        """
        agent_id = get_agent_id()
        iics_api.perform_agent_service("Data Integration Server", "stop", agent_id)
        while self.get_status() != ComputeEngineStatus.STOPPED.value:
            _logger.info("Compute engine shutting down.")
            time.sleep(60)
        _logger.info("Compute engine stopped.")

    def _enable_connectors(self):
        """
        Enable DIS and all the infacore connectors for the given runtime_env_id.
        """
        try:
            runtime_env_id = self._config["runtime_env_id"]
            agent_id = self._config["agent_id"]
            selections_resp = iics_api.get_runtime_env_details(
                runtime_env_id + "/selections/details"
            )
            if selections_resp.ok:
                response = selections_resp.json()
                services = response.get("services", {}).get("selections", {})
                update_selection_req = False
                for service in services:
                    service_name = service.get("name")
                    is_service_disabled = not service.get("enabled")
                    if (
                        service_name in ["Data Integration", "Data Quality"]
                        and is_service_disabled
                    ):
                        service["enabled"] = True
                        update_selection_req = True
                infacore_datasources = set()
                for ids in InfacoreDataSources:
                    infacore_datasources.add(ids.value[1])

                # Selections API will return connectors with display name only. So we are calling, connectors API to get INFAcore connectors display name
                licensed_connectors = iics_api.get_connectors().json()
                connector_display_names = set()
                for connector in licensed_connectors:
                    if connector.get("name") in infacore_datasources:
                        connector_display_names.add(connector.get("displayName"))

                connectors = response.get("connectors", {}).get("selections", {})
                for connector in connectors:
                    if (
                        connector.get("name") in connector_display_names
                        and connector.get("enabled") == False
                    ):
                        connector["enabled"] = True
                        update_selection_req = True

                if update_selection_req:
                    iics_api.update_selections(runtime_env_id + "/selections", response)
                    _logger.info(
                        "Data Integration Service and INFACore Data Sources (detailed list can be found at https://onlinehelp.informatica.com/IICS/prod/infacore/en/index.htm#page/ff-connections/Connections_to_source_and_target_endpoints.html ) are enabled successfully for this compute engine"
                    )
                else:
                    _logger.info(
                        "INFACore Data Sources and Data Integration service are already enabled for this compute engine"
                    )
                self._get_service_status("Data_Integration_Server", agent_id)
        except Exception as e:
            _logger.exception("Exception while enabling connectors, %s", str(e))

    def _save_agent_details(self):
        """_summary_"""
        ic_config = load_infacore_config()
        ic_config["compute_engine"]["type"] = self._type
        ic_config["compute_engine"]["runtime_env_name"] = self._config.get(
            "runtime_env_name"
        )
        ic_config["compute_engine"]["runtime_env_id"] = self._config.get(
            "runtime_env_id"
        )
        ic_config["compute_engine"]["agent_id"] = self._config.get("agent_id")
        ic_config["compute_engine"]["agent_name"] = self._config.get("agent_name")
        dump_infacore_config(ic_config)

    def _get_service_status(self, service_name: str, runtime_env_id: str):
        """
        Check the DIS service status.
        We will check the latest dis version and then check, status and desiredStatus is running
        """
        MAX_WAIT_TIME = 3600.0  # 60 mins
        runtime = 0.0
        while True:
            resp = iics_api.get_agent_service_details(runtime_env_id)
            resp = resp.json()
            latest_service_status = None
            latest_version = tuple("0.0.0".split("."))
            for service in resp.get("agentEngines", []):
                service_status = service.get("agentEngineStatus")
                if service_status.get("appname") == service_name:
                    current_version = tuple(service_status.get("appversion").split("."))
                    if current_version > latest_version:
                        latest_version = current_version
                        latest_service_status = service_status

            if (
                latest_service_status.get("desiredStatus") == "RUNNING"
                and latest_service_status.get("status") == "RUNNING"
            ):
                _logger.info(latest_service_status.get("appDisplayName") + " started.")
                break
            else:
                _logger.info(latest_service_status.get("appDisplayName") + " starting.")
            runtime += 60.0
            time.sleep(60.0)
            if runtime >= MAX_WAIT_TIME:
                raise ValueError(
                    "Data Integration Service not starting. Please contact Informatica global customer support."
                )
