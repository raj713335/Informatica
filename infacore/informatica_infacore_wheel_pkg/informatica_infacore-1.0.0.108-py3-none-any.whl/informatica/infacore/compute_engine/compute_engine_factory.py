#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
from informatica.infacore.compute_engine.informatica.local_compute_engine import (
    LocalComputeEngine,
)
from informatica.infacore.compute_engine.informatica.remote_compute_engine import (
    RemoteComputeEngine,
)
from informatica.infacore.common.constants import ComputeEngineType
import informatica.infacore.internal.logger as logger

_logger = logger.get_logger(__name__)


class ComputeEngineFactory:
    """Factory class for creating compute engine object based on type."""

    @staticmethod
    def build_compute_engine(type, config):
        try:
            if type == ComputeEngineType.LOCAL.value:
                return LocalComputeEngine(type, config)
            elif type == ComputeEngineType.REMOTE.value:
                return RemoteComputeEngine(type, config)
            raise AssertionError("Compute Engine type is not valid.")
        except AssertionError as e:
            _logger.error(e)
