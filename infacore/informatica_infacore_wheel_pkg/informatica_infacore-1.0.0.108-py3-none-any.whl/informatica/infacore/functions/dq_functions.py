#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
from informatica.infacore.common.decorators import log_activity
from informatica.infacore.dataframe.dataobject import DataObject
from informatica.infacore.common.template_executor import execute_template
from informatica.infacore.internal.utils import (
    construct_payload,
    generate_random_name,
    get_agent_id,
    get_mapping_id,
    get_org_id,
    get_project_id,
    get_runtime_env_id,
    get_staging_type,
    sanitize_col_name,
)
from informatica.infacore.staging.staging import Staging
from informatica.infacore.staging.staging_factory import StagingFactory


class DataQualityFunctions:
    """
    Exposes functions to analyze, validate, and improve the quality of your data.

    You can use this class to eliminate duplicate and redundant records,
    verify addresses, and standardize operations on your business data.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> dq_obj = ic.DataQualityFunctions()
    >>> dq_obj.get_country_iso_values(src_data_obj, country_col_name)
    """

    def __init__(self) -> None:
        pass

    @log_activity
    def get_country_iso_values(
        self, src_data_object: DataObject, country_col_name: str
    ):
        """
        Reads a country name as input and returns
        the full ISO country name,
        the ISO three-letter country code,
        and the ISO two-letter country code.

        Parameters
        ----------
        src_data_object : DataObject
            The object name for the source DataObject class.
        country_col_name : str
            The column name that contains the country names.

        Returns
        -------
        table
            ISO data represented in columnar format.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> dq_obj = ic.DataQualityFunctions()
        >>> dq_obj.get_country_iso_values(src_data_obj, country_col_name)
        """
        mapping_id = get_mapping_id("infacore_get_country_iso_values_id")
        return self._execute_generic_dq_mapping(
            src_data_object,
            country_col_name,
            mapping_id,
            "Retrieval of country ISO values failed.",
        )

    @log_activity
    def validate_email_address(self, src_data_object: DataObject, email_col_name: str):
        """
        Validates the email format.
        This function  does not check if the email is an active address.

        Parameters
        ----------
        src_data_object : DataObject
            The object name for the source DataObject class.
        email_col_name : str
            Column name corresponding to email address.

        Returns
        -------
        table
            The validation status "Valid" or "Invalid" for the email address in columnar representation.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> dq_obj = ic.DataQualityFunctions()
        >>> dq_obj.validate_email_address(src_data_obj, email_col_name)
        """
        mapping_id = get_mapping_id("infacore_validate_email_address_id")
        return self._execute_generic_dq_mapping(
            src_data_object,
            email_col_name,
            mapping_id,
            "Validation of email address failed.",
        )

    @log_activity
    def find_invalid_names(self, src_data_object: DataObject, name_col_name: str):
        """
        Flags suspicious or fake names in the input data.

        Parameters
        ----------
        src_data_object : DataObject
            The object name for the source DataObject class.
        name_col_name : str
            The column name to represent the name.

        Returns
        -------
        table
            Data with fake names.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> dq_obj = ic.DataQualityFunctions()
        >>> dq_obj.find_invalid_names(src_data_obj, name_col_name)
        """
        mapping_id = get_mapping_id("infacore_find_invalid_names_id")
        return self._execute_generic_dq_mapping(
            src_data_object,
            name_col_name,
            mapping_id,
            "Finding invalid names failed.",
        )

    @log_activity
    def remove_control_characters(self, src_data_object: DataObject, col_name: str):
        """
        Identifies and removes non-printable characters in an input field.

        Parameters
        ----------
        src_data_object : DataObject
            The object name for the source DataObject class.
        col_name : str
            Column name for which you want to remove control characters.

        Returns
        -------
        table
            Columnar data with control characters removed.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> dq_obj = ic.DataQualityFunctions()
        >>> dq_obj.remove_control_characters(src_data_obj, col_name)
        """
        mapping_id = get_mapping_id("infacore_remove_control_characters_id")
        return self._execute_generic_dq_mapping(
            src_data_object,
            col_name,
            mapping_id,
            "Removal of control characters failed.",
        )

    @log_activity
    def convert_diacritic_english_chars(
        self, src_data_object: DataObject, col_name: str
    ):
        """
        Translates diacritical characters to regular ASCII text characters.
        For example, to return tëst as test, it changes the ë to e.

        Parameters
        ----------
        src_data_object : DataObject
            The object name for the source DataObject class.
        col_name : str
            The name of the column that contains diacritic characters which you want to convert to a regular ASCII character.

        Returns
        -------
        table
            Data converted from diacritic to ASCII characters.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> dq_obj = ic.DataQualityFunctions()
        >>> dq_obj.convert_diacritic_english_chars(src_data_obj, col_name)
        """
        mapping_id = get_mapping_id("infacore_convert_diacritic_english_chars_id")
        return self._execute_generic_dq_mapping(
            src_data_object,
            col_name,
            mapping_id,
            "Conversion of diacritic english chars failed.",
        )

    @log_activity
    def validate_usa_zipcode(
        self,
        src_data_object: DataObject,
        zipcode_col_name: str,
    ):
        """
        Validates if the input column data is a five-digit United States zip code.

        Parameters
        ----------
        src_data_object : DataObject
            The object name for the source DataObject class.
        zipcode_col_name : str
            Column name corresponding to United States zip code.

        Returns
        -------
        table
            The validation status "Valid" or "Invalid" for the zip code values in columnar representation.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> dq_obj = ic.DataQualityFunctions()
        >>> dq_obj.validate_usa_zipcode(src_data_obj, zipcode_col_name)
        """
        mapping_id = get_mapping_id("infacore_validate_usa_zipcode_id")
        return self._execute_generic_dq_mapping(
            src_data_object,
            zipcode_col_name,
            mapping_id,
            "Validation of USA zipcodes failed.",
        )

    @log_activity
    def validate_usa_state(self, src_data_object: DataObject, state_col_name: str):
        """
        Validates if the input column data is a state name in the United States.

        Parameters
        ----------
        src_data_object : DataObject
            The object name for the source DataObject class.
        state_col_name : str
            The column name corresponding to the state name in the United States.

        Returns
        -------
        table
            Validation values "Valid" or "Invalid" for the state name in columnar representation.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> dq_obj = ic.DataQualityFunctions()
        >>> dq_obj.validate_usa_state(src_data_obj, state_col_name)
        """
        mapping_id = get_mapping_id("infacore_validate_usa_state_id")
        return self._execute_generic_dq_mapping(
            src_data_object,
            state_col_name,
            mapping_id,
            "Validation of USA states failed.",
        )

    @log_activity
    def validate_ssn(self, src_data_object: DataObject, ssn_col_name: str):
        """
        Parses a United States SSN pattern from a larger string of text.
        This function parses SSNs with dashes or without dashes.
        It also formats and validates the SSN.

        Parameters
        ----------
        src_data_object : DataObject
            The object name for the source DataObject class.
        ssn_col_name : str
            Column name corresponding to the SSN number.

        Returns
        -------
        table
            Validation values "Valid" or "Invalid" for the SSN number in columnar representation.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> dq_obj = ic.DataQualityFunctions()
        >>> dq_obj.validate_ssn(src_data_obj, ssn_col_name)
        """
        mapping_id = get_mapping_id("infacore_validate_ssn_id")
        return self._execute_generic_dq_mapping(
            src_data_object,
            ssn_col_name,
            mapping_id,
            "Validation of SSN failed.",
        )

    @log_activity
    def validate_usa_phone_number(
        self, src_data_object: DataObject, phone_col_name: str
    ):
        """
        Parses the United States phone number from a string of text and validates if the area code is valid for the United States.

        Parameters
        ----------
        src_data_object : DataObject
            The object name for the source DataObject class.
        phone_col_name : str
            Column name corresponding to the USA phone number.

        Returns
        -------
        table
            Validation values "Valid" or "Invalid" and a status description for the United States phone number in columnar representation.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> dq_obj = ic.DataQualityFunctions()
        >>> dq_obj.validate_usa_phone_number(src_data_obj, phone_col_name)
        """
        mapping_id = get_mapping_id("infacore_validate_usa_phone_number_id")
        return self._execute_generic_dq_mapping(
            src_data_object,
            phone_col_name,
            mapping_id,
            "Validation of USA phone number failed.",
        )

    @log_activity
    def parse_name(
        self,
        src_data_object: DataObject,
        firstname_col_name: str,
        surname_col_name: str,
        gender_col_name: str,
    ):
        """
        Determines the gender status.If you know the gender for a specified name, the rule determines the status based on the gender-specific score.
        Acceptable inputs for male and female genders are M and F.
        If the gender is unknown, the rule determines the status based on the highest of the male or female scores.

        The rule also calculates the probable gender based on the first name input and provides a confidence score
        based on the frequency that a name occurs as male or female.
        Genders are only assigned a score if the probability of the gender being either male or female is 70% or more.
        Unknown genders always have a confidence score of zero.

        Parameters
        ----------
        src_data_object : DataObject
            The object name for the source DataObject class.
        firstname_col_name : str
            The name of the firstname column.
        surname_col_name : str
            The column name that contains the surnames.
        gender_col_name : str
            The name of the gender column.

        Returns
        -------
        table
            The gender probability data in columnar representation.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> dq_obj = ic.DataQualityFunctions()
        >>> dq_obj.parse_name(src_data_obj, firstname_col_name, surname_col_name, gender_col_name)
        """
        mapping_id = get_mapping_id("infacore_parse_name_id")
        source_payload, param_values, target_staging_object = self._get_param_values(
            src_data_object, mapping_id, firstname_col_name
        )
        param_values["expr_col_name_2"] = sanitize_col_name(surname_col_name)
        param_values["expr_col_name_3"] = sanitize_col_name(gender_col_name)
        payload = construct_payload("dq_parse_name_template.json", param_values)
        self._set_dfc_config(payload)
        payload["parameters"].append(source_payload)
        table = execute_template(
            payload,
            "read_staging",
            target_staging_object,
            "Parsing name failed.",
        )
        return table

    @log_activity
    def validate_us_county(self, src_data_object: DataObject, county_col_name: str):
        """
        Checks if the input column data is a valid county name in any state in the Unites States.

        Parameters
        ----------
        src_data_object : DataObject
            The object name for the source DataObject class.
        county_col_name : str
            Column name corresponding to the USA county name.

        Returns
        -------
        table
            Validation values "Valid" or "Invalid" for the United States county name in columnar representation.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> dq_obj = ic.DataQualityFunctions()
        >>> dq_obj.validate_us_county(src_data_obj, county_col_name)
        """
        mapping_id = get_mapping_id("infacore_validate_us_county_id")
        return self._execute_generic_dq_mapping(
            src_data_object,
            county_col_name,
            mapping_id,
            "Validation of US county failed.",
        )

    @log_activity
    def standardize_us_companyname(
        self,
        src_data_object: DataObject,
        companyname_col_name: str,
    ):
        """
        Standardizes a company name and provides an acronym if possible.

        Parameters
        ----------
        src_data_object : DataObject
            The object name for the source DataObject class.
        companyname_col_name : str
            The name of the United States company name column.

        Returns
        -------
        table
            The company standard name and its acronym.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> dq_obj = ic.DataQualityFunctions()
        >>> dq_obj.standardize_us_companyname(src_data_obj, companyname_col_name)
        """
        mapping_id = get_mapping_id("infacore_standardize_us_companyname_id")
        return self._execute_generic_dq_mapping(
            src_data_object,
            companyname_col_name,
            mapping_id,
            "Standardization of US company name failed.",
        )

    def _execute_generic_dq_mapping(
        self,
        src_data_object: DataObject,
        column_name: str,
        mapping_id: str,
        error_message: str,
    ):
        """
        Common mapping execution for all DQ functions with one columns.
        All the four parameters will differ for all DQ functions, but template remains the same.
        """
        source_payload, param_values, target_staging_object = self._get_param_values(
            src_data_object, mapping_id, column_name
        )
        payload = construct_payload("dq_generic_template.json", param_values)
        self._set_dfc_config(payload)
        payload["parameters"].append(source_payload)
        table = execute_template(
            payload,
            "read_staging",
            target_staging_object,
            error_message,
        )
        return table

    def _get_param_values(
        self,
        src_data_object: DataObject,
        mapping_id: str,
        expr_col_name: str,
    ):
        """
        Returns the mapping dict and source payload with advanced config if available
        """
        src_data_object._payload["parameters"] = []
        src_data_object.read()
        source_payload = src_data_object._payload["parameters"][0]
        type = get_staging_type()
        staging_instace: Staging = StagingFactory.get_staging(
            type=type
        ).create_instance()
        tgt_obj_name = staging_instace.get_staging_path()
        tgt_connection_id = staging_instace.get_connection()._connection_id
        sanitized_col_name = sanitize_col_name(expr_col_name)
        param_values = {
            "org_id": get_org_id(),
            "mct_name": generate_random_name("mct"),
            "agent_id": get_agent_id(),
            "runtime_env_id": get_runtime_env_id(),
            "infacore_project_id": get_project_id(),
            "mapping_id": mapping_id,
            "tgt_cnx_id": tgt_connection_id,
            "tgt_obj_name": tgt_obj_name,
            "expr_col_name": sanitized_col_name,
        }

        return source_payload, param_values, staging_instace

    def _set_dfc_config(self, payload):
        type = get_staging_type()
        if type == "Microsoft Fabric OneLake":
            target_param = payload.get("parameters")[0]  # Retrieving TARGET parameter
            dfc = {
                "@type": "dataFormat",
                "formatId": "Parquet",
                "dataFormatAttributes": {},
            }
            target_param["dataFormat"] = dfc
