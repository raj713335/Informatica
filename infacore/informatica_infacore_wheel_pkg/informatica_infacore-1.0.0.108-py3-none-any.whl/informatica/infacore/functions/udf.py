#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
from __future__ import annotations

from functools import partialmethod

from informatica.infacore.common.decorators import log_activity
import informatica.infacore.common.iics_rest_api as iics_api


@log_activity
def list_udfs() -> list[str]:
    """
    Lists the available user-defined functions in your Informatica Intelligent Cloud Service organization.

    Returns
    -------
    list[str]
        A list of user-defined functions.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> ic.list_udfs()
    """
    udfs = []
    mapplets = _list_mapplets()
    for mapplet in mapplets:
        udfs.append(mapplet.get("path"))
    return udfs


@log_activity
def get_udf_details(path: str):
    """
    Lists the details of the specified user-defined function.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> ic.get_udf_details("Default/EmailMask")
    """
    udfs = list_udfs()
    if path in udfs:
        mapplet_id: str = ""
        mapplets = _list_mapplets()
        for mapplet in mapplets:
            if path == mapplet.get("path"):
                mapplet_id = mapplet.get("id")
                break
        saas_mapplet_id = _get_mapplet_saas_id(mapplet_id)
        return _get_mapplet_details(saas_mapplet_id)
    else:
        raise ValueError("Unsupported udf path provided.")

@log_activity
def init_udfs(udf_dict: list[dict]):
    """
    Allows you to specify the alias name for UDFs. Alias names help you to simplify the code snippet for the data pipeline creation.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> udf_conf = [
            {
                "name": "sanitize_currency"
                "path": "Excel/SanitizeAmountValue"
            },
            {
                "name": "remove_trailing_spaces"
                "path": "Cleanse/MappletProdCharRemoveSpaces"
            },
        ]
    >>> ic.init_udfs(udf_conf)
    """
    for udf in udf_dict:
        function_name = udf.get("name")
        path = udf.get("path")
        if not function_name:
            raise ValueError("Please provide name for udf " + str(udf))
        if not path:
            raise ValueError("Please provide path for udf " + str(udf))

    for udf in udf_dict:
        _init_udf(udf.get("name"), udf.get("path"))

def _list_mapplets() -> list:
    """
    Returns list of mapplets.
    """
    all_mapplets = []
    # Paginating to get all mapplets
    # By default we get 200 objects per page
    # Max allowed value for limit is 200
    # Hence paginating only via skip
    skip = 0
    while True:
        query = "&skip=" + str(skip)
        resp = iics_api.get_objects("DMAPPLET", query)
        mapplets = resp.json()["objects"]
        if mapplets:
            all_mapplets.extend(mapplets)
        else:
            break
        skip += 200
    return all_mapplets


def _get_mapplet_saas_id(mapplet_id) -> str:
    """
    Returns mapplet saas id.
    """
    resp = iics_api.get_frs_document(document_id=mapplet_id)
    saa_mapplet_id = resp.json()["repoInfo"]["repoHandle"]
    return saa_mapplet_id


def _get_mapplet_details(saas_mapplet_id) -> str:
    """
    Returns mapplet details
    """
    resp = iics_api.get_mapplet_details(saas_mapplet_id)
    return resp.json()


def _init_udf(udf_name: str, path: str):
    from informatica.infacore.dataframe.dataframe import DataFrame

    method_definition = partialmethod(DataFrame.udf, path=path)
    setattr(DataFrame, udf_name, method_definition)

