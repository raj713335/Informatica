#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import os
import pyarrow as pa
from pyarrow import csv

import informatica.infacore as ic
from informatica.infacore.common.decorators import log_activity
import informatica.infacore.internal.logger as logger
from informatica.infacore.common.template_executor import execute_template
from informatica.infacore.internal.utils import (
    construct_payload,
    generate_random_name,
    get_agent_id,
    get_agent_root_dir,
    get_env_var,
    get_mapping_id,
    get_org_id,
    get_project_id,
    get_runtime_env_id,
    get_runtime_env_name,
    get_tmp_dir,
)


_logger = logger.get_logger(__name__)


class ParserFunctions:
    """
    Exposes functions to parse semi-structured or unstructured data.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> p_func = ic.ParserFunctions()
    >>> p_func.parse_unstructured_data(input_file_path, schema_file_path)
    """

    def __init__(self) -> None:
        pass

    @log_activity
    def parse_unstructured_data(self, input_file_path: str, schema_file_path: str):
        """
        Uses Intelligent Structure Discovery (ISD) to parse semi-structured or unstructured data.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> p_func = ic.ParserFunctions()
        >>> p_func.parse_unstructured_data(input_file_path, schema_file_path)

        """
        ic_classpath = self._construct_classpath()
        ff_cnx_id = self._get_ff_cnx_id()
        org_id = get_org_id()
        agent_id = get_agent_id()
        runtime_env_id = get_runtime_env_id()
        mct_name = generate_random_name("mct")
        infacore_project_id = get_project_id()
        mapping_id = get_mapping_id("infacore_parse_unstructured_data_id")
        src_obj_name = self._get_input_fname(input_file_path, schema_file_path)
        tgt_obj_name = generate_random_name("ff") + ".csv"
        param_values = {
            "org_id": org_id,
            "mct_name": mct_name,
            "agent_id": agent_id,
            "runtime_env_id": runtime_env_id,
            "infacore_project_id": infacore_project_id,
            "mapping_id": mapping_id,
            "ic_classpath": ic_classpath,
            "ff_cnx_id": ff_cnx_id,
            "src_obj_name": src_obj_name,
            "tgt_obj_name": tgt_obj_name,
        }
        payload = construct_payload(
            "isd_parse_unstructured_data_template.json", param_values
        )
        table = execute_template(
            payload,
            "read_csv",
            tgt_obj_name,
            "Parsing unstructured data failed.",
            src_obj_name,
        )
        return table

    def _get_input_fname(self, input_file_path: str, schema_file_path: str):
        input_fname = "isd_input.csv"
        i_file = pa.array([input_file_path])
        s_file = pa.array([schema_file_path])
        table = pa.table([i_file, s_file], names=["Input_file", "Schema_file"])
        tmp_dir = get_tmp_dir()
        if not os.path.exists(tmp_dir):
            os.makedirs(tmp_dir)

        csv.write_csv(table, tmp_dir + input_fname)
        return input_fname

    def _get_ff_cnx_id(self):
        ff_ds = ic.get_data_source("Flat File")
        ff_connections = ff_ds.list_connections()
        runtime_env_name = get_runtime_env_name()
        cnx_name = runtime_env_name + "_" + "FlatFile"
        if cnx_name in ff_connections:
            ff_connection = ff_ds.get_connection(cnx_name)
            return ff_connection._connection_id
        else:
            tmp_dir = get_tmp_dir()
            if not os.path.exists(tmp_dir):
                os.makedirs(tmp_dir)
            ff_payload = {
                "dateFormat": "MM/dd/yyyy HH:mm:ss",
                "dirName": tmp_dir,
                "codePage": "UTF-8",
            }
            ff_connection = ff_ds.connect(cnx_name, ff_payload)
            return ff_connection._connection_id

    def _construct_classpath(self) -> str:
        classpath = ""
        agent_root_dir = get_agent_root_dir()
        isd_jars_dir = (
            agent_root_dir
            + "apps/Data_Integration_Server/ext/deploy_to_main/infacore/isd/"
        )
        for file in os.listdir(isd_jars_dir):
            if file.endswith(".jar"):
                classpath += isd_jars_dir + file + os.pathsep
        return classpath
