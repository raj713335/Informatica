from informatica.infacore.common.constants import StagingType
from informatica.infacore.staging.arrow_staging import ArrowStaging
from informatica.infacore.staging.databricks_delta_staging import DatabricksDeltaStaging
from informatica.infacore.staging.microsoft_fabric_onelake_staging import MicrosoftFabricOneLakeStaging
from informatica.infacore.staging.staging import Staging


class StagingFactory:
    @staticmethod
    def get_staging(type: str) -> Staging:
        staging: Staging = None
        if type == StagingType.DATABRICKS_DETLA.value:
            staging = DatabricksDeltaStaging
        elif type == StagingType.MICROSOFT_FABRIC_ONELAKE.value:
            staging = MicrosoftFabricOneLakeStaging
        else:
            staging = ArrowStaging

        staging.validate()
        return staging
