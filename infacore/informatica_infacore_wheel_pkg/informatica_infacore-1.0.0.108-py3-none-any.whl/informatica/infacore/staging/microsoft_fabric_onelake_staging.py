import os

from informatica.infacore.internal.utils import (
    generate_random_name,
    get_staging_connection_name,
    get_staging_config,
)
from informatica.infacore.staging.staging import Staging
import informatica.infacore as ic


class MicrosoftFabricOneLakeStaging(Staging):
    """
    Microsoft Fabric Onelake is used as staging environment here. This is supported in Microsoft Fabric notebooks.
    """

    def __init__(self, _workspace_name: str, _name: dict, _spark_session) -> None:
        self._workspace_name = _workspace_name
        self._name = _name
        self._spark_session = _spark_session

    @staticmethod
    def create_instance():
        """
        Creates Fabric OneLake object
        """
        from pyspark.sql import SparkSession

        staging_config: dict = get_staging_config()
        _workspace_name = staging_config.get("workspace_name")
        _name = generate_random_name("infacore") + ".parquet"
        _spark_session = SparkSession.builder.getOrCreate()
        return MicrosoftFabricOneLakeStaging(_workspace_name, _name, _spark_session)

    def get_connection(self):
        """
        Returns the configured Fabric OneLake connection object
        """
        onelake_ds = ic.get_data_source("Microsoft Fabric OneLake")
        cnx_name = get_staging_connection_name()
        return onelake_ds.get_connection(cnx_name)

    def get_staging_path(self):
        """
        Get the staging file name
        """
        return self._name

    def read(self):
        """
        Read the data from Fabric OneLake table. Create new dataframe and return it to user.
        """
        spark_df = self._spark_session.read.parquet("Files/" + self._name)
        return spark_df

    def write(self, pandas_df):
        """
        Writes the Data to Fabric OneLake and return data object
        """
        df = self._spark_session.createDataFrame(pandas_df)
        df.write.parquet("Files/" + self._name)
        connection = self.get_connection()
        return connection.get_data_object(self._workspace_name + "/" + self._name)

    def delete(self):
        """Deletes the Parquet file in Fabric OneLake"""
        # We are not acutally delete the file, if we delete the file, we can not do operations.


    @staticmethod
    def validate():
        """It will be called in staging factory, validates the environment before creating staging object"""
        if not get_staging_connection_name():
            raise ValueError("Please Provide Microsoft Fabric OneLake connection name in setup")

    @staticmethod
    def to_pandas(dataframe):
        """Converts staging DF to Pandas DF"""
        return dataframe.toPandas()
