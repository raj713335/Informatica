from abc import ABC, abstractmethod


class Staging(ABC):
    """Base class for all staging classes implementation"""

    @abstractmethod
    def __init__(self) -> None:
        pass

    @staticmethod
    def create_instance():
        """Creats a new stating class instance"""
        pass

    @abstractmethod
    def get_connection(self):
        """Get the connection to perform ecosystem specific operations"""
        pass

    @abstractmethod
    def get_staging_path(self):
        """Get the Staging file name"""
        pass

    @abstractmethod
    def read(self):
        """Read the file created in corresponding ecosytem"""
        pass

    @abstractmethod
    def write(self):
        """Writes the file created in corresponding ecosystem"""
        pass

    @abstractmethod
    def delete(self):
        """Deltes the file"""
        pass

    @staticmethod
    def validate():
        """validate the ecosystem prerequisites"""
        pass

    @staticmethod
    def to_pandas(dataframe):
        """Converts staging DF to Pandas DF"""
        pass
