import os

from informatica.infacore.internal.utils import (
    generate_random_name,
    get_staging_connection_name,
    get_staging_config,
)
from informatica.infacore.staging.staging import Staging
import informatica.infacore as ic


class DatabricksDeltaStaging(Staging):
    """
    Databricks Delta used as staging environment here. This is supported in Delta notebook alone.
    """

    def __init__(
        self, _catalog_name, _database_name: str, _name: dict, _spark_session
    ) -> None:
        self._catalog_name = _catalog_name
        self._database_name = _database_name
        self._name = _name
        self._spark_session = _spark_session

    @staticmethod
    def create_instance():
        """
        Creates Delta object
        """
        from pyspark.sql import SparkSession

        staging_config: dict = get_staging_config()
        _catalog_name = staging_config.get("catalog_name")
        _database_name = staging_config.get("database")
        _name = generate_random_name("infa_table")
        _spark_session = SparkSession.builder.getOrCreate()
        return DatabricksDeltaStaging(
            _catalog_name, _database_name, _name, _spark_session
        )

    def get_connection(self):
        """
        Returns the configured Delta connection object
        """
        delta_ds = ic.get_data_source("Databricks Delta")
        cnx_name = get_staging_connection_name()
        return delta_ds.get_connection(cnx_name)

    def get_staging_path(self):
        """
        Get the staging file name
        """
        return self._name

    def read(self):
        """
        Read the data from delta table. Create new dataframe and return it to user.
        """
        spark_df = self._spark_session.read.table(
            self._catalog_name + "." + self._database_name + "." + self._name
        )
        # schema = spark_df.schema
        # pandas_df = spark_df.toPandas()
        # return self._spark_session.createDataFrame(pandas_df, schema=schema)
        return spark_df

    def write(self, pandas_df):
        """
        Writes the Data to delta and return data object
        """
        df = self._spark_session.createDataFrame(pandas_df)
        if self._catalog_name == "hive_metastore":
            table_name = self._database_name + "." + self._name
        else:
            table_name = self._catalog_name + "." + self._database_name + "." + self._name
        df.write.format("delta").saveAsTable(table_name)
        connection = self.get_connection()
        return connection.get_data_object(self._database_name + "/TABLE/" + self._name)

    def delete(self):
        """deletes the delta table"""
        # We are not acutally delete the file, if we delete the file, we can not do operations on the underlying delta table

        # self._spark_session.sql("drop table " + self._database_name + "." + self._name)

    @staticmethod
    def validate():
        """It will be called in staging factory, validates the environment before creating staging object"""
        if not get_staging_connection_name():
            raise ValueError("Please Provide Databricks connection name in setup")

    @staticmethod
    def to_pandas(dataframe):
        """Converts staging DF to Pandas DF"""
        return dataframe.toPandas()
