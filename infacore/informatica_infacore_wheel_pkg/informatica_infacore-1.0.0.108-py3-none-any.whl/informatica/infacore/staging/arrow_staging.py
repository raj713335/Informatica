import os

import pyarrow as pa
from informatica.infacore.internal.utils import (
    generate_random_name,
    get_staging_connection_name,
    get_tmp_dir,
)
from informatica.infacore.staging.staging import Staging
import informatica.infacore as ic


class ArrowStaging(Staging):
    """
    Arrow connector used as staging, Arrow is supported in local compute engine
    """

    def __init__(self, _dir: str, _name: dict) -> None:
        self._dir = _dir
        self._name = _name

    @staticmethod
    def create_instance():
        """
        Creates staging object
        """
        _dir = get_tmp_dir()
        _name = generate_random_name("arrow") + ".arrow"
        return ArrowStaging(_dir, _name)

    def get_connection(self):
        """
        returns configured arrow connection object
        """
        arrow_ds = ic.get_data_source("Arrow")
        cnx_name = get_staging_connection_name()
        return arrow_ds.get_connection(cnx_name)

    def get_staging_path(self):
        """Get the connection file name"""
        return self._name

    def read(self):
        """Read the arrow file"""
        with pa.OSFile(self._dir + self._name, "rb") as source:
            table = pa.ipc.open_file(source).read_all()
        return table

    def write(self, pandas_df):
        """Creates arrow file and return data object"""
        table = pa.Table.from_pandas(pandas_df)
        schema = pa.Schema.from_pandas(pandas_df)
        writer = pa.ipc.new_file(self._dir + self._name, schema)
        writer.write(table)
        writer.close()
        connection = self.get_connection()
        return connection.get_data_object("/Local/" + self._name)

    def delete(self):
        """deletes the file from temp folder"""
        fname = self._dir + self._name
        if os.path.isfile(fname):
            os.remove(fname)

    @staticmethod
    def to_pandas(dataframe):
        """Converts pyarrow table to Pandas DF"""
        return dataframe.to_pandas()
