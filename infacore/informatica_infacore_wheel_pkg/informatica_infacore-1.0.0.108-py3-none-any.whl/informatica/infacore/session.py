#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
This module lists the functions to manage the INFACore client session.
"""
from informatica.infacore.compute_engine.compute_engine_factory import (
    ComputeEngineFactory,
)
from informatica.infacore.common.constants import (
    INFACORE_LOGO,
    CloudProvider,
    ComputeEngineType,
    EnvType,
    Region,
    StagingType,
)
from informatica.infacore.common.decorators import log_activity
from informatica.infacore.internal.error_message import InfacoreClientErrorMessages
import informatica.infacore.common.iics_rest_api as iics_api
import informatica.infacore.common.iics_login_rest_api as iics_login_api
from informatica.infacore.internal.toml_utils import (
    dump_infacore_config,
    load_infacore_base_config,
    load_infacore_config,
)
from informatica.infacore.internal.utils import (
    get_compute_engine_type,
    get_log_filepath,
    get_os_name,
    get_python_version,
    get_runtime_env_name,
    get_username,
    get_version,
    is_ecosystem_staging_done,
    set_password,
    is_asset_setup_done,
    is_compute_engine_installed,
    is_user_logged_in,
)
import informatica.infacore.internal.logger as logger
import informatica.infacore as ic

_logger = logger.get_logger(__name__)


@log_activity
def help():
    """
    Lists the available INFACore methods with their short descriptions.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> ic.help()
    """
    print(INFACORE_LOGO)

    session_info = f"""
INFACore SDK Version: {get_version()},
Python Version: {get_python_version()},
OS Name: {get_os_name()},
Log File Path: {get_log_filepath()}
    """
    print(session_info)

    method_help = r"""
Available methods:
------------------
help(): Lists the available INFACore methods with their short descriptions.
register(): Redirects to the INFACore registration page.
setup(): Sets up the user environment for INFACore.
logout(): Logs out the current user.
reset(): Logs out the current user and clears the user's environment configurations.
list_data_sources(): Lists the available data sources to extract or load data.
get_data_source(): Fetch data source object for the data source name you specify.
get_compute_engine(): Fetches the compute engine object and provides you with options to start or stop the compute engine.


Available classes:
------------------
DataFrameReader: Exposes methods to convert the INFACore DataFrame to other DataFrames such as Pandas.
DataFrameWriter: Exposes methods to convert different DataFrames such as Pandas to the INFACore DataFrame.
ParserFunctions: Exposes functions to parse semi-structured and unstructured data.
DataQualityFunctions: Exposes functions to analyze, validate, and improve the quality of your data.


Documentation links:
--------------------
For the available INFACore methods, see:
https://onlinehelp.informatica.com/IICS/prod/infacorepythonsdk/100/index.html

For the INFACore documentation, see:
https://docs.informatica.com/integration-cloud/infacore/current-version.html
    """
    print(method_help)

    _logger.debug("INFACore session information: %s", session_info)


@log_activity
def register() -> str:
    """
    Redirects to the INFACore registration page.

    Returns
    -------
    str
        Registration link.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> ic.register()
    """
    trail_registration_link = r"""
INFACore is the industry’s first, open, extensible and embeddable intelligent headless
data management for data scientists and data engineers. It is a simple plug-in for any
development and data science framework that radically simplifies composing data
pipelines, turning thousands of lines of code into a single function. It also accelerates
the ability to consume, transform and prepare data from any source within an integrated
development environment (IDE).

Please visit following url for registering into INFACore:

https://marketplace.informatica.com/forms/infacore-trial.html
    """
    print(trail_registration_link)
    return "https://marketplace.informatica.com/forms/infacore-trial.html"


@log_activity
def setup(config: dict):
    """
    Sets up the user environment for INFACore.

    Parameters
    ----------
    config: dict
        A dictionary that contains the login, compute engine, and ecosystem related configuration details.

            - config['login'] : A dictionary containing the login credentials and POD details.
                - config['login']['username']: str, the IICS user name.
                - config['login']['password']: str, the IICS password.
                - config['login']['env_type'] : str, 'prod' if your account is in the IICS production POD. Else, specify 'test'.
                - config['login']['url']: str, the login URL. Mandatory if the 'env_type' is 'test'.
                - config['login']['region']: str, the region where your IICS account resides. Mandatory if the 'env_type' is 'prod'.
                - config['login']['cloud_provider']: str, the cloud provider where your IICS account resides. Mandatory if the 'env_type' is 'prod'.

            - config['compute_engine']: A dictionary containing the details of the compute engine.
                - config['compute_engine']['type']: str, Allowed values are local and remote. Specify 'local' if INFACore and the compute engine are on the same machine. Else, specify 'remote'.
                - config['compute_engine']['install']: bool, mandatory key for the local compute engine. Specify True if you want to install the compute engine locally. Specify False if the compute engine is already installed.
                - config['compute_engine']['runtime_env_name']: str, mandatory key for the remote compute engine. Specify the runtime environment name for the remote compute engine.
                - config['compute_engine']['agent_name']: str, optional key for remote compute engine. The runtime_env_name is considered as the agent name by default. If your agent name is different, specify the name.

            - config['ecosystem']: A dictionary containing the details of the ecosystem where you want to stage the data.
                - config['ecosystem']['type']: str, Allowed value are "Databricks Delta", "Microsoft Fabric OneLake".
                - config['ecosystem']['staging']: dict, placeholder for staging attributes.
                - config['ecosystem']['staging']['connection_name']: str, the connection name corresponding to the ecosystem where you want to stage the data.

    Examples
    --------
    # Example 1 - Setting up the local compute engine

    >>> import informatica.infacore as ic
    >>> user_config = {
            "login": {
                "username": "infacore",
                "password": "INFACore!rocks",
                "env_type": "prod",
                "cloud_provider": "dm",
                "region": "us"
            },
            "compute_engine": {
                "type": "local",
                "install" : True
            }
        }
    >>> ic.setup(config=user_config)


    # Example 2 - Setting up the remote compute engine with the Databricks Delta ecosystem

    >>> import informatica.infacore as ic
    >>> user_config = {
            "login": {
                "username": "infacore",
                "password": "INFACore!rocks",
                "env_type": "prod",
                "cloud_provider": "dm",
                "region": "us"
            },
            "compute_engine": {
                "type": "remote",
                "runtime_env_name" : "icagentcluster",
                "agent_env_name" : "icagent01"
            },
            "ecosystem" : {
                "type" : "Databricks Delta"
                "staging" : {
                    "connection_name" : "Databricks INFACore"
                }
            }
        }
    >>> ic.setup(config=user_config)

    Raises
    ------
    InfacoreClientErrorMessages.mandatory_setup_config_missing
        It is mandatory that you provide the config dictionary for the setup() function.
    """
    if not config:
        raise InfacoreClientErrorMessages.mandatory_setup_config_missing()

    if is_user_logged_in():
        _logger.debug("User is already logged in, hence skipping login.")
    else:
        _login(config)
        _get_user_details()

    if "compute_engine" in config:
        _setup_compute_engine(config)
    else:
        _logger.debug(
            "No compute engine config provided, hence skipping compute engine setup."
        )

    if is_compute_engine_installed():
        if is_asset_setup_done():
            _logger.debug("Asset setup was already done, hence skipping asset setup.")
        else:
            _setup_assets()

        if "ecosystem" in config:
            _setup_ecosystem(config)
        else:
            if is_ecosystem_staging_done():
                _logger.debug(
                    "Ecosystem setup was already done, hence skipping ecosystem setup."
                )
            else:
                compute_engine_type = get_compute_engine_type()
                if compute_engine_type == ComputeEngineType.LOCAL.value:
                    _setup_arrow_staging()

    else:
        _logger.debug(
            "Compute engine not configured, hence skipping assets & staging setup."
        )


@log_activity
def logout():
    """
    Logs out the current user.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> ic.logout()
    """
    ic_config = load_infacore_config()
    ic_config["session"]["id"] = ""
    ic_config["session"]["org_id"] = ""
    ic_config["session"]["base_url"] = ""
    dump_infacore_config(ic_config)
    _logger.info("Logged out user successfully.")


@log_activity
def reset():
    """
    Logs out the current user and clears the user's environment configurations.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> ic.reset()
    """
    ic_template_config = load_infacore_base_config()
    dump_infacore_config(ic_template_config)
    _logger.info("Logged out user successfully & cleared user's environment config.")


def _login(config: dict):
    """Invokes INFACore login API."""
    _validate_login_details(config)
    try:
        username = config["login"]["username"]
        password = config["login"]["password"]
        resp = iics_login_api.perform_login(username, password)
        login_resp = resp.json()
        session_id = login_resp["userInfo"]["sessionId"]
        org_id = login_resp["userInfo"]["orgId"]
        products = login_resp["products"]
        base_url = ""
        for product in products:
            if product["name"] == "Integration Cloud":
                base_url = product["baseApiUrl"]
                break
        if not base_url:
            raise Exception("Infacore is only supported for Integration Cloud product.")

        ic_config = load_infacore_config()
        ic_config["login"]["username"] = username
        set_password(username, password)
        ic_config["session"]["id"] = session_id
        ic_config["session"]["org_id"] = org_id
        ic_config["session"]["base_url"] = base_url
        dump_infacore_config(ic_config)
    except Exception as ex:
        raise InfacoreClientErrorMessages.invalid_login_details_provided(str(ex))
    _logger.info("Logged in user successfully.")


def _validate_login_details(config: dict) -> None:
    """Validates user provided login details."""
    env_type, cloud_provider, region, url = "", "", "", ""
    if "login" in config:
        if "env_type" not in config["login"]:
            env_type = EnvType.PROD.value  # default value
        else:
            env_type = config["login"]["env_type"]
            supported_env_types = [member.value for member in EnvType]
            if env_type not in supported_env_types:
                raise InfacoreClientErrorMessages.unsupported_setup_config_provided(
                    "env_type", env_type, supported_env_types
                )
            if env_type == EnvType.TEST.value:
                if "url" not in config["login"]:
                    raise InfacoreClientErrorMessages.mandatory_login_detail_missing(
                        "url"
                    )
                else:
                    url = config["login"]["url"]
        if env_type == EnvType.PROD.value:
            if "cloud_provider" not in config["login"]:
                cloud_provider = CloudProvider.AWS.value  # default value
            else:
                cloud_provider = config["login"]["cloud_provider"]
                supported_cloud_providers = [member.value for member in CloudProvider]
                if cloud_provider not in supported_cloud_providers:
                    raise InfacoreClientErrorMessages.unsupported_setup_config_provided(
                        "cloud_provider", cloud_provider, supported_cloud_providers
                    )
            if "region" not in config["login"]:
                region = Region.NORTH_AMERICA.value  # default value
            else:
                region = config["login"]["region"]
                supported_regions = [member.value for member in Region]
                if region not in supported_regions:
                    raise InfacoreClientErrorMessages.unsupported_setup_config_provided(
                        "region", region, supported_regions
                    )
        if "username" not in config["login"]:
            raise InfacoreClientErrorMessages.mandatory_login_detail_missing("username")
        if "password" not in config["login"]:
            raise InfacoreClientErrorMessages.mandatory_login_detail_missing("password")

        ic_config = load_infacore_config()
        if _is_new_user(config, ic_config):
            reset()
            ic_config = load_infacore_config()

        ic_config["login"]["env_type"] = env_type
        ic_config["login"]["cloud_provider"] = cloud_provider
        ic_config["login"]["region"] = region
        ic_config["login"]["url"] = url

        dump_infacore_config(ic_config)
    else:
        raise InfacoreClientErrorMessages.mandatory_login_key_missing()
    _logger.debug("User provided login information: %s", ic_config)


def _is_new_user(user_config, saved_config) -> bool:
    new_username = user_config["login"]["username"]
    existing_username = saved_config["login"]["username"]
    new_env_type = user_config["login"]["env_type"]
    if new_env_type == EnvType.TEST.value:
        new_url = user_config["login"]["url"]
        existing_url = saved_config["login"]["url"]
        if new_username == existing_username and new_url == existing_url:
            return False
    elif new_env_type == EnvType.PROD.value:
        new_cloud_provider = user_config["login"]["cloud_provider"]
        existing_cloud_provider = saved_config["login"]["cloud_provider"]
        new_region = user_config["login"]["region"]
        existing_region = saved_config["login"]["region"]
        if (
            new_username == existing_username
            and new_cloud_provider == existing_cloud_provider
            and new_region == existing_region
        ):
            return False
    return True


def _get_user_details():
    user_resp = iics_api.get_user_details(get_username())
    user_details = user_resp.json()[0]
    user_fname = user_details["firstName"]
    user_lname = user_details["lastName"]
    user_email = user_details["email"]
    ic_config = load_infacore_config()
    ic_config["user"]["firstname"] = user_fname
    ic_config["user"]["lastname"] = user_lname
    ic_config["user"]["email"] = user_email
    dump_infacore_config(ic_config)


def _setup_compute_engine(config: dict):
    """Setup compute engine."""
    compute_engine_config = {}
    if "type" not in config["compute_engine"]:
        raise InfacoreClientErrorMessages.mandatory_compute_engine_detail_missing(
            "type"
        )
    else:
        compute_engine_type = config["compute_engine"]["type"]
        supported_ce_types = [member.value for member in ComputeEngineType]
        if compute_engine_type not in supported_ce_types:
            raise InfacoreClientErrorMessages.unsupported_setup_config_provided(
                "type", compute_engine_type, ["local"]
            )
        if compute_engine_type == ComputeEngineType.REMOTE.value:
            if "runtime_env_name" not in config["compute_engine"]:
                raise InfacoreClientErrorMessages.mandatory_compute_engine_detail_missing(
                    "runtime_env_name"
                )
            else:
                runtime_env_name = config["compute_engine"]["runtime_env_name"]
                compute_engine_config["runtime_env_name"] = runtime_env_name

                if "agent_name" in config["compute_engine"]:
                    compute_engine_config["agent_name"] = config["compute_engine"][
                        "agent_name"
                    ]
                else:
                    # If agent_name is not provided, we will assume agent_name is same as runtime_env_name, same as IICS behaviour
                    compute_engine_config["agent_name"] = runtime_env_name

                if not _validate_ce_details(compute_engine_config):
                    if not compute_engine_config.get("runtime_env_id"):
                        raise ValueError(
                            "Please provide a valid 'runtime_env_name' in 'compute_engine' config."
                        )

                    raise ValueError(
                        "Please provide a valid 'agent_name' in 'compute_engine' for runtime enviroment : "
                        + runtime_env_name
                    )

        elif compute_engine_type == ComputeEngineType.LOCAL.value:
            install = config["compute_engine"]["install"]
            compute_engine_config = {"install": install}
    compute_engine = ComputeEngineFactory.build_compute_engine(
        compute_engine_type, compute_engine_config
    )
    compute_engine.setup()


def _setup_assets():
    ic_config = load_infacore_config()
    ic_config["asset"]["project_id"] = _get_project_id()
    ic_config["asset"]["infacore_passthrough_id"] = _get_mapping_id(
        "infacore_passthrough"
    )
    ic_config["asset"]["infacore_parse_unstructured_data_id"] = _get_mapping_id(
        "infacore_parse_unstructured_data"
    )
    ic_config["asset"]["infacore_get_country_iso_values_id"] = _get_mapping_id(
        "infacore_get_country_iso_values"
    )
    ic_config["asset"]["infacore_validate_email_address_id"] = _get_mapping_id(
        "infacore_validate_email_address"
    )
    ic_config["asset"]["infacore_find_invalid_names_id"] = _get_mapping_id(
        "infacore_find_invalid_names"
    )
    ic_config["asset"]["infacore_remove_control_characters_id"] = _get_mapping_id(
        "infacore_remove_control_characters"
    )
    ic_config["asset"]["infacore_convert_diacritic_english_chars_id"] = _get_mapping_id(
        "infacore_convert_diacritic_english_chars"
    )
    ic_config["asset"]["infacore_validate_usa_zipcode_id"] = _get_mapping_id(
        "infacore_validate_usa_zipcode"
    )
    ic_config["asset"]["infacore_validate_usa_state_id"] = _get_mapping_id(
        "infacore_validate_usa_state"
    )
    ic_config["asset"]["infacore_validate_ssn_id"] = _get_mapping_id(
        "infacore_validate_ssn"
    )
    ic_config["asset"]["infacore_validate_usa_phone_number_id"] = _get_mapping_id(
        "infacore_validate_usa_phone_number"
    )
    ic_config["asset"]["infacore_parse_name_id"] = _get_mapping_id(
        "infacore_parse_name"
    )
    ic_config["asset"]["infacore_validate_us_county_id"] = _get_mapping_id(
        "infacore_validate_us_county"
    )
    ic_config["asset"]["infacore_standardize_us_companyname_id"] = _get_mapping_id(
        "infacore_standardize_us_companyname"
    )

    dump_infacore_config(ic_config)
    _logger.info("Assets setup completed successfully.")


def _get_project_id() -> str:
    """Retrive INFACore project id."""
    project_id = ""
    resp = iics_api.perform_lookup({"path": "INFACore", "type": "Project"})
    if resp.ok:
        project_id = resp.json()["objects"][0]["id"]
    else:
        resp = iics_api.create_project(
            "INFACore", "Project to store all INFACore assets."
        )
        project_id = resp.json()["id"]
    return project_id


def _get_mapping_id(mapping_name: str) -> str:
    """Retrive passthrough mapping template id."""
    resp = iics_api.get_mapping_details(mapping_name)
    template_id = resp.json()["id"]
    return template_id


def _get_arrow_connection_id() -> str:
    """Retrive INFACore_Arrow connection id."""
    arrow_ds = ic.get_data_source("Arrow")
    arrow_connections = arrow_ds.list_connections()
    runtime_env_name = get_runtime_env_name()
    cnx_name = runtime_env_name + "_" + "Arrow"
    if cnx_name in arrow_connections:
        arrow_connection = arrow_ds.get_connection(cnx_name)
        return arrow_connection._connection_id
    else:
        arrow_connection = arrow_ds.connect(cnx_name, {"remoteFlow": False})
        return arrow_connection._connection_id


def _setup_ecosystem(config: dict):
    ecosystem_config = config.get("ecosystem")
    type = ecosystem_config.get("type")
    supported_staging_type = [staging_type.value for staging_type in StagingType]
    if type in supported_staging_type:
        if type == StagingType.ARROW.value:
            _setup_arrow_staging()
        else:
            _validate_and_setup_staging(ecosystem_config, type)
        _logger.info("Staging setup completed successfully")

    else:
        raise InfacoreClientErrorMessages.unsupported_setup_config_provided(
            "[ecosystem][type]", type, supported_staging_type
        )


def _validate_and_setup_staging(user_config: dict, type: str):
    ic_config = load_infacore_config()
    if "staging" in user_config:
        user_staging_config: dict = user_config.get("staging")
        if "connection_name" not in user_staging_config:
            raise InfacoreClientErrorMessages.mandatory_compute_engine_detail_missing(
                "[ecosystem][staging][connection_name]"
            )

        config = {}
        connection_name = user_staging_config.get("connection_name")
        if type == StagingType.DATABRICKS_DETLA.value:
            datasource = ic.get_data_source("Databricks Delta")
            staging_connection = datasource.get_connection(connection_name)
            connection_attributes = staging_connection.config()
            sql_endpoint_url = connection_attributes.get("sqlEndpointUrl")
            unity_catalog = connection_attributes.get("unityCatalog")
            database_name = connection_attributes.get("Database")
            catalog_name = _parse_catalog_name(sql_endpoint_url, unity_catalog)
            config["catalog_name"] = catalog_name
            if not database_name:
                database_name = "default"
            config["database"] = database_name
        elif type == StagingType.MICROSOFT_FABRIC_ONELAKE.value:
            datasource = ic.get_data_source("Microsoft Fabric OneLake")
            staging_connection = datasource.get_connection(connection_name)
            connection_attributes = staging_connection.config()
            workspace_name = connection_attributes.get("workspaceName")
            config["workspace_name"] = workspace_name

        ic_config["staging"]["type"] = type
        ic_config["staging"]["connection_name"] = connection_name
        ic_config["staging"]["config"] = config
        ic_config["staging"]["connection_id"] = staging_connection._connection_id
        dump_infacore_config(ic_config)
    else:
        raise InfacoreClientErrorMessages.mandatory_compute_engine_detail_missing(
            "[ecosystem][staging]"
        )


def _setup_arrow_staging():
    ic_config = load_infacore_config()
    runtime_env_name = get_runtime_env_name()
    cnx_name = runtime_env_name + "_" + "Arrow"
    ic_config = load_infacore_config()
    ic_config["staging"]["type"] = StagingType.ARROW.value
    ic_config["staging"]["connection_id"] = _get_arrow_connection_id()
    ic_config["staging"]["connection_name"] = cnx_name
    ic_config["staging"]["config"] = {}
    dump_infacore_config(ic_config)


def _validate_ce_details(ce_config: dict) -> bool:
    runtime_env_name = ce_config.get("runtime_env_name")
    agent_name = ce_config.get("agent_name")
    resp = iics_api.get_runtime_env_details()
    runtime_envs = resp.json()
    for runtime_env in runtime_envs:
        runtime_env_id = runtime_env.get("id")
        if runtime_env.get("name") == runtime_env_name:
            ce_config["runtime_env_id"] = runtime_env_id
            agents = runtime_env.get("agents", [])
            for agent in agents:
                if agent.get("name") == agent_name:
                    ce_config["agent_id"] = agent.get("id")
                    return True
    return False


def _parse_catalog_name(sql_endpoint_url, unity_catalog):
    catalog_name = "hive_metastore"
    if unity_catalog:
        catalog_name = unity_catalog
    else:
        url_parts = sql_endpoint_url.split(";")
        for url_part in url_parts:
            if "ConnCatalog" in url_part:
                catalog_split = url_part.split("=")
                if len(catalog_split) >= 2:
                    catalog_name = catalog_split[1]
    return catalog_name
