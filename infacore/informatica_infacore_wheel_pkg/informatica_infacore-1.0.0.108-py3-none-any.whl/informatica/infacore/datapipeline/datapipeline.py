#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
from __future__ import annotations
from informatica.infacore.common.constants import (
    DataPipelineConfigModes,
)
import informatica.infacore.common.iics_rest_api as iics_api
from informatica.infacore.common.template_executor import execute_template
from informatica.infacore.dataframe.dataframe_writer import DataFrameWriter
import informatica.infacore.internal.logger as logger
from informatica.infacore.common.decorators import log_activity
from informatica.infacore.internal.utils import (
    construct_payload,
    generate_random_name,
    get_agent_id,
    get_org_id,
    get_project_id,
    get_runtime_env_id,
    get_staging_type,
)
from informatica.infacore.staging.staging_factory import StagingFactory


class DataPipeline:
    """
    Represents an end-to-end sequence of digital processes used to collect, modify, and deliver data.
    Use data pipelines to copy or move your data from one source to another so it can be stored, used for analytics, or combine with other data.

    """

    def __init__(self, name: str) -> None:
        self._name = name
        self.parameters = None

    @log_activity
    def config(self, mode: str = DataPipelineConfigModes.BASIC.value) -> dict:
        """
        Returns the parameter details required for configuring the data pipeline.

        Parameters
        ----------
        mode : str
            The value to assign to retrieve the corresponding data pipeline parameter details.

            You can specify the following values:
                - BASIC: Gets only the parameter attribute keys.
                - RAW: Gets the complete data pipeline details.

            The default value is BASIC.


        Returns
        -------
        dict
            Data pipeline details as the "key, value" pair.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> scd_dp = ic.get_data_pipeline("scd type 2")
        >>> scd_dp.config()
        """
        resp = iics_api.get_mapping_details(self._name)
        config = resp.json()
        if mode == DataPipelineConfigModes.BASIC.value:
            basic_config = {}
            mapping_params = config.get("parameters")
            for mapping_param in mapping_params:
                type = mapping_param.get("type")
                if type not in ["SOURCE", "EXTENDED_SOURCE", "TARGET"]:
                    name = mapping_param.get("name").replace("$", "")
                    basic_config[name] = ""
            config = basic_config
        return config

    @log_activity
    def execute(self, src_dfs=None, tgt_dfs=None, parameters=None):
        """
        Executes the data pipeline with the specified source and target native DataFrames and data pipeline parameters.

        Parameters
        ----------
        src_dfs : dict
            Source native DataFrame.
        tgt_dfs : dict
            Target DataFrame. Skip for using staging.
        parameters: dict
            Data pipeline parameters in "key, value" pairs.

        Returns
        -------
        Object
            Native DataFrame object.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> scd_dp = ic.get_data_pipeline("scd type 2")
        >>> params = {
                "i_param_1": "",
                "i_param_2": ""
            }
        >>> orcl_cnx = scd_dp.execute(src_dfs, parameters=params)
        """
        mapping_details = self.config(DataPipelineConfigModes.RAW.value)
        mapping_params = mapping_details.get("parameters")
        mapping_id = mapping_details.get("id")
        payload = self._populate_base_template(mapping_id)
        self._update_source_params(payload, mapping_params, src_dfs)
        target_staging_object = self._update_target_params(payload, mapping_params)
        additional_params = self._update_additional_params(mapping_params, parameters)
        payload["parameters"].extend(additional_params)
        return self._execute_template(payload, target_staging_object)

    @log_activity
    def visualize(self):
        """
        Retrieves the image of the data pipeline.

        Returns
        -------
        Image
            A visual image representation of the data pipeline.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> import matplotlib.pyplot as plt
        >>> import numpy as np
        >>> from PIL import Image
        >>> from io import BytesIO
        >>> scd_dp = ic.get_datapipeline("scd type 2")
        >>> resp = scd_dp.visualize()
        >>> img = Image.open(BytesIO(resp.content))
        >>> im_array = np.asarray(img)
        >>> plt.imshow(im_array)
        >>> plt.show()
        """
        pipeline_id = self.config(DataPipelineConfigModes.RAW.value)["id"]
        resp = iics_api.get_mapping_image(pipeline_id)
        return resp

    def _populate_base_template(self, mapping_id):
        org_id = get_org_id()
        mct_name = generate_random_name("mct")
        agent_id = get_agent_id()
        runtime_env_id = get_runtime_env_id()
        infacore_project_id = get_project_id()
        param_values = {
            "org_id": org_id,
            "mct_name": mct_name,
            "agent_id": agent_id,
            "runtime_env_id": runtime_env_id,
            "infacore_project_id": infacore_project_id,
            "mapping_id": mapping_id,
        }
        payload = construct_payload("base_template.json", param_values)
        return payload

    def _update_source_params(self, payload, mapping_params, src_df=None):
        type = get_staging_type()
        pandas_df = StagingFactory.get_staging(type).to_pandas(src_df)
        infa_df = DataFrameWriter().from_pandas(pandas_df)
        src_cnx_id = infa_df._data_object._connection._connection_id
        src_obj_name = infa_df._data_object._object_name
        src_cnx_param_name, src_obj_param_name = self._get_src_param_details(
            mapping_params
        )
        param_values = {
            "src_cnx_id": src_cnx_id,
            "src_obj_name": src_obj_name,
            "src_cnx_param_name": src_cnx_param_name,
            "src_obj_param_name": src_obj_param_name,
        }
        src_param = construct_payload("src_param_template.json", param_values)
        payload["parameters"].append(src_param)

    def _update_target_params(self, payload, mapping_params, tgt_df=None):
        type = get_staging_type()
        target_staging_object = StagingFactory.get_staging(type).create_instance()
        staging_connection = target_staging_object.get_connection()
        tgt_obj_name = target_staging_object.get_staging_path()
        tgt_cnx_id = staging_connection._connection_id
        tgt_cnx_param_name, tgt_obj_param_name = self._get_tgt_param_details(
            mapping_params
        )
        param_values = {
            "tgt_cnx_id": tgt_cnx_id,
            "tgt_obj_name": tgt_obj_name,
            "tgt_cnx_param_name": tgt_cnx_param_name,
            "tgt_obj_param_name": tgt_obj_param_name,
        }
        tgt_param = construct_payload("tgt_param_template.json", param_values)
        payload["parameters"].append(tgt_param)
        return target_staging_object

    def _update_additional_params(self, mapping_params, param_values):
        additional_params = []
        self._validate_param_values(mapping_params, param_values)
        for mapping_param in mapping_params:
            type = mapping_param.get("type")
            if type not in ["SOURCE", "EXTENDED_SOURCE", "TARGET"]:
                name = mapping_param.get("name").replace("$", "")
                value = param_values.get(name)
                mapping_param["text"] = value
                additional_params.append(mapping_param)
        return additional_params

    def _validate_param_values(self, mapping_params, param_values):
        user_provided_params = list(param_values.keys())
        supported_params = []
        for mapping_param in mapping_params:
            type = mapping_param.get("type")
            if type not in ["SOURCE", "EXTENDED_SOURCE", "TARGET"]:
                name = mapping_param.get("name").replace("$", "")
                supported_params.append(name)
        invalid_params = []
        for param in user_provided_params:
            if param not in supported_params:
                invalid_params.append(param)
        if invalid_params:
            raise ValueError(
                "Invalid parameters "
                + str(invalid_params)
                + " provided. Please check list of valid parameters via config() method."
            )

    def _execute_template(self, mct_payload, target_staging_object):
        table = execute_template(
            mct_payload,
            "read_staging",
            target_staging_object,
            "Executing data pipeline failed.",
        )
        return table

    def _get_src_param_details(self, mapping_params):
        # Handling only for single source, need to extend for multi-source in future
        for mapping_param in mapping_params:
            type = mapping_param.get("type")
            if type in ["SOURCE", "EXTENDED_SOURCE"]:
                src_cnx_param_name, src_obj_param_name = self._get_param_name(
                    mapping_param
                )
        return src_cnx_param_name, src_obj_param_name

    def _get_tgt_param_details(self, mapping_params):
        # Handling only for single target, need to extend for multi-target in future
        for mapping_param in mapping_params:
            type = mapping_param.get("type")
            if type in ["TARGET"]:
                tgt_cnx_param_name, tgt_obj_param_name = self._get_param_name(
                    mapping_param
                )
        return tgt_cnx_param_name, tgt_obj_param_name

    def _get_param_name(self, mapping_param):
        cnx_param_name = mapping_param.get("runtimeParameterData").get(
            "connectionParameterName"
        )
        obj_param_name = mapping_param.get("runtimeParameterData").get(
            "objectParameterName"
        )
        return cnx_param_name, obj_param_name


@log_activity
def list_data_pipelines() -> list[str]:
    """
    Lists the available data pipelines in your Informatica Intelligent Cloud Service organization that you can use to extract, transform, or load data.

    Returns
    -------
    list[str]
        A list of data pipeline names.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> ic.list_data_pipelines()
    """
    data_pipelines = []
    mappings = _list_mappings()
    data_pipelines.extend(mappings)
    return data_pipelines


@log_activity
def get_data_pipeline(data_pipeline_name: str) -> DataPipeline:
    """
    Fetches the data pipeline object for the data pipeline name you specified.

    Parameters
    ----------
    datasource_name : str
        The name of the data pipeline for which you want to extract, transform, or load data.

    Returns
    -------
    DataPipeline
        Object of class DataPipeline.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> ic.get_data_pipeline("Oracle to Snowflake ")

    Raises
    ------
    ValueError
        A ValueError if you specified an unsupported data pipeline name.
    """
    data_pipelines = list_data_pipelines()
    if data_pipeline_name in data_pipelines:
        return DataPipeline(data_pipeline_name)
    else:
        raise ValueError("Non existent data pipeline name provided.")


def _list_mappings() -> list:
    """
    Returns list of mappings created in users org.
    """
    resp = iics_api.get_mappings()
    # Neither in API doc nor in code I see way to paginate.
    # Hence I hope this API will return all mappings in 1 call.
    mapping_details = resp.json()
    mappings = []
    for mapping in mapping_details:
        mappings.append(mapping.get("name"))
    return mappings
