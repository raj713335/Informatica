#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
This module contains information about the Informatica INFACore Python SDK version.
"""
__version__ = "1.0.0"
