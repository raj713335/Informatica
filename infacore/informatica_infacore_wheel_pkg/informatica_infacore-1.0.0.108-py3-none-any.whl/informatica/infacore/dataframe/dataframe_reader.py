#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
from informatica.infacore.common.decorators import log_activity
from informatica.infacore.internal.utils import get_staging_type
from informatica.infacore.staging.staging import Staging
from informatica.infacore.staging.staging_factory import StagingFactory


class DataFrameReader:
    """
    Exposes methods to convert the Ecosystem DataFrame to other DataFrames such as Pandas.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> df_reader = ic.DataFrameReader(table)
    >>> df_reader.to_pandas()
    """

    def __init__(self, dataframe):
        self._dataframe = dataframe

    @log_activity
    def to_pandas(self):
        """
        Converts the Ecosystem dataframe to the Pandas DataFrame.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> df_reader = ic.DataFrameReader(table)
        >>> df_reader.to_pandas()
        """
        type = get_staging_type()
        staging: Staging = StagingFactory.get_staging(type)
        return staging.to_pandas(self._dataframe)
