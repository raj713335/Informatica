#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
import pyarrow as pa
import informatica.infacore as ic
from informatica.infacore.common.decorators import log_activity
from informatica.infacore.internal.utils import (
    get_staging_type,
)
from informatica.infacore.staging.staging import Staging
from informatica.infacore.staging.staging_factory import StagingFactory


class DataFrameWriter:
    """
    Exposes methods to convert different DataFrames such as Pandas to the Ecosystem DataFrame.

    Example
    -------
    >>> import informatica.infacore as ic
    >>> df_writer = ic.DataFrameWriter()
    >>> df_writer.from_pandas(pandas_df)
    """

    def __init__(self):
        pass

    @log_activity
    def from_pandas(self, pandas_df):
        """
        Converts the Pandas DataFrame object to the Ecosystem DataFrame.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> df_writer = ic.DataFrameWriter()
        >>> df_writer.from_pandas(pandas_df)
        """
        type = get_staging_type()
        staging_instace: Staging = StagingFactory.get_staging(type).create_instance()
        source_do = staging_instace.write(pandas_df)
        source_do._options = {"source_staging_obj": staging_instace}
        read_options = None
        if type == "Microsoft Fabric OneLake":
            read_options = {
                "data_format" : {
                    "format" : "Parquet"
                }
            }
        return source_do.read(read_options)
