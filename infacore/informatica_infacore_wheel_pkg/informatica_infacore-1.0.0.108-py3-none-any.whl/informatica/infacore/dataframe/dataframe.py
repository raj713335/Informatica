#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
from __future__ import annotations

from typing import TYPE_CHECKING

from informatica.infacore.functions.udf import get_udf_details
from informatica.infacore.common.decorators import log_activity
from informatica.infacore.common.mapping_model import MappingModel, Mapping
from informatica.infacore.common.template_executor import execute_template
from informatica.infacore.internal.utils import (
    get_staging_type,
    get_type_system,
    generate_random_name,
    construct_payload,
    upsert_mct_parameter,
)
from informatica.infacore.staging.staging import Staging
from informatica.infacore.staging.staging_factory import StagingFactory

if TYPE_CHECKING:
    from informatica.infacore.dataframe.dataobject import DataObject


class DataFrame:
    """
    Represents a relational dataset that is lazily evaluated.

    The DataFrame encapsulates the computation or pipeline required to produce a relational dataset,
    but does not perform the computation until you call action methods such as collect() and write().
    """

    def __init__(self, data_object: DataObject, _mapping: Mapping):
        self._data_object = data_object
        self._mapping = _mapping

    @log_activity
    def collect(self):
        """
        This method executes the user-created data pipeline
        and fetches actual data corresponding to the DataFrame object.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_do = ic.get_data_source("Oracle").get_connection("Oracle Prod").get_data_object("Customers")
        >>> table = orcl_do.read().collect()

        """
        (
            target_staging_object,
            tgt_param,
            function_payload,
        ) = self._populate_target()
        if self._data_object:
            # MCT_FLOW
            upsert_mct_parameter(self._data_object._payload["parameters"], tgt_param)
            create_mct_payload = self._data_object._payload
            source_staging_object = None
            if self._data_object._options:
                data_object_options = self._data_object._options
                if data_object_options.get("source_staging_obj"):
                    source_staging_object = data_object_options.get(
                        "source_staging_obj"
                    )
            table = execute_template(
                create_mct_payload,
                "read_staging",
                target_staging_object,
                "Reading from datasource failed.",
                source_staging_object,
            )
            return table
        else:
            # MAPPING_FLOW
            source_staging_object = None
            write_df = DataFrame(
                None,
                Mapping(
                    self._mapping._mapping_model,
                    function_payload,
                    [generate_random_name("function")],
                    self._mapping._current_id,
                ),
            )
            create_mct_payload = write_df._mapping._mapping_model.serialize_model()
            table = execute_template(
                create_mct_payload,
                "read_staging",
                target_staging_object,
                "Reading from datasource failed.",
                source_staging_object,
                True,
            )
            self._mapping_model = self._mapping._mapping_model.reinit_after_read()
        return table

    @log_activity
    def udf(self, path: str, field_mapping: dict = None):
        """
        Chains the UDF to the data pipeline.

        Parameters
        ----------
        path : str
            The path of the UDF.

        field_mapping, optional : dict
            Map of UDF input field and incoming field as "key, value" pair.


        Returns
        -------
        DataFrame
            The INFACore DataFrame object.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_do = ic.get_data_source("Oracle").get_connection("Oracle Prod").get_data_object("Customers")
        >>> infa_df = orcl_do.read().udf("Default/EmailMask", field_mapping={"Input_Email": "Email Id"})

        """
        mapplet_details: dict = get_udf_details(path)
        saas_mapplet_id = mapplet_details.get("saasMappletId")
        function_payload = {
            "name": "mapplet",
            "id": saas_mapplet_id,
            "fieldMapping": field_mapping,
        }
        return DataFrame(
            None,
            Mapping(
                self._mapping._mapping_model,
                function_payload,
                [generate_random_name("function")],
                self._mapping._current_id,
            ),
        )

    def _populate_target(self):
        # MCT_FLOW
        type = get_staging_type()
        target_staging_object: Staging = StagingFactory.get_staging(
            type
        ).create_instance()
        staging_connection = target_staging_object.get_connection()
        tgt_obj_name = target_staging_object.get_staging_path()
        tgt_cnx_id = staging_connection._connection_id
        param_values = {"tgt_cnx_id": tgt_cnx_id, "tgt_obj_name": tgt_obj_name}
        tgt_param = construct_payload(
            "newobject_target_parameter_template.json", param_values
        )
        if type == "Microsoft Fabric OneLake":
            dfc = {
                "@type": "dataFormat",
                "formatId": "Parquet",
                "dataFormatAttributes": {},
            }
            tgt_param["dataFormat"] = dfc

        # MAPPING_FLOW
        dfc = None
        if type == "Microsoft Fabric OneLake":
            dfc = {
                "dataFormat": "Parquet",
            }
        type_system = get_type_system(staging_connection._connnector_type)
        function_payload = {
            "name": "write",
            "connectionId": tgt_cnx_id,
            "path": tgt_obj_name,
            "typeSystem": type_system,
            "writeOptions": {"createTarget": True, "operationType": "Insert"},
            "dataFormatOptions": dfc,
        }
        return target_staging_object, tgt_param, function_payload
