#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
from __future__ import annotations
from typing import TYPE_CHECKING
from informatica.infacore.common.constants import (
    SUPPORTED_FILTER_OPERATORS,
    SUPPORTED_FILTER_TYPES,
    SUPPORTED_READ_OPTIONS,
    SUPPORTED_WRITE_OPTIONS,
    SUPPORTED_ADVANCED_OPTIONS,
    DataSourceConfigModes,
)
from informatica.infacore.common.decorators import log_activity
from informatica.infacore.common.template_executor import execute_template
from informatica.infacore.internal.utils import (
    construct_payload,
    generate_random_name,
    get_agent_id,
    get_org_id,
    get_project_id,
    get_runtime_env_id,
    get_mapping_id,
    get_type_system,
    upsert_mct_parameter,
)

if TYPE_CHECKING:
    from informatica.infacore.datasource.connection import Connection

import informatica.infacore.common.iics_rest_api as iics_api
from informatica.infacore.dataframe.dataframe import DataFrame
from informatica.infacore.common.mapping_model import Mapping


class DataObject:
    """
    Represents the INFACore data source instance.
    You can perform operations such as config(), read(), write(), & schema() on the DataObject instances.
    """

    def __init__(self, connection: Connection, object_name: str, options: dict):
        self._connection = connection
        self._object_name = object_name
        self._options = options
        self._payload = self._initial_payload()
        self._advanced_attributes = {}

    @log_activity
    def read(self, options: dict = None):
        """
        Creates the INFACore DataFrame for the specified DataObject instance
        to extract data from the data source using the action method collect().

        Parameters
        ----------
        options : dict, optional
                A placeholder to specify properties for advanced functionalities. Default is None.

                options["data_format"], optional : dict, must have the "format" attribute. Allowed values for "format" are 'Avro', 'Parquet', 'Orc', 'Json', and 'Flat'.

                options["filter"], optional : dict, Allowed values for the filter "type" are 'simple' and 'advanced'.

                    For a simple filter, specify "condition" as the key and 2-D array (for example,  ["column","operator","value"]) as the value.

                    For an advanced filter, specify "expression" as the key and expression (str) as the value.


        Returns
        -------
        DataFrame
            The INFACore DataFrame object.

        Examples
        -------
        # Example 1 - Read data from the Oracle Customers table

        >>> import informatica.infacore as ic
        >>> orcl_do = ic.get_datasource("Oracle").get_connection("Oracle Prod").get_data_object("Customers")
        >>> i_df = orcl_do.read()


        # Example 2 - Read data from the Oracle Employee table where the employee age is greater than 30 and state is Arizona

        >>> import informatica.infacore as ic
        >>> orcl_do = ic.get_datasource("Oracle").get_connection("Oracle Prod").get_data_object("Employee")
        >>> options = {
                "filters": {
                    "type" : "simple",
                    "condition":
                        [
                            ["age","GREATER","30"],
                            ["state","EQUALS","ARIZONA"]
                        ]
                }
            }
        >>> i_df = orcl_do.read(options)

        # Example 3 - Read customer data which is in Avro format from Amazon S3

        >>> import informatica.infacore as ic
        >>> s3_do = ic.get_datasource("Amazon S3").get_connection("S3 Sandbox").get_data_object("com.amk/customer.avro")
        >>> options = {
                "data_format" : {
                    "format" : "Avro"
                }
            }
        >>> i_df = s3_do.read(options)
        """

        # MAPPING_FLOW
        src_cnx_id = self._connection._connection_id
        src_obj_name = self._object_name
        type_system = get_type_system(self._connection._connnector_type)
        function_payload = {
            "name": "read",
            "connectionId": src_cnx_id,
            "path": src_obj_name,
            "typeSystem": type_system,
        }

        # MCT_FLOW
        param_values = {"src_cnx_id": src_cnx_id, "src_obj_name": src_obj_name}
        src_param, function_payload = self._validate_and_process_read_options(
            options, param_values, function_payload
        )
        upsert_mct_parameter(self._payload["parameters"], src_param)

        cascade_fields = False
        if options:
            cascade_fields = options.get("cascade_fields", False)

        mapping_obj: Mapping = Mapping(  # MAPPING_FLOW
            None,
            function_payload,
            [generate_random_name("function")],
            None,
            cascade_fields,
        )
        return DataFrame(self, mapping_obj)

    @log_activity
    def write(self, i_df: DataFrame, options: dict = None):
        """
        Action method which takes the INFACore DataFrame and writes data to the data source.

        Parameters
        ----------
        i_df : DataFrame
            INFACore DataFrame object.

        options : dict, optional
            A placeholder to specify properties for advanced functionalities. Default is None.

            options["data_format"], optional : dict, must have the "format" attribute. Allowed values for "format" are 'Avro', 'Parquet', 'Orc', 'Json', and 'Flat'.

            options["create_target"], optional : bool, specify value as True to create a new target object with schema similar to the source object.

            options["operation_type"], optional : str, type of operation. Allowed value is 'Insert'.

        Returns
        -------
        Stats
            Returns the detailed statistics for the write operation, such as the number of rows written to the target data source.

        Examples
        --------
        # Example 1 - Write data from a Customers table in Oracle to an existing Snowflake table

        >>> import informatica.infacore as ic
        >>> orcl_do = ic.get_datasource("Oracle").get_connection("Oracle Prod").get_data_object("Customers")
        >>> snow_do = ic.get_datasource("Snowflake").get_connection("Snowflake US").get_data_object("Prod/Sales/Customers")
        >>> i_df = orcl_do.read()
        >>> stats = snow_do.write(i_df)


        # Example 2 - Write Employee data from Oracle to a new table in Snowflake

        >>> import informatica.infacore as ic
        >>> orcl_do = ic.get_datasource("Oracle").get_connection("Oracle Prod").get_data_object("Employee")
        >>> snow_do = ic.get_datasource("Snowflake").get_connection("Snowflake US").get_data_object("Prod/Sales/Employee")
        >>> i_df = orcl_do.read()
        >>> options = {
                "create_target" : True
            }
        >>> stats = snow_do.write(i_df, options)

        """
        (
            tgt_param,
            function_payload,
            field_mapping_provided,
        ) = self._validate_options_and_populate_target_param(options)

        # MCT_FLOW
        if i_df._data_object and not field_mapping_provided:
            upsert_mct_parameter(i_df._data_object._payload["parameters"], tgt_param)
            mapping_payload = i_df._data_object._payload
            source_fname = ""
            if i_df._data_object._options:
                data_object_options = i_df._data_object._options
                if data_object_options.get("delete_after_read"):
                    source_fname = data_object_options.get("file_name")
            stats = execute_template(
                mapping_payload,
                "write_stats",
                "",
                "Writing to datasource failed.",
                source_fname,
            )
            return stats

        # MAPPING_FLOW
        else:
            write_df = DataFrame(
                None,
                Mapping(
                    i_df._mapping._mapping_model,
                    function_payload,
                    [generate_random_name("function")],
                    i_df._mapping._current_id,
                ),
            )
            mapping_payload = write_df._mapping._mapping_model.serialize_model()
            stats = execute_template(
                mapping_payload,
                "write_stats",
                "",
                "Writing to datasource failed.",
                "",  # TODO
                True,
            )
            write_df._mapping._mapping_model.reinit_after_read()
            return stats

    @log_activity
    def schema(self, is_write_object: bool = False) -> list:
        """
        Returns the details of the fields for the selected DataObject instance.

        Parameters
        ----------
        is_write_object : bool, optional
            Provide this value as True to display fields for the write operation. Default value is False.

        Returns
        -------
        list
            The details of the fields for the selected DataObject instance.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_do = ic.get_datasource("Oracle").get_connection("Oracle Prod").get_data_object("Customers")
        >>> orcl_do.schema()
        """
        is_object_flat = True
        object_name = self._object_name
        if "/" in object_name:
            is_object_flat = False

        connection_name = self._connection._connection_name
        query = ""
        if is_object_flat:
            query = connection_name + "/field/" + object_name
        else:
            query = connection_name + "/fields" + "?objectName=" + object_name

        if is_write_object:
            resp = iics_api.get_target_fields(query)
        else:
            resp = iics_api.get_source_fields(query)
        fields = resp.json()
        return fields

    @log_activity
    def config(self) -> dict:
        """
        Returns the filter configuration for the DataObject.


        Returns
        -------
        dict
            Filter options: Key-value pair that contains the following information
                - Describes if the filter support is available
                - Filterable fields
                - Filter operators

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_do = ic.get_datasource("Oracle").get_connection("Oracle Prod").get_data_object("Customers")
        >>> orcl_do.config()
        """
        native_filter_config = self._get_filter_configuration()
        config = {
            "filter": native_filter_config,
        }
        return config

    @log_activity
    def get_advanced_config(
        self, mode: str = DataSourceConfigModes.BASIC.value
    ) -> dict:
        """
        Returns the advanced attributes for the DataObject.

        Parameters
        ----------
        mode : str, optional
            The value to assign to retrieve the corresponding advanced attribute details.

            You can specify the following values:
                - SIMPLIFIED: Gets only the mandatory fields, with default values wherever applicable.
                - BASIC: Gets all the advanced attribute keys as dict.
                - RAW: Gets the details of the advanced attributes such as the data type, default value, isMandatory, and other details.


        Returns
        -------
        dict
            Dictionary that contains advanced attributes for both read and write operations.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_do = ic.get_datasource("Oracle").get_connection("Oracle Prod").get_data_object("Customers")
        >>> orcl_do.get_advanced_config()
        """
        source_advanced_attributes = self._get_advanced_attributes(False, mode)
        target_advanced_attributes = self._get_advanced_attributes(True, mode)
        advanced_config = {
            "read": source_advanced_attributes,
            "write": target_advanced_attributes,
        }
        return advanced_config

    def _validate_and_process_read_options(
        self, options: dict, param_values: dict, function_payload: dict
    ):
        src_param = construct_payload("source_parameter_template.json", param_values)
        dfc = {}
        dfc_mapping = None
        if options:
            for option in options:
                if option not in SUPPORTED_READ_OPTIONS:
                    raise ValueError(
                        f"Unsupported read options - {option}, supported options are {SUPPORTED_READ_OPTIONS}"
                    )

            if "data_format" in options:
                if "format" not in options["data_format"]:
                    raise ValueError("For data format, please provide format key")

                format = options["data_format"]["format"]
                dfc = {
                    "@type": "dataFormat",
                    "formatId": format,
                    "dataFormatAttributes": {},
                }
                dfc_mapping = {
                    "dataFormat": format,
                    "dataFormatAttributes": None,
                }

            if "filters" in options:
                filter_res, filter_expression = self._validate_and_process_filters(
                    options.get("filters")
                )
                # MCT_FLOW
                src_param["extendedObject"]["filters"] = filter_res
                src_param["extendedObject"][
                    "advancedFilterExpression"
                ] = filter_expression

                # MAPPING_FLOW
                function_payload["readOptions"] = {}
                simple_filters = []
                for filter in filter_res:
                    simple_filter = {}
                    simple_filter["fieldName"] = filter.get("field")
                    simple_filter["filterValue"] = filter.get("value")
                    simple_filter["operator"] = filter.get("operator")
                    simple_filters.append(simple_filter)
                if simple_filters:
                    function_payload["readOptions"]["filterConditions"] = simple_filters
                else:
                    function_payload["readOptions"][
                        "advancedFilterCondition"
                    ] = filter_expression

            if dfc:
                src_param["dataFormat"] = dfc  # MCT_FLOW
                function_payload["dataFormatOptions"] = dfc_mapping  # MAPPING_FLOW

        if "read" in self._advanced_attributes:
            src_param["runtimeAttrs"] = self._advanced_attributes.get(
                "read"
            )  # MCT_FLOW
            function_payload["advancedOptions"] = self._advanced_attributes.get(
                "read"
            )  # MAPPING_FLOW

        return src_param, function_payload

    def _validate_options_and_populate_target_param(self, options: dict) -> dict:
        """validates the write options and create a new  target payload with the options
        Parameters
        ----------
        options : dict
            User provided options for the write operation

        Returns : dict
            Target Parameter with the write options
        """
        new_object = False
        operation_type = "Insert"
        dfc = {}
        dfc_mapping = None
        field_mapping = None
        field_mapping_provided = False
        if options:
            for option in options:
                if option not in SUPPORTED_WRITE_OPTIONS:
                    raise ValueError(
                        f"Unsupported write options - {option}, supported options are {SUPPORTED_WRITE_OPTIONS}"
                    )

            if "data_format" in options:
                if "format" not in options["data_format"]:
                    raise ValueError("For data format, please provide format key")
            if "create_target" in options:
                create_target = options["create_target"]
                if create_target:
                    new_object = True
            if "operation_type" in options:
                operation_type = options["operation_type"]
            if "data_format" in options:
                format = options["data_format"]["format"]
                dfc_attr = {}
                if format == "Flat":
                    dfc_attr = {
                        "escapeChar": "\\",
                        "rowDelimiter": "",
                        "importColumnFromFirstLine": "true",
                        "headerLineNumber": "1",
                        "maxRowsToPreview": "0",
                        "distributionColumn": "",
                        "qualifierMode": "MINIMAL",
                        "firstDataRow": "2",
                        "generateHeader": "true",
                        "delimiter": ",",
                        "qualifier": '"',
                        "targetHeader": "With Header",
                        "escapeCharacterDataRetained": "false",
                        "codePage": "UTF-8",
                        "fixedWidthMode": "false",
                    }
                dfc = {
                    "@type": "dataFormat",
                    "formatId": format,
                    "dataFormatAttributes": dfc_attr,
                }

                # MAPPING_FLOW
                dfc_mapping = {
                    "dataFormat": format,
                    "dataFormatAttributes": dfc_attr,
                }
            if "field_mapping" in options:
                if new_object:
                    raise ValueError("Field Mapping not supported for create target")
                else:
                    field_mapping = options.get("field_mapping")
                    field_mapping_provided = True

        tgt_cnx_id = self._connection._connection_id
        tgt_obj_name = self._object_name

        # MCT_FLOW
        param_values = {
            "tgt_cnx_id": tgt_cnx_id,
            "tgt_obj_name": tgt_obj_name,
            "operation_type": operation_type,
        }

        if new_object:
            target_param_template = "newobject_target_parameter_template.json"
        else:
            target_param_template = "target_parameter_template.json"

        tgt_param = construct_payload(target_param_template, param_values)
        if dfc:
            tgt_param["dataFormat"] = dfc

        if "write" in self._advanced_attributes:
            tgt_param["runtimeAttrs"] = self._advanced_attributes.get("write")

        # MAPPING_FLOW
        type_system = get_type_system(self._connection._connnector_type)
        function_payload = {
            "name": "write",
            "connectionId": tgt_cnx_id,
            "path": tgt_obj_name,
            "typeSystem": type_system,
            "writeOptions": {
                "createTarget": new_object,
                "operationType": operation_type,
            },
            "dataFormatOptions": dfc_mapping,
            "advancedOptions": self._advanced_attributes.get("write"),
            "fieldMapping": field_mapping,
        }
        return tgt_param, function_payload, field_mapping_provided

    def _get_filter_configuration(self) -> dict:
        """return filter configuration based on connector type"""

        iics_name = self._connection._connnector_type
        iics_type = self._connection._get_iics_type(iics_name)
        from informatica.infacore.datasource.datasource import (
            DataSource,
            get_compute_engine,
        )

        data_source = DataSource("", iics_name, iics_type, get_compute_engine())
        config = {
            "filter_capability_available": False,
            "filterable_fields": [],
            "supported_operators": [],
        }

        if iics_name == "CSVFile":
            return config

        if data_source._iics_type == "CCI":
            cci_meta = data_source.config("RAW")
            return self._get_cci_filter_config(cci_meta, config)
        else:
            filterable_fields = self._get_filterable_fields()
            if len(filterable_fields) > 0:
                config["filter_capability_available"] = True
                config["filterable_fields"] = filterable_fields
                config["supported_operators"] = SUPPORTED_FILTER_OPERATORS
        return config

    def _get_cci_filter_config(self, cci_meta: dict, config: dict) -> dict:
        for nmos in cci_meta.get("nmos", []):
            for operation in nmos.get("operations", []):
                if "read" in operation.get(
                    "supports", []
                ) and "filter" in operation.get("txSupport", []):
                    filter_details = operation.get("txSupport").get("filter")
                    if "projectionObject" in filter_details:
                        projectionObject = filter_details.get("projectionObject")
                        if projectionObject.get(
                            "expressionInfo"
                        ) and projectionObject.get("nativeFilterExpressionSupported"):
                            config["filter_capability_available"] = True
                            config["filterable_fields"] = self._get_filterable_fields()
                            config["supported_operators"] = projectionObject.get(
                                "expressionInfo"
                            ).get("supportedBinaryOperators")
                            return config
        return config

    def _initial_payload(self) -> dict:
        """_summary_"""
        org_id = get_org_id()
        mct_name = generate_random_name("mct")
        agent_id = get_agent_id()
        runtime_env_id = get_runtime_env_id()
        infacore_project_id = get_project_id()
        mapping_id = get_mapping_id("infacore_passthrough_id")
        param_values = {
            "org_id": org_id,
            "mct_name": mct_name,
            "agent_id": agent_id,
            "runtime_env_id": runtime_env_id,
            "infacore_project_id": infacore_project_id,
            "mapping_id": mapping_id,
        }
        payload = construct_payload("mct_root_template.json", param_values)
        return payload

    def _validate_and_process_filters(self, filters: dict):
        """validate and process the opetions' filter dictionary"""

        filter_res = []
        expression = ""
        if "type" not in filters:
            raise ValueError("Please provide mandatory filter type")

        type = filters["type"]
        if type not in SUPPORTED_FILTER_TYPES:
            raise ValueError(
                f"Please provide valid filter type. Supported types are {SUPPORTED_FILTER_TYPES}"
            )

        if type == "simple" and not filters.get("condition"):
            raise ValueError(
                "For simple filter type, please provide mandatory condition array"
            )

        elif type == "advanced" and not filters.get("expression"):
            raise ValueError(
                "For advanced filter type, please provide mandatory expression value"
            )

        filter_conf: dict = self.config()["filter"]
        if filter_conf.get("filter_capability_available"):
            if type == "simple":
                for filter in filters.get("condition"):
                    if not isinstance(filter, (list, tuple)):
                        raise ValueError("Conditions value should be type array")

                    if len(filter) >= 2:
                        valid_filter = self._validate_filter_condition(
                            filter, filter_conf
                        )
                        if valid_filter:
                            filter_res.append(valid_filter)
            else:
                expression = filters.get("expression")
        return filter_res, expression

    def _get_filterable_fields(self) -> list:
        """
        Returns the list of filterable fields from the schema
        """

        fields = self.schema()
        filterable_fields: list = []
        for field in fields:
            if field.get("isFilterable"):
                filterable_fields.append(field.get("name"))
        return filterable_fields

    def _replace_filter_operator(self, operator_name: str) -> str:
        """
        Replace the IICS metadata filter operator name to IICS expected filter operator name

        Parameters
        ----------
        operator_name : str
            Operator name as per metadata

        Returns
        -------
        str:
            Operator name as expected in native filters
        """
        values = {
            "EQUALS": "equals",
            "GREATER": "greaterThan",
            "GREATER_OR_EQUALS": "greaterOrEquals",
            "LESS": "lessThan",
            "LESS_OR_EQUALS": "lessOrEquals",
            "NOT_EQUALS": "notEquals",
            "IS_NOT_NULL": "isNotNull",
            "IS_NULL": "isNull",
            "CONTAINS": "contains",
            "STARTS_WITH": "startsWith",
            "ENDS_WITH": "endsWith",
        }
        return values.get(operator_name)

    def _validate_filter_condition(self, filter_arr, filter_conf):
        """Validate the filterable field and filter operators"""

        field = filter_arr[0]
        operator = filter_arr[1]
        if len(filter_arr) > 2:
            value = filter_arr[2]

        if field not in filter_conf.get("filterable_fields"):
            raise ValueError(
                "Specified filter field is either unavailable or not filterable"
            )

        if operator not in filter_conf.get("supported_operators"):
            raise ValueError(
                "Specified filter operator is not supported for this data object"
            )

        operator = self._replace_filter_operator(operator)
        if operator in ["isNull", "isNotNull"]:
            value = ""
        if value is not None:
            return self._create_filter_object(field, operator, value)

        return None

    def _create_filter_object(self, field: str, operator: str, value: str) -> dict:
        """Creates simple filter condition object"""

        filter_params = {
            "object_name": self._object_name,
            "field": field,
            "operator": operator,
            "value": value,
        }
        filter_object = construct_payload("filter_template.json", filter_params)
        return filter_object

    def _get_advanced_attributes(self, is_write_object: bool, mode: str) -> dict:
        """
        Construct the query params and call the corresponding IICS Api
        """
        query = "?connId=" + self._connection._connection_id + "&parameterType="
        if is_write_object:
            query = query + "TARGET"
        else:
            if self._connection._connnector_type == "CSVFile":
                query = query + "EXTENDED_SOURCE"
            else:
                query = query + "SOURCE"
        resp = iics_api.get_advanced_attributes(query)
        advanced_attributes = resp.json()
        return self._parse_advanced_attributes(advanced_attributes, mode)

    def _parse_advanced_attributes(self, advanced_attributes: dict, mode: str) -> dict:
        """
        Parse the Runtime Attributes response based on user-specified mode
        """
        config = {}
        if mode == DataSourceConfigModes.BASIC.name:
            for attribute in advanced_attributes:
                config[attribute["name"]] = ""
        elif mode == DataSourceConfigModes.RAW.name:
            config = advanced_attributes
        elif mode == DataSourceConfigModes.SIMPLIFIED.name:
            for attribute in advanced_attributes:
                name = attribute["name"]
                is_mandatory = attribute["mandatory"]
                value = attribute["defaultValue"]
                if is_mandatory:
                    config[name] = value
        return config

    def _process_advanced_attributes(self, advanced_attributes: dict) -> dict:
        """
        In IICS, for runtime attributes with boolean data type, we have to pass the values as "Yes" / "No"
        That parsing logic is implemented in this method
        """
        for attribute_name, attribute_value in advanced_attributes.items():
            if (attribute_value == True) or str(attribute_value).lower() == "true":
                advanced_attributes[attribute_name] = "YES"
            elif (attribute_value == False) or str(attribute_value).lower() == "false":
                advanced_attributes[attribute_name] = "NO"
        return advanced_attributes

    @log_activity
    def set_advanced_config(self, config: dict) -> DataObject:
        """
        Sets the advanced attributes for the data sources to leverage advanced functionalities.
        You can specify advanced attributes for both read and write operations.

        Parameters
        ----------
        config: dict
            The advanced attributes as the "key, value" pair.

        Returns
        ----------
        DataObject
            Updated DataObject with advanced configuration set.

        Example
        -------
        >>> import informatica.infacore as ic
        >>> orcl_do = ic.get_datasource("Oracle").get_connection("Oracle Prod").get_data_object("Customers")
        >>> advanced_config = { "read" : { "Post SQL" : '''UPDATE "DB1002"."Customers" SET "CUSTOMER_STATUS"='PROCESSED' ''' } }
        >>> orcl_do.set_advanced_config(advanced_config)
        >>> orcl_do.read().collect()
        """
        for keys in config.keys():
            if keys not in SUPPORTED_ADVANCED_OPTIONS:
                raise ValueError(
                    f"Unsupported advanced configuration. {SUPPORTED_ADVANCED_OPTIONS} is only supported"
                )

        if "read" in config:
            read_config = config.get("read")
            source_advanced_attributes = self._get_advanced_attributes(
                False, DataSourceConfigModes.BASIC.name
            )
            for attributes in read_config:
                if attributes not in source_advanced_attributes:
                    raise ValueError(
                        "Provided advanced configuration attributes are not supported for read operation."
                    )
            self._advanced_attributes["read"] = self._process_advanced_attributes(
                read_config
            )

        if "write" in config:
            write_config = config.get("write")
            target_advanced_attributes = self._get_advanced_attributes(
                True, DataSourceConfigModes.BASIC.name
            )
            for attributes in write_config:
                if attributes not in target_advanced_attributes:
                    raise ValueError(
                        "Provided advanced configuration attributes are not supported for write operation."
                    )
            self._advanced_attributes["write"] = self._process_advanced_attributes(
                write_config
            )

        return self
