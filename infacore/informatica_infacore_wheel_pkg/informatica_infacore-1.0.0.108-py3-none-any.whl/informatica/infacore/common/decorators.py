#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
Module capturing all decorators used in INFACore Python SDK.

For internal use only.
"""
from functools import wraps
from informatica.infacore.internal.toml_utils import (
    dump_infacore_config,
    load_infacore_config,
)
from informatica.infacore.internal.utils import (
    get_password,
    get_session_id,
    get_username,
    is_user_logged_in,
)
import informatica.infacore.internal.logger as logger
import informatica.infacore.common.iics_login_rest_api as iics_login_api


def refresh_session_id(func):
    """Refresh's session id."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        if is_user_logged_in():
            validate_resp = iics_login_api.validate_session_id(
                get_username(), get_session_id()
            )
            is_valid_token = validate_resp.json().get("isValidToken")
            if not is_valid_token:
                resp = iics_login_api.perform_login(get_username(), get_password())
                login_resp = resp.json()
                session_id = login_resp["userInfo"]["sessionId"]
                ic_config = load_infacore_config()
                ic_config["session"]["id"] = session_id
                dump_infacore_config(ic_config)
            return func(*args, **kwargs)
        else:
            raise ValueError(
                "Setup needs to be performed prior to using current method."
            )

    return wrapper


def log_activity(func):
    """Generates activity log."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        _logger = logger.get_logger(func.__name__)
        _logger.debug("INFACore :: Entering %s", func.__name__)
        out = func(*args, **kwargs)
        _logger.debug("INFACore :: Exiting %s", func.__name__)
        return out

    return wrapper
