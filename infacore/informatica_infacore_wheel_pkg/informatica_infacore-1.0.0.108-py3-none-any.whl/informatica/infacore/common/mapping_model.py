#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
from informatica.infacore.internal.utils import get_runtime_env_id
import informatica.infacore.internal.logger as logger

_logger = logger.get_logger(__name__)

class MappingModel:
    def __init__(self):
        self._functions = []
        self._links = []
        self._functions_map = {}
        self._read_function = None
        self._read_function_id = None
        self._cascade_fields = False

    def append_functions(self, function_payload, function_id):
        if len(self._functions_map) == 0:
            self._read_function = function_payload
            self._read_function_id = function_id
        if function_id not in self._functions_map:
            self._functions_map[function_id] = len(self._functions)
            self._functions.append(function_payload)

    def append_links(self, _previous_func_id, _current_func_id):
        link: dict = {
            "fromFunction": self._functions_map.get(_previous_func_id),
            "toFunction": self._functions_map.get(_current_func_id),
        }
        self._links.append(link)

    def reinit_after_read(self):
        self._functions = [self._read_function]
        self._links = []
        self._functions_map = {self._read_function_id: 0}

    def serialize_model(self):
        links = []
        if self._cascade_fields:
            links = self._construct_cascading_links()
        else:
            links = self._links

        serialized_model = {
            "functions": self._functions,
            "links": links,
            "parameters": self._construct_params(),
        }
        _logger.debug("INFACore Minimal Model is :: " + str(serialized_model))
        return serialized_model

    def _construct_params(self):
        mt_task_params = {
            "runtimeEnvId": get_runtime_env_id(),
            "mtTaskParameters": [
                {
                    "@type": "mtTaskParameter",
                    "id": -1,
                    "name": "$Dummy$",
                    "type": "dummy",
                }
            ],
        }
        return mt_task_params
    
    def _construct_cascading_links(self):
        links = []
        num_of_functions = len(self._functions)
        for i in range(num_of_functions - 1):
            for j in range(i + 1, num_of_functions):
                link = {
                    "fromFunction": i,
                    "toFunction": j,
                }
                links.append(link)
        return links


class Mapping:
    def __init__(
        self,
        _mapping_model: MappingModel,
        _function_payload: dict,
        _current_id: list,
        _previous_ids: list = None,
        _cascade_fields: bool = False
    ):
        self._mapping_model: MappingModel = _mapping_model
        self._function_payload: dict = _function_payload
        self._current_id: list = _current_id
        self._previous_ids: list = _previous_ids
        self._cascade_fields = _cascade_fields
        self._add_to_mapping_model()


    def _add_to_mapping_model(self):
        if self._mapping_model is None:
            self._mapping_model = MappingModel()
            self._mapping_model._cascade_fields = self._cascade_fields 
        if self._function_payload is not None:
            self._mapping_model.append_functions(
                self._function_payload, self._current_id[0]
            )
        if self._previous_ids is not None:
            for _previous_id in self._previous_ids:
                self._mapping_model.append_links(_previous_id, self._current_id[0])
