#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
IICS Login Rest API functions.

For internal use only.
"""
from informatica.infacore.common.constants import ApiUrl
import informatica.infacore.internal.http_client as http

# LOGIN API's
def perform_login(username: str, password: str):
    login_payload = {"username": username, "password": password}
    resp = http.post(ApiUrl.LOGIN.name, login_payload, login_api=True)
    return resp


def validate_session_id(username: str, session_id: str):
    validate_payload = {
        "@type": "validatedToken",
        "userName": username,
        "icToken": session_id,
    }
    resp = http.post(ApiUrl.VALIDATE_SESSION_ID.name, validate_payload)
    return resp
