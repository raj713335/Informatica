#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
Module containing INFACore python SDK constants.

For internal use only.
"""
import os
from enum import Enum

INFACORE_LOGO = r"""
 ___ _   _ _____ _    ____ ___  ____  _____
|_ _| \ | |  ___/ \  / ___/ _ \|  _ \| ____|
 | ||  \| | |_ / _ \| |  | | | | |_) |  _|
 | || |\  |  _/ ___ \ |__| |_| |  _ <| |___
|___|_| \_|_|/_/   \_\____\___/|_| \_\_____|
"""

DEFAULT_TIMEOUT_IN_SEC = 300
CONFIG_FILE_ENV_VAR = "INFACORE_CONFIG_FILE"
LOG_CONFIG_FILE = os.path.join(
    os.path.dirname(__file__), "..", "resources", "configs", "log_config.toml"
)
INFACORE_CONFIG_FILE = os.path.join(
    os.path.dirname(__file__), "..", "resources", "configs", "infacore_config.toml"
)
INFACORE_CONFIG_TEMPLATE_FILE = os.path.join(
    os.path.dirname(__file__),
    "..",
    "resources",
    "configs",
    "infacore_config_template.toml",
)
TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), "..", "resources", "templates")

NATIVE_DATASOURCES = [
    "Oracle",
    "SqlServer",
    "MySQL",
    "CSVFile",
    "ODBC",
    "MS_ACCESS",
    "FTP",
    "SAP",
    "WebServicesConsumer",
]

SUPPORTED_FILTER_OPERATORS = [
    "EQUALS",
    "GREATER",
    "GREATER_OR_EQUALS",
    "LESS",
    "LESS_OR_EQUALS",
    "NOT_EQUALS",
]

SUPPORTED_READ_OPTIONS = ["filters", "data_format", "cascade_fields"]

SUPPORTED_WRITE_OPTIONS = ["data_format", "create_target", "operation_type", "field_mapping"]

SUPPORTED_FILTER_TYPES = ["simple", "advanced"]

SUPPORTED_ADVANCED_OPTIONS = ["read", "write"]


class ComputeEngineType(Enum):
    """
    Infacore supported compute engines.
    """

    LOCAL = "local"
    REMOTE = "remote"


class ComputeEngineStatus(Enum):
    """
    Infacore compute engine's applicable status.
    """

    NOT_INSTALLED = "NOT INSTALLED"
    RUNNING = "RUNNING"
    STOPPED = "STOPPED"


class InfacoreDataSources(Enum):
    """
    Infacore supported data sources.
    """

    ADPATIVE_INSIGHTS = ("Adaptive Insights", "Adaptive Insights", "CTK")
    AMAZON_ATHENA = ("Amazon Athena", "Amazon Athena", "CCI")
    AMAZON_REDSHIFT = ("Amazon Redshift", "Amazon Redshift v2", "CCI")
    AMAZON_S3 = ("Amazon S3", "Amazon S3 v2", "CCI")
    AMAZON_AURORA = ("Amazon Aurora", "Aurora", "CTK")
    ARROW = ("Arrow", "Arrow", "CCI")
    COUPA = ("Coupa", "Coupa", "CTK")
    CVENT = ("Cvent", "Cvent", "CTK")
    DATABRICKS_DELTA = ("Databricks Delta", "Databricks Delta", "CCI")
    ELOQUA = ("Eloqua", "Eloqua-Bulk API", "CTK")
    FLAT_FILE = ("Flat File", "CSVFile", "NATIVE")
    FILE_IO = ("File IO", "FileIO", "CTK")
    FILE_PROCESSOR = ("File Processor", "FileProcessor", "CTK")
    GOOGLE_BIG_QUERY = ("Google BigQuery", "Google Big Query V2", "CCI")
    GOOGLE_CLOUD_SPANNER = ("Google Cloud Spanner", "Google Cloud Spanner", "CCI")
    GOOGLE_CLOUD_STORAGE = ("Google Cloud Storage", "Google Cloud Storage V2", "CCI")
    HADOOP_FILES = ("Hadoop Files", "Hadoop Files V2", "CCI")
    HIVE = ("Hive", "Hive Connector", "CCI")
    IBM_DB2 = ("IBM Db2 Warehouse on Cloud", "Db2 Warehouse on Cloud", "CCI")
    JDEE = ("JD Edwards Enterprise One", "JD Edwards Enterprise One", "CTK")
    JDBC = ("JDBC", "JDBCV2", "CCI")
    JIRA = ("Jira", "Jira", "CTK")
    KAFKA = ("Kafka", "Kafka", "CCI")
    LDAP = ("LDAP", "LDAP", "CTK")
    MAILCHIMP = ("Mailchimp", "Mailchimp", "CCI")
    MARKETO = ("Marketo", "Marketo V3", "CTK")
    MICROSOFT_ADLS = (
        "Microsoft Azure Data Lake Store",
        "Microsoft Azure Data Lake Store V3",
        "CCI",
    )
    MICROSOFT_ADLS_GEN2 = (
        "Microsoft Azure Data Lake Store Gen2",
        "Azure Data Lake Store Gen2",
        "CCI",
    )
    MICROSOFT_BLOB = (
        "Microsoft Azure Blob Storage",
        "Microsoft Azure Blob Storage V3",
        "CCI",
    )
    MICROSOFT_COSMOSDB = (
        "Microsoft Azure Cosmos DB",
        "Microsoft Azure Cosmos DB SQL API",
        "CCI",
    )
    MICROSOFT_SQL_DW = (
        "Microsoft Azure SQL Data Warehouse",
        "Microsoft Azure SQL Data Warehouse V3",
        "CCI",
    )
    MICROSOFT_CDM = ("Microsoft CDM Folders", "Microsoft CDM Folders V2", "CCI")
    MICROSOFT_365_OPERATIONS = (
        "Microsoft Dynamics 365 for Operations",
        "Microsoft Dynamics 365 for Operations",
        "CTK",
    )
    MICROSOFT_365_SALES = (
        "Microsoft Dynamics 365 for Sales",
        "Microsoft Dynamics 365 for Sales",
        "CTK",
    )
    MICROSOFT_EXCEL = ("Microsoft Excel", "Microsoft Excel", "CTK")
    MICROSOFT_FABRIC_ONELAKE = ("Microsoft Fabric OneLake", "Microsoft OneLake", "CCI")
    MONGODB = ("MongoDB", "MongoDB", "CCI")
    MRISOFTWARE = ("MRISoftware", "MRISoftware", "CCI")
    MS_ACCESS = ("MS Access", "MS_ACCESS", "NATIVE")
    MYSQL = ("MySQL", "MySQL", "NATIVE")
    ODATA = ("OData", "OData", "CTK")
    ODBC = ("ODBC", "ODBC", "NATIVE")
    ORACLE = ("Oracle", "Oracle", "NATIVE")
    ORACLE_CRM_ONDEMAND = ("Oracle CRM OnDemand", "OracleCRMOnDemand", "CTK")
    ORACLE_NETSUITE = ("Oracle NetSuite", "NetSuite", "CTK")
    ORACLE_OPENAIR = ("Oracle OpenAir", "OpenAir", "CTK")
    POSTGRESQL = ("PostgreSQL", "PostgreSQL", "CCI")
    QUICKBOOKS = ("Quickbooks", "Quickbooks V2", "CTK")
    SALESFORCE_MKT_CLOUD = (
        "Salesforce Marketing Cloud",
        "Salesforce Marketing Cloud",
        "CTK",
    )
    SAP_ADSO = ("SAP ADSO", "SAP ADSO Writer", "CCI")
    SAP_BW = ("SAP BW", "SAP BW Connector", "CTK")
    SAP_ODP = ("SAP ODP", "SAP ODP Extractor", "CCI")
    SAP_TABLE = ("SAP Table", "SAPTableConnector", "CTK")
    SERVICENOW = ("ServiceNow", "ServiceNow", "CTK")
    SHAREPOINT = ("Sharepoint", "Sharepoint", "CTK")
    SHAREPOINT_ONLINE = ("Sharepoint Online", "Sharepoint Online", "CTK")
    SHOPIFY = ("Shopify", "Shopify", "CCI")
    SNOWFLAKE = ("Snowflake", "Snowflake Cloud Data Warehouse V2", "CCI")
    STRIPE = ("Stripe", "Stripe", "CCI")
    SUCCESSFACTOR_LMS = ("SuccessFactors LMS", "SuccessFactors LMS", "CTK")
    SUCCESSFACTOR_ODATA = ("SuccessFactors OData", "SuccessFactors OData", "CTK")
    SQL_SERVER = ("SQL Server", "SqlServer", "NATIVE")
    TABLEAU = ("Tableau", "Tableau V3", "CCI")
    TWITTER = ("Twitter", "TwitterV1", "CCI")
    XACTLY = ("Xactly", "Xactly", "CTK")
    ZENDESK = ("Zendesk", "Zendesk V2", "CTK")
    ZUORA_AQUA = ("Zuora AQuA", "ZuoraAQuA", "CTK")

    def __init__(self, infacore_name, iics_name, iics_type) -> None:
        self._infacore_name = infacore_name
        self._iics_name = iics_name
        self._iics_type = iics_type

    def __str__(self) -> str:
        return f"{self._infacore_name}"


class EnvType(Enum):
    """
    Infacore supported environment types.
    """

    PROD = "prod"
    TEST = "test"


class CloudProvider(Enum):
    """
    INFACore supported list of cloud providers.
    """

    AWS = "dm"
    AZURE = "dm1"
    GCP = "dm2"


class Region(Enum):
    """
    INFACore supported list of data center regions.
    """

    NORTH_AMERICA = "us"
    EUROPE = "em"
    ASIA_PACIFIC = "ap"


class ApiUrl(Enum):
    """
    INFACore REST API URL's.
    """

    LOGIN = "/saas/public/core/v3/login"
    GET_CONNECTORS = "/saas/api/v2/connector"
    GET_CONNECTOR_DETAILS = "/saas/api/v2/connector/metadata?connectorName="
    GET_CONNECTIONS = "/saas/api/v2/connection"
    GET_CONNECTION_DETAILS = "/saas/api/v2/connection/name/"
    VALIDATE_SESSION_ID = "/saas/api/v2/user/validSessionId"
    CREATE_CONNECTION = "/saas/api/v2/connection/"
    TEST_CONNECTION = "/saas/api/v2/connection/test/"
    GET_SOURCE_OBJECTS = "/saas/api/v2/connection/source/name/"
    GET_TARGET_OBJECTS = "/saas/api/v2/connection/target/name/"
    AGENT = "/saas/api/v2/agent/name/"
    ADVANCED_ATTRIBUTES = "/saas/api/v2/mttask/runtimeAttributes/"
    AGENT_DETAILS = "/saas/api/v2/agent/details/"
    AGENT_SERVICE = "/saas/public/core/v3/agent/service"
    RUNTIME_ENV = "/saas/api/v2/runtimeEnvironment/"
    INSTALLER = "/saas/api/v2/agent/installerInfo/"
    LOOKUP = "/saas/public/core/v3/lookup"
    MAPPING = "/saas/api/v2/mapping"
    MCT = "/saas/api/v2/mttask/"
    JOB = "/saas/api/v2/job"
    ACTIVITY_LOG = "/saas/api/v2/activity/activityLog?taskId="
    PROJECTS = "/saas/public/core/v3/projects"
    USER_DETAILS = "/saas/public/core/v3/users?q=userName=="
    OBJECTS = "/saas/public/core/v3/objects?q=type=="
    FRS_DOCUMENTS = "/frs/api/v1/Documents"
    MAPPLET = "/saas/api/v2/mapplet/"
    INFACORE_FEEDBACK = "/infacorecommonapi/commonapi/v1/survey/feedback"
    INFACORE_SUGGESTION = "/infacorecommonapi/commonapi/v1/survey/suggestion"
    INFACORE_REFERRAL = "/infacorecommonapi/commonapi/v1/survey/referral"
    INFACORE_JOB = "/infacorecommonapi/api/v1/jobs"
    INFACORE_MAP_GEN = "/infacorecommonapi/mappingapi/v1/mapping"
    INFACORE_MAP_GEN_STATUS = "/infacorecommonapi/mappingapi/v1/status/"


class ApiVersion(Enum):
    """
    INFACore REST API URL's.
    """

    LOGIN = "V3"
    GET_CONNECTORS = "V2"
    GET_CONNECTOR_DETAILS = "V2"
    GET_CONNECTIONS = "V2"
    GET_CONNECTION_DETAILS = "V2"
    VALIDATE_SESSION_ID = "V2"
    CREATE_CONNECTION = "V2"
    TEST_CONNECTION = "V2"
    GET_SOURCE_OBJECTS = "V2"
    GET_TARGET_OBJECTS = "V2"
    AGENT = "V2"
    ADVANCED_ATTRIBUTES = "V2"
    AGENT_DETAILS = "V2"
    AGENT_SERVICE = "V3"
    RUNTIME_ENV = "V2"
    INSTALLER = "V2"
    LOOKUP = "V3"
    MAPPING = "V2"
    MCT = "V2"
    JOB = "V2"
    ACTIVITY_LOG = "V2"
    PROJECTS = "V3"
    USER_DETAILS = "V3"
    OBJECTS = "V3"
    FRS_DOCUMENTS = "V1"
    MAPPLET = "V2"
    INFACORE_FEEDBACK = "INFACORE_V1"
    INFACORE_SUGGESTION = "INFACORE_V1"
    INFACORE_REFERRAL = "INFACORE_V1"
    INFACORE_JOB = "INFACORE_V1"
    INFACORE_MAP_GEN = "INFACORE_V1"
    INFACORE_MAP_GEN_STATUS = "INFACORE_V1"


class SessionIdHeader(Enum):
    """
    INFACore REST API expected session-id header key.
    """

    V1 = "IDS-SESSION-ID"
    V2 = "icSessionId"
    V3 = "INFA-SESSION-ID"
    INFACORE_V1 = "IDS-SESSION-ID"


class DataObjectScopes(Enum):
    """
    Supported Dataobject Scopes
    """

    READ_ONLY = "Read Only"
    WRITE_ONLY = "Write Only"
    READ_AND_WRITE = "Read And Write"


class DataSourceConfigModes(Enum):
    """
    Supported Datasource config() modes
    """

    SIMPLIFIED = "SIMPLIFIED"
    BASIC = "BASIC"
    RAW = "RAW"

    def __str__(self):
        return str(self.value)


class DataPipelineConfigModes(Enum):
    """
    Supported DataPipeline config() modes
    """

    BASIC = "BASIC"
    RAW = "RAW"

    def __str__(self):
        return str(self.value)


class SurveyType(Enum):
    """
    INFACore survey types.
    """

    FEEDBACK = "FEEDBACK"
    SUGGESTION = "SUGGESTION"
    REFERRAL = "REFERRAL"


class StagingType(Enum):
    """
    INFACore Staging Types.
    """

    ARROW = "Arrow"
    DATABRICKS_DETLA = "Databricks Delta"
    MICROSOFT_FABRIC_ONELAKE = "Microsoft Fabric OneLake"
