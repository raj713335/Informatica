#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
IICS Rest API functions based on session id.

For internal use only.
"""

from informatica.infacore.common.constants import ApiUrl
from informatica.infacore.common.decorators import refresh_session_id
import informatica.infacore.internal.http_client as http

# ASSET API's
@refresh_session_id
def get_user_details(username: str):
    resp = http.get(ApiUrl.USER_DETAILS.name, username)
    return resp


@refresh_session_id
def perform_lookup(lookup_object: dict):
    lookup_payload = {"objects": [lookup_object]}
    resp = http.post(ApiUrl.LOOKUP.name, lookup_payload)
    return resp


@refresh_session_id
def create_project(project_name: str, project_description: str):
    project_payload = {"name": project_name, "description": project_description}
    resp = http.post(ApiUrl.PROJECTS.name, project_payload)
    return resp


@refresh_session_id
def get_mapping_details(mapping_name: str):
    additional_path = "/name/" + mapping_name
    resp = http.get(ApiUrl.MAPPING.name, additional_path)
    return resp


@refresh_session_id
def get_mapping_image(mapping_id: str):
    additional_path = "/" + mapping_id + "/image"
    resp = http.get(ApiUrl.MAPPING.name, additional_path)
    return resp


# AGENT API's
@refresh_session_id
def get_installer_info(platform: str):
    resp = http.get(ApiUrl.INSTALLER.name, platform)
    return resp


@refresh_session_id
def get_runtime_env_details(query: str = ""):
    resp = http.get(ApiUrl.RUNTIME_ENV.name, query)
    return resp


@refresh_session_id
def get_agent_details(agent_name: str):
    resp = http.get(ApiUrl.AGENT.name, agent_name)
    return resp


@refresh_session_id
def get_agent_service_details(agent_name: str):
    resp = http.get(ApiUrl.AGENT_DETAILS.name, agent_name)
    return resp


@refresh_session_id
def perform_agent_service(service_name: str, service_action: str, agent_lookup_id: str):
    start_agent_payload = {
        "serviceName": service_name,
        "serviceAction": service_action,
        "agentId": agent_lookup_id,
    }
    resp = http.post(ApiUrl.AGENT_SERVICE.name, start_agent_payload)
    return resp


# DI API's
@refresh_session_id
def get_connectors():
    resp = http.get(ApiUrl.GET_CONNECTORS.name)
    return resp


@refresh_session_id
def get_connector_details(connector_name: str):
    resp = http.get(ApiUrl.GET_CONNECTOR_DETAILS.name, connector_name)
    return resp


@refresh_session_id
def get_connections():
    resp = http.get(ApiUrl.GET_CONNECTIONS.name)
    return resp


@refresh_session_id
def get_connection_details(connection_name: str):
    resp = http.get(ApiUrl.GET_CONNECTION_DETAILS.name, connection_name)
    return resp


@refresh_session_id
def create_connection(create_connection_payload: dict):
    resp = http.post(ApiUrl.CREATE_CONNECTION.name, create_connection_payload)
    return resp


@refresh_session_id
def edit_connection(connection_id: str, edit_connection_payload: dict):
    resp = http.post(
        ApiUrl.CREATE_CONNECTION.name,
        edit_connection_payload,
        additional_path=connection_id,
        additional_headers={"Update-Mode": "PARTIAL"},
    )
    return resp


@refresh_session_id
def test_connection(connection_id: str):
    resp = http.get(ApiUrl.TEST_CONNECTION.name, connection_id)
    return resp


@refresh_session_id
def get_source_objects(query: str):
    resp = http.get(ApiUrl.GET_SOURCE_OBJECTS.name, query)
    return resp


@refresh_session_id
def get_target_objects(query: str):
    resp = http.get(ApiUrl.GET_TARGET_OBJECTS.name, query)
    return resp


@refresh_session_id
def get_source_fields(query: str):
    resp = http.get(ApiUrl.GET_SOURCE_OBJECTS.name, query)
    return resp


@refresh_session_id
def get_target_fields(query: str):
    resp = http.get(ApiUrl.GET_TARGET_OBJECTS.name, query)
    return resp


@refresh_session_id
def create_mct(create_mct_payload: dict):
    resp = http.post(ApiUrl.MCT.name, create_mct_payload)
    return resp


@refresh_session_id
def delete_mct(mct_id):
    resp = http.delete(ApiUrl.MCT.name, mct_id)
    return resp


@refresh_session_id
def run_job(task_name):
    job_payload = {"@type": "job", "taskName": task_name, "taskType": "MTT"}
    resp = http.post(ApiUrl.JOB.name, job_payload)
    return resp


@refresh_session_id
def get_job_status(task_id):
    resp = http.get(ApiUrl.ACTIVITY_LOG.name, task_id)
    return resp


@refresh_session_id
def get_advanced_attributes(query: str):
    resp = http.get(ApiUrl.ADVANCED_ATTRIBUTES.name, query)
    return resp


@refresh_session_id
def update_selections(additional_path: str, selections_payload: dict):
    resp = http.put(ApiUrl.RUNTIME_ENV.name, selections_payload, additional_path)
    return resp


@refresh_session_id
def get_mappings():
    resp = http.get(ApiUrl.MAPPING.name)
    return resp

# Mapplet API's
@refresh_session_id
def get_objects(object_type: str, query: str = None):
    resp = http.get(ApiUrl.OBJECTS.name, "'" + object_type + "'" + query)
    return resp


@refresh_session_id
def get_frs_document(document_id: str):
    resp = http.get(ApiUrl.FRS_DOCUMENTS.name, "('" + document_id + "')")
    return resp


@refresh_session_id
def get_mapplet_details(saas_mapplet_id: str):
    resp = http.get(ApiUrl.MAPPLET.name, saas_mapplet_id)
    return resp