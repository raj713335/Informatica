#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
Native datasource connection requires special handling
for each of them.

This module tackles with construction of
native datasource connection payload creation.

For internal use only.
"""


def construct_connection_payload(
    connection_type: str, input_values: dict, is_conn_config_call: bool = False
) -> dict:

    if is_conn_config_call:
        output_payload = {}
    else:
        output_payload = {
            "@type": "connection",
            "orgId": input_values["org_id"],
            "name": input_values["name"],
            "agentId": input_values["agent_id"],
            "runtimeEnvironmentId": input_values["runtime_env_id"],
        }

    populate_attributes = {
        "MySQL": _populate_mysql_attributes,
        "MSD": _populate_ms_dynamics_attributes,
        "CSVFile": _populate_csv_attributes,
        "MS_ACCESS": _populate_ms_access_attributes,
        "Oracle": _populate_oracle_attributes,
        "ODBC": _populate_odbc_attributes,
        "SqlServer": _populate_sql_server_attributes,
        "SAP": _populate_sap_attributes,
        "WebServicesConsumer": _populate_web_services_attributes,
        "Salesforce": _populate_salesforce_attributes,
    }
    return populate_attributes[connection_type](
        output_payload, input_values, is_conn_config_call
    )


def _transform_payload(
    key_value_mapping: dict,
    input_values: dict,
    output_payload: dict,
    is_conn_config_call: bool = False,
) -> dict:
    """
    Tranforms the IICS expected attribute name(as per connection payload / response) to IICS returned attribute name (as in connection config) and vice-versa

    Parameters
    ----------
    key_value_mapping : dict
        Mapping values of iics_expected_attribute_name -> iics_returned_attribute_name. Dot indictes the key at nested level
    input_values: dict
        Actual user given values or values returned from connection config method
    output_payload : dict
        Dictionary which we need to add the output attributes
    is_conn_config_call : bool
        Check the direction of mapping.
        True indicates that we need to transform iics_returned_attribute_name to iics_expected_attribute_name
        False indicates that we need to transform iics_expected_attribute_name to iics_returned_attribute_name
    """
    # check the direction of mapping
    if is_conn_config_call:
        for input_key, output_key in key_value_mapping.items():
            # If input_key has a '.' in it, it is a nested key
            if "." in input_key:
                input_keys = input_key.split(".")
                # check if the first key exists in input_values
                if input_keys[0] in input_values:
                    nested_dict = input_values.get(input_keys[0])
                    if nested_dict and input_keys[1] in nested_dict:
                        # map the nested key to the common_payload dictonary
                        output_payload[output_key] = nested_dict.get(input_keys[1])
            elif input_key in input_values:
                # map the key to the common_payload dictionary
                output_payload[output_key] = input_values.get(input_key)
    else:
        # iterate through the key_value_mapping keys and values
        for output_key, input_key in key_value_mapping.items():
            if input_key in input_values:
                if "." in output_key:
                    output_keys = output_key.split(".")
                    if not output_keys[0] in output_payload:
                        # creates nested dict
                        output_payload[output_keys[0]] = {}
                    # map the nested key to the nested dict in common_payload dictonary
                    output_payload[output_keys[0]][output_keys[1]] = input_values.get(
                        input_key
                    )
                else:
                    # map the key to the common_payload dictionary
                    output_payload[output_key] = input_values.get(input_key)
    return output_payload


def _populate_mysql_attributes(
    common_payload: dict, param_values: dict, is_conn_config_call: bool
) -> dict:
    """
    key value mapping of IICS_expected_attribute_name(as per connection payload / response) to IICS_returned_attribute_name (as in connection config)
    Dot in key indicates that expected values are in nested dict
    """
    mysql_mapping = {
        "database": "database",
        "codepage": "codePage",
        "port": "port",
        "password": "password",
        "username": "username",
        "host": "host",
        "connParams.sslca": "sslca",
        "connParams.verifyServerCertificate": "verifyServerCertificate",
        "connParams.sslcipher": "sslcipher",
        "connParams.trustCertificateKeyStorePassword": "trustCertificateKeyStorePassword",
        "connParams.enabledSSLCipherSuites": "enabledSSLCipherSuites",
        "connParams.useSSL": "useSSL",
        "connParams.clientCertificateKeyStorePassword": "clientCertificateKeyStorePassword",
        "connParams.requireSSL": "requireSSL",
        "connParams.clientCertificateKeyStoreUrl": "clientCertificateKeyStoreUrl",
        "connParams.enabledTLSProtocols": "enabledTLSProtocols",
        "connParams.SSLMODE": "SSLMODE",
        "connParams.trustCertificateKeyStoreUrl": "trustCertificateKeyStoreUrl",
        "connParams.sslkey": "sslkey",
        "connParams.sslcert": "sslcert",
    }

    if not is_conn_config_call:
        common_payload["type"] = "MySQL"

    return _transform_payload(
        mysql_mapping, param_values, common_payload, is_conn_config_call
    )


def _populate_ms_dynamics_attributes(
    common_payload: dict, param_values: dict, is_conn_config_call: bool
) -> dict:
    """
    key value mapping of IICS_expected_attribute_name(as per connection payload / response) to IICS_returned_attribute_name (as in connection config)
    Dot in key indicates that expected values are in nested dict
    """
    ms_dymanics_mappings = {
        "domain": "domain",
        "authenticationType": "msdAuthenticationType",
        "serviceUrl": "serviceUrl",
        "password": "password",
        "username": "username",
        "organizationName": "organizationName",
        "connParams.MSD_STS_URL": "msdStsUrl",
        "connParams.DOMAIN": "domain",
        "connParams.AUTHENTICATION_TYPE": "msdAuthenticationType",
        "connParams.ORGANIZATION_NAME": "organizationName",
    }
    if not is_conn_config_call:
        common_payload["type"] = "MSD"

    return _transform_payload(
        ms_dymanics_mappings, param_values, common_payload, is_conn_config_call
    )


def _populate_csv_attributes(
    common_payload: dict, param_values: dict, is_conn_config_call: bool
) -> dict:
    csv_connection_mapping = {
        "dateFormat": "dateFormat",
        "database": "dirName",
        "codepage": "codePage",
    }
    if not is_conn_config_call:
        common_payload["type"] = "CSVFile"

    return _transform_payload(
        csv_connection_mapping, param_values, common_payload, is_conn_config_call
    )


def _populate_ms_access_attributes(
    common_payload: dict, param_values: dict, is_conn_config_call: bool
) -> dict:
    ms_access_mapping = {"database": "database", "codepage": "codePage"}
    if not is_conn_config_call:
        common_payload["type"] = "MS_ACCESS"

    return _transform_payload(
        ms_access_mapping, param_values, common_payload, is_conn_config_call
    )


def _populate_oracle_attributes(
    common_payload: dict, param_values: dict, is_conn_config_call: bool
) -> dict:
    oracle_mapping = {
        "host": "host",
        "database": "database",
        "codepage": "codePage",
        "schema": "schema",
        "port": "port",
        "password": "password",
        "username": "username",
        "connParams.Connection Retry Period": "Connection Retry Period",
        "connParams.keyStorePassword": "keyStorePassword",
        "connParams.CryptoProtocolVersion": "CryptoProtocolVersion",
        "connParams.encryptionMethod": "encryptionMethod",
        "connParams.ValidateServerCertificate": "ValidateServerCertificate",
        "connParams.trustStorePassword": "trustStorePassword",
        "connParams.oracleSubType": "oracleSubType",
        "connParams.keyPassword": "keyPassword",
        "connParams.keyStore": "keyStore",
        "connParams.Metadata Advanced Connection Properties": "Metadata Advanced Connection Properties",
        "connParams.trustStore": "trustStore",
        "connParams.HostNameInCertificate": "HostNameInCertificate",
        "connParams.Run-time Advanced Connection Properties": "Run-time Advanced Connection Properties",
    }
    if not is_conn_config_call:
        common_payload["type"] = "Oracle"

    return _transform_payload(
        oracle_mapping, param_values, common_payload, is_conn_config_call
    )


def _populate_odbc_attributes(
    common_payload: dict, param_values: dict, is_conn_config_call: bool
) -> dict:
    odbc_mapping = {
        "database": "database",
        "codepage": "codePage",
        "schema": "schema",
        "password": "password",
        "username": "username",
        "connParams.odbcDriverManager": "odbcDriverManager",
        "connParams.ODBC_SUBTYPE": "odbcSubtype",
    }
    if not is_conn_config_call:
        common_payload["type"] = "ODBC"

    return _transform_payload(
        odbc_mapping, param_values, common_payload, is_conn_config_call
    )


def _populate_sql_server_attributes(
    common_payload: dict, param_values: dict, is_conn_config_call: bool
) -> dict:
    sql_server_mapping = {
        "host": "host",
        "database": "database",
        "codepage": "codePage",
        "authenticationType": "authenticationType",
        "schema": "schema",
        "type": "subType",
        "password": "password",
        "username": "username",
        "port": "port",
        "instanceName": "instanceName",
        "connParams.Run-time Advanced Connection Properties": "Run-time Advanced Connection Properties",
        "connParams.CryptoProtocolVersion": "CryptoProtocolVersion",
        "connParams.AUTHENTICATION_TYPE": "authenticationType",
        "connParams.encryptionMethod": "encryptionMethod",
        "connParams.ValidateServerCertificate": "ValidateServerCertificate",
        "connParams.trustStorePassword": "trustStorePassword",
        "connParams.domain": "domain",
        "connParams.Metadata Advanced Connection Properties": "Metadata Advanced Connection Properties",
        "connParams.trustStore": "trustStore",
        "connParams.HostNameInCertificate": "HostNameInCertificate",
    }

    return _transform_payload(
        sql_server_mapping, param_values, common_payload, is_conn_config_call
    )


def _populate_sap_attributes(
    common_payload: dict, param_values: dict, is_conn_config_call: bool
) -> dict:
    sap_mapping = {
        "database": "database",
        "codepage": "codePage",
        "clientCode": "clientCode",
        "languageCode": "languageCode",
        "type": "subType",
        "password": "password",
        "username": "username",
    }

    return _transform_payload(
        sap_mapping, param_values, common_payload, is_conn_config_call
    )


def _populate_web_services_attributes(
    common_payload: dict, param_values: dict, is_conn_config_call: bool
) -> dict:
    web_services_mapping = {
        "domain": "domain",
        "authenticationType": "authenticationType",
        "serviceUrl": "serviceUrl",
        "password": "password",
        "username": "username",
        "timeout": "timeout",
        "trustCertificatesFile": "trustCertificatesFile",
        "certificateFile": "certificateFile",
        "certificateFilePassword": "certificateFilePassword",
        "certificateFileType": "certificateFileType",
        "privateKeyFile": "privateKeyFile",
        "privateKeyPassword": "keyPassword",
        "privateKeyFileType": "keyFileType",
    }
    if not is_conn_config_call:
        common_payload["type"] = "WebServicesConsumer"

    return _transform_payload(
        web_services_mapping, param_values, common_payload, is_conn_config_call
    )


def _populate_salesforce_attributes(
    common_payload: dict, param_values: dict, is_conn_config_call: bool
) -> dict:
    salesforce_mapping = {
        "serviceUrl": "serviceUrl",
        "type": "subType",
        "password": "password",
        "username": "username",
        "securityToken": "securityToken",
        "connParams.consumer_secret": "consumer_secret",
        "connParams.USE_PROXY": "USE_PROXY",
        "connParams.consumer_key": "consumer_key",
        "connParams.refresh_token": "refresh_token",
    }

    return _transform_payload(
        salesforce_mapping, param_values, common_payload, is_conn_config_call
    )
