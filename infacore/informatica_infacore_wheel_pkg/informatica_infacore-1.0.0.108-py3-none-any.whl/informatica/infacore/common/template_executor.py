#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
Module capturing workflow for template execution.

For internal use only.
"""

import os
import time
import pyarrow as pa
from pyarrow import csv

import informatica.infacore.common.iics_rest_api as iics_api
import informatica.infacore.common.infacore_rest_api as infacore_api
from informatica.infacore.internal.utils import delete_tmp_file, get_tmp_dir
from informatica.infacore.staging.staging import Staging
import informatica.infacore.internal.logger as logger

_logger = logger.get_logger(__name__)


def execute_template(
    payload,
    mode,
    target_staging_object: Staging,
    error_message: str,
    source_staging_object: Staging = None,
    mapping_flow: bool = False,
):
    if mapping_flow:
        # MAPPING_FLOW
        mapping_id = _execute_mapping(payload)
        table = None
        try:
            while True:
                _logger.info("Job execution in progress.")
                time.sleep(30)
                resp = infacore_api.check_mapping_status(mapping_id)
                status = resp.json().get("status")
                if status == "EXECUTION_COMPLETED":
                    table = _get_action_method(mode, target_staging_object, resp)
                    _logger.info("Job execution completed.")
                    break
                elif status in ["CREATION_FAILED", "EXECUTION_FAILED"]:
                    raise ValueError(error_message + " :: " + resp.text)
        finally:
            if target_staging_object:
                if (
                    mode == "read_csv"
                ):  # If parser function is called, it will not come to staging code flow, so added a check seperately to delete this
                    delete_tmp_file(target_staging_object)
                else:
                    target_staging_object.delete()
            if source_staging_object:
                if mode == "read_csv":
                    delete_tmp_file(source_staging_object)
                else:
                    source_staging_object.delete()
        return table

    else:
        # MCT_FLOW
        mct_id, mct_name = _create_mct(payload)
        task_id = _run_job(mct_name)
        table = None
        try:
            while True:
                _logger.info("Job execution in progress.")
                time.sleep(30)
                resp = iics_api.get_job_status(task_id)
                if resp.json():
                    state = resp.json()[0]["state"]
                    if state == 1:
                        table = _get_action_method(mode, target_staging_object, resp)
                        _logger.info("Job execution completed.")
                        break
                    else:
                        raise ValueError(error_message + " :: " + resp.text)
        finally:
            if target_staging_object:
                if (
                    mode == "read_csv"
                ):  # If parser function is called, it will not come to staging code flow, so added a check seperately to delete this
                    delete_tmp_file(target_staging_object)
                else:
                    target_staging_object.delete()
            if source_staging_object:
                if mode == "read_csv":
                    delete_tmp_file(source_staging_object)
                else:
                    source_staging_object.delete()
            _delete_mct(mct_id)
        return table


def _execute_mapping(payload: dict) -> str:
    resp = infacore_api.create_mapping(payload)
    return resp.json().get("mappingID")


def _create_mct(create_mct_payload):
    resp = iics_api.create_mct(create_mct_payload)
    mct_id = resp.json()["id"]
    mct_name = resp.json()["name"]
    return mct_id, mct_name


def _delete_mct(mct_id):
    iics_api.delete_mct(mct_id)


def _run_job(task_name: str) -> str:
    resp = infacore_api.run_job(task_name)
    task_id = resp.json()["taskId"]
    return task_id


def _read_staging_file(staging_obj):
    return staging_obj.read()


def _read_csv(csv_fname: str):
    tmp_dir = get_tmp_dir()
    csv_filepath = tmp_dir + os.sep + csv_fname
    table = csv.read_csv(csv_filepath)
    return table


def _write_stats(resp):
    return resp.json()


def _get_action_method(mode, fname, resp):
    output = None
    if mode == "read_staging":
        output = _read_staging_file(fname)
    elif mode == "read_csv":
        output = _read_csv(fname)
    elif mode == "write_stats":
        output = _write_stats(resp)
    return output
