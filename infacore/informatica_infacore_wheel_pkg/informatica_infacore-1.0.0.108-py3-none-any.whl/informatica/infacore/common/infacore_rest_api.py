#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
INFACore Rest API functions based on session id.

For internal use only.
"""

from informatica.infacore.common.constants import ApiUrl
from informatica.infacore.common.decorators import refresh_session_id
import informatica.infacore.internal.http_client as http


# SURVEY API
@refresh_session_id
def create_survey(survey_url: str, survey_payload: dict):
    resp = http.post(survey_url, survey_payload)
    return resp


# JOB API
@refresh_session_id
def run_job(task_name):
    job_payload = {"taskName": task_name}
    resp = http.post(ApiUrl.INFACORE_JOB.name, job_payload)
    return resp


# MAPPING API's
@refresh_session_id
def create_mapping(payload: dict):
    resp = http.post(ApiUrl.INFACORE_MAP_GEN.name, payload)
    return resp


@refresh_session_id
def check_mapping_status(mapping_id: str):
    resp = http.get(ApiUrl.INFACORE_MAP_GEN_STATUS.name, additional_path=mapping_id)
    return resp
