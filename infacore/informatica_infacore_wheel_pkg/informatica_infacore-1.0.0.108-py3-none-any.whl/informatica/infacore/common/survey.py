#
# Copyright (c) 1993-2023 Informatica LLC. All rights reserved.
#
# This file contains material proprietary to Informatica LLC. and
# may not be copied or distributed in any form
# without the written permission of Informatica LLC.
#
"""
Module capturing functions exposed to capture end-user feedback.

For internal use only.
"""

from informatica.infacore.common.constants import ApiUrl, SurveyType
import informatica.infacore.common.infacore_rest_api as infacore_api


def create_survey(survey_payload: dict, survey_type=SurveyType.FEEDBACK):
    """
    Stores user provided survey details.

    Survey can be of following 3 types:
    1. Feedback - Overall INFACore product feedback.
    2. Suggestion - Suggestion pertaining to new data source request.
    3. Referral - Referral details to friend or coworker.
    """
    api_path = ""
    if survey_type == SurveyType.FEEDBACK:
        api_path = ApiUrl.INFACORE_FEEDBACK.name
    elif survey_type == SurveyType.SUGGESTION:
        api_path = ApiUrl.INFACORE_SUGGESTION.name
    elif survey_type == SurveyType.REFERRAL:
        api_path = ApiUrl.INFACORE_REFERRAL.name
    resp = infacore_api.create_survey(api_path, survey_payload)
    return resp
