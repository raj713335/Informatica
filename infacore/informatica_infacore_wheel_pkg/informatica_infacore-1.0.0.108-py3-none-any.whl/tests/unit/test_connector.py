import pytest
import pytest_mock
import informatica.infacore.connector as connector

# def test_get_connectors(mocker):
#     """Test connectors"""
#     mock = mocker.patch("informatica.infacore.connector")
#     expected = mock
#     output = connector.get_connectors()
#     assert output == expected

# def test_get_connector_details():
#     """Test connector details"""
#     output = connector.get_connector_details(connector_name="Oracle HCM Cloud V1")
#     hcm_details = json.loads(HCM_CONNECTOR)
#     assert output == hcm_details
