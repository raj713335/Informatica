import pytest
import informatica.infacore.session as ic
from informatica.infacore.internal.exceptions import InfacoreClientError


CONFIG = {
    "login": {
        "username": "sar-singh-test",
        "password": "Sarsingh123"
    }
}

CONFIG_NOT_PROVIDED = None
MISSING_LOGIN_KEY_CONFIG = {
    "username": "xyz123"
}
UNSUPPORTED_ENV_TYPE_CONFIG = {
    "login": {
        "env_type": "xyz",
        "username": "abc",
        "password": "Abcd@1234"
    }
}
UNSUPPORTED_CLOUD_PROVIDER_CONFIG = {
    "login": {
        "cloud_provider": "xyz",
        "username": "abc",
        "password": "Abcd@1234"
    }
}
UNSUPPORTED_REGION_CONFIG = {
    "login": {
        "region": "xyz",
        "username": "abc",
        "password": "Abcd@1234"
    }
}
UNSUPPORTED_CLOUD_PROVIDER_CONFIG = {
    "login": {
        "cloud_provider": "xyz",
        "username": "abc",
        "password": "Abcd@1234"
    }
}
NO_URL_CONFIG = {
    "login": {
        "env_type": "test",
        "username": "abc",
        "password": "Abcd@1234"
    }
}
NO_USERNAME_CONFIG = {
    "login": {
        "password": "Abcd@1234"
    }
}
NO_PASSWORD_CONFIG = {
    "login": {
        "username": "abc@xyz.com"
    }
}

CONFIG_NOT_PROVIDED_MESSAGE = "Mandatory INFACore setup config not provided."
MISSING_LOGIN_KEY_MESSAGE = "Mandatory login key missing from INFACore setup config."
UNSUPPORTED_ENV_TYPE_MESSAGE = "Unsupported value xyz provided for attribute env_type. Supported values are: ['prod', 'test']"
UNSUPPORTED_CLOUD_PROVIDER_MESSAGE = "Unsupported value xyz provided for attribute cloud_provider. Supported values are: ['dm', 'dm1', 'dm2']"
UNSUPPORTED_REGION_MESSAGE = "Unsupported value xyz provided for attribute region. Supported values are: ['us', 'em', 'ap']"
NO_URL_MESSAGE = "Mandatory login detail url not provided."
NO_USERNAME_MESSAGE = "Mandatory login detail username not provided."
NO_PASSWORD_MESSAGE = "Mandatory login detail password not provided."

# Tests
def test_setup_positive():
    """Test setup"""
    assert ic.setup(CONFIG) is None

@pytest.mark.parametrize("config, message", [
    (CONFIG_NOT_PROVIDED, CONFIG_NOT_PROVIDED_MESSAGE),
    (MISSING_LOGIN_KEY_CONFIG, MISSING_LOGIN_KEY_MESSAGE),
    (UNSUPPORTED_ENV_TYPE_CONFIG, UNSUPPORTED_ENV_TYPE_MESSAGE),
    (UNSUPPORTED_CLOUD_PROVIDER_CONFIG, UNSUPPORTED_CLOUD_PROVIDER_MESSAGE),
    (UNSUPPORTED_REGION_CONFIG, UNSUPPORTED_REGION_MESSAGE),
    (NO_URL_CONFIG, NO_URL_MESSAGE),
    (NO_USERNAME_CONFIG, NO_USERNAME_MESSAGE),
    (NO_PASSWORD_CONFIG, NO_PASSWORD_MESSAGE)
    ]
)
def test_setup_negative(config, message):
    """Test setup"""
    try:
        ic.setup(config)
    except InfacoreClientError as exc:
        assert exc.message == message
