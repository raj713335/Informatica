import json
import pytest
import informatica.infacore.datasource.connector as connector

CONNECTORS = [
    "Microsoft Azure Data Lake Store V2",
    "Box",
    "JD Edwards Enterprise One",
    "LDAP",
    "Salesforce Marketing Cloud",
    "SalesforceOAuth",
    "WSConsumer",
    "Zendesk",
    "Amazon Dynamo DB",
    "Amazon S3",
    "AmazonRedshift",
    "Aurora",
    "Azure Blob",
    "Azure DW",
    "Concur",
    "Cvent",
    "Eloqua-Bulk API",
    "FileList",
    "FileProcessor",
    "Google Big Query",
    "Google Cloud Storage",
    "GoogleAPI",
    "Hadoop",
    "JDBC",
    "JDBC_IC",
    "Jira",
    "Jira Cloud",
    "JSON Target",
    "Marketo V3",
    "MemSQL",
    "Microsoft Azure SQL Data Warehouse V2",
    "Microsoft Dynamics AX 2012_V2",
    "Microsoft Dynamics AX V3",
    "Microsoft Dynamics NAV",
    "Microsoft Excel",
    "OData",
    "Odata Consumer",
    "OpenAir",
    "OracleCRMOnDemand",
    "Quickbooks V2",
    "ReST",
    "Salesforce Analytics",
    "SAP BW BEx Query",
    "SAPTableConnector",
    "Sharepoint",
    "Sharepoint Online",
    "Snowflake Cloud Data Warehouse",
    "SuccessFactors OData",
    "SuccessFactors SOAP",
    "Tableau V2",
    "Teradata",
    "Webservices",
    "Webservices V2",
    "Workday",
    "Workday V2",
    "Xactly",
    "XML",
    "XMLTarget",
    "ZuoraAQuA",
    "SAP BW Connector",
    "SAP Bapi",
    "REST V2",
    "NetSuite",
    "Microsoft Azure Blob Storage V2",
    "Informatica Connectivity as a Service",
    "Coupa",
    "Concur V2",
    "ComplexFileProcessor",
    "Azure Data Lake",
    "BigMachines",
    "Hadoop Files",
    "Amazon S3 v2",
    "Amazon Redshift v2",
    "Advanced FTP",
    "Advanced FTPS",
    "Advanced SFTP",
    "MockConnector",
    "Oracle HCM Cloud",
    "SuccessFactors LMS",
    "Google Cloud Spanner",
    "Zuora REST V2",
    "FileIO",
    "Azure DocumentDB",
    "DynamoDB",
    "Excel",
    "Marketo REST",
    "SAP Concur",
    "Snowflake",
    "Snowflake Big Data Warehouse",
    "Google Sheets",
    "GoogleDrive",
    "Litmos",
    "Domo",
    "ServiceNow",
    "Satmetrix",
    "AnaplanV2",
    "Anaplan",
    "UltiPro",
    "Data Integration Hub",
    "Oracle CDC",
    "Cloud Integration Hub",
    "Coupa V2",
    "Microsoft Azure SQL Data Warehouse V3",
    "Microsoft Azure Blob Storage V3",
    "NetSuite V2",
    "Microsoft Dynamics 365 for Sales",
    "Microsoft Dynamics 365 for Operations",
    "Google Analytics",
    "Hive Connector",
    "Oracle Financials Cloud",
    "Netezza",
    "Zendesk V2",
    "Microsoft Azure Cosmos DB SQL API",
    "Microsoft Azure Data Lake Store V3",
    "Tableau V3",
    "B2B EDI Gateway Endpoint",
    "AS2",
    "Eloqua REST",
    "SQL Server CDC",
    "Oracle Financials Cloud V1",
    "Oracle HCM Cloud V1",
    "PostgreSQL",
    "Google Cloud Storage V2",
    "B2B EDI Gateway",
    "Power BI",
    "Oracle CRM Cloud V1",
    "MySQL CDC",
    "Db2 for zOS CDC",
    "Oracle CDC V2",
    "MongoDB",
    "CDM Folders",
    "Azure Data Lake Store Gen2",
    "Advanced FTP V2",
    "Db2 for LUW CDC",
    "Advanced FTPS V2",
    "Advanced SFTP V2",
    "Db2 for i CDC",
    "Db2 Warehouse on Cloud",
    "Google Big Query V2",
    "Hadoop Files V2",
    "Salesforce",
    "Adobe Experience Platform",
    "AribaV2",
    "Snowflake Cloud Data Warehouse V2",
    "JMS",
    "Amazon Kinesis",
    "Kafka",
    "MQTT",
    "Azure EventHub",
    "Salesforce Commerce Cloud",
    "JDBCV2",
    "Oracle Database Ingestion",
    "Azure DW Database Ingestion",
    "SAP HANA",
    "VSAM CDC",
    "Databricks Delta",
    "Microsoft Azure Synapse Analytics Database Ingestion",
    "PostgreSQL CDC",
    "Google PubSub",
    "Oracle Business Intelligence Publisher V1",
    "SAP ODP Extractor",
    "Amazon Athena",
    "OPC UA",
    "SAP ADSO Writer",
    "Business 360",
    "Db2 for i Database Ingestion",
    "OData V2 Applications",
    "Microsoft CDM Folders V2",
    "Db2 for zOS Database Ingestion",
    "SAS Connector",
    "Yellowbrick Data Warehouse",
    "Db2 for LUW Database Ingestion",
    "SAP HANA Database Ingestion",
    "Microsoft Dynamics 365 Mass Ingestion",
    "Salesforce Mass Ingestion",
    "SAP HANA CDC",
    "NetSuite Mass Ingestion",
    "Google Analytics Mass Ingestion",
    "Workday Mass Ingestion",
    "ServiceNow Mass Ingestion",
    "MongoDB Mass Ingestion",
    "Zendesk Mass Ingestion",
    "MongoDB v2",
    "Amazon DynamoDB V2",
    "Adobe Analytics Mass Ingestion",
    "Oracle Fusion Cloud Mass Ingestion",
    "VSAM",
    "SAPIQ",
    "IMS CDC",
    "Adabas CDC",
    "Db2 for zOS",
    "IMS",
    "Sequential File",
    "Adabas",
    "Db2 for i",
]

HCM_CONNECTOR = """{
	"adapterId": "com.informatica.adapter.oraclehcmcloud",
	"name": "OracleHCMCloud",
	"shortName": "OracleHCMCloud",
	"version": "1.0.0",
	"vendorId": "Informatica",
	"vendorName": "Informatica",
	"connections": [
		{
			"name": "ORACLEHCMCLOUD",
			"type": "com.informatica.adapter.oraclehcmcloud.connection.OracleHCMCloudConnectInfo",
			"displayName": "OracleHCMCloud",
			"category": {
				"id": "com.informatica.enterprise application.category",
				"displayName": "Enterprise Application",
				"description": "%category.description"
			},
			"pages": [
				{
					"name": "Connection Page",
					"description": "Connection Page",
					"groups": [
						{
							"connAttributePresentation": [
								{
									"attributeType": {
										"defaultValue": "",
										"size": 255,
										"attributeType": "STRING",
										"attributeName": "ucmURL",
										"encrypted": false,
										"validList": null,
										"deprecated": false,
										"minRangeValue": null,
										"maxRangeValue": null,
										"attributeDisplayName": "WebCenter Content URL",
										"attributeValue": null,
										"minOccursValue": 1,
										"attributeDescription": null,
										"mandatory": true,
										"maxOccursValue": 1,
										"genericAttribute": false,
										"minLength": 0,
										"maxLength": 255,
										"tagList": null,
										"dynamicAttribute": false
									},
									"hidden": false,
									"enabled": true,
									"engineProperty": {
										"defaultValue": null,
										"engineType": null,
										"hidden": false,
										"editable": false
									},
									"refreshRequired": false,
									"attributeName": "WebCenter Content URL",
									"toolTip": "Enter the URL of Oracle WebCenter Content Server."
								},
								{
									"attributeType": {
										"defaultValue": "",
										"size": 255,
										"attributeType": "STRING",
										"attributeName": "hcmURL",
										"encrypted": false,
										"validList": null,
										"deprecated": false,
										"minRangeValue": null,
										"maxRangeValue": null,
										"attributeDisplayName": "HCM URL",
										"attributeValue": null,
										"minOccursValue": 0,
										"attributeDescription": null,
										"mandatory": false,
										"maxOccursValue": 1,
										"genericAttribute": false,
										"minLength": 0,
										"maxLength": 255,
										"tagList": null,
										"dynamicAttribute": false
									},
									"hidden": false,
									"enabled": true,
									"engineProperty": {
										"defaultValue": null,
										"engineType": null,
										"hidden": false,
										"editable": false
									},
									"refreshRequired": false,
									"attributeName": "HCM URL",
									"toolTip": "Enter the URL of HCM application server."
								},
								{
									"attributeType": {
										"defaultValue": "Basic Authentication",
										"size": 255,
										"attributeType": "STRING",
										"attributeName": "authenticationType",
										"encrypted": false,
										"validList": [
											{
												"name": "Basic Authentication",
												"displayName": "Basic Authentication"
											}
										],
										"deprecated": false,
										"minRangeValue": null,
										"maxRangeValue": null,
										"attributeDisplayName": "Authentication Type",
										"attributeValue": null,
										"minOccursValue": 1,
										"attributeDescription": null,
										"mandatory": true,
										"maxOccursValue": 1,
										"genericAttribute": false,
										"minLength": 0,
										"maxLength": 255,
										"tagList": null,
										"dynamicAttribute": false
									},
									"hidden": false,
									"enabled": true,
									"engineProperty": {
										"defaultValue": null,
										"engineType": null,
										"hidden": false,
										"editable": false
									},
									"refreshRequired": false,
									"attributeName": "Authentication Type",
									"toolTip": "Select the type of user authentication to connect to the Oracle HCM Cloud application."
								},
								{
									"attributeType": {
										"defaultValue": "",
										"size": 255,
										"attributeType": "STRING",
										"attributeName": "username",
										"encrypted": false,
										"validList": null,
										"deprecated": false,
										"minRangeValue": null,
										"maxRangeValue": null,
										"attributeDisplayName": "Username",
										"attributeValue": null,
										"minOccursValue": 1,
										"attributeDescription": null,
										"mandatory": true,
										"maxOccursValue": 1,
										"genericAttribute": false,
										"minLength": 0,
										"maxLength": 255,
										"tagList": null,
										"dynamicAttribute": false
									},
									"hidden": false,
									"enabled": true,
									"engineProperty": {
										"defaultValue": null,
										"engineType": null,
										"hidden": false,
										"editable": false
									},
									"refreshRequired": false,
									"attributeName": "Username",
									"toolTip": "Enter the user name of the Oracle HCM Cloud account."
								},
								{
									"attributeType": {
										"defaultValue": "",
										"size": 255,
										"attributeType": "STRING",
										"attributeName": "password",
										"encrypted": true,
										"validList": null,
										"deprecated": false,
										"minRangeValue": null,
										"maxRangeValue": null,
										"attributeDisplayName": "Password",
										"attributeValue": null,
										"minOccursValue": 1,
										"attributeDescription": null,
										"mandatory": true,
										"maxOccursValue": 1,
										"genericAttribute": false,
										"minLength": 0,
										"maxLength": 255,
										"tagList": null,
										"dynamicAttribute": false
									},
									"hidden": false,
									"enabled": true,
									"engineProperty": {
										"defaultValue": null,
										"engineType": null,
										"hidden": false,
										"editable": false
									},
									"refreshRequired": false,
									"attributeName": "Password",
									"toolTip": "Enter the password for the Oracle HCM Cloud account."
								},
								{
									"attributeType": {
										"defaultValue": "",
										"size": 500,
										"attributeType": "STRING",
										"attributeName": "schemaDirectory",
										"encrypted": false,
										"validList": null,
										"deprecated": false,
										"minRangeValue": null,
										"maxRangeValue": null,
										"attributeDisplayName": "Schema Directory",
										"attributeValue": null,
										"minOccursValue": 1,
										"attributeDescription": null,
										"mandatory": true,
										"maxOccursValue": 1,
										"genericAttribute": false,
										"minLength": 0,
										"maxLength": 500,
										"tagList": null,
										"dynamicAttribute": false
									},
									"hidden": false,
									"enabled": true,
									"engineProperty": {
										"defaultValue": null,
										"engineType": null,
										"hidden": false,
										"editable": false
									},
									"refreshRequired": false,
									"attributeName": "Schema Directory",
									"toolTip": "Enter the directory path where HCM extract definition files are stored.You must store the HCM extract definition files in the machine on which the Secure Agent is installed."
								},
								{
									"attributeType": {
										"defaultValue": "NONE",
										"size": 255,
										"attributeType": "STRING",
										"attributeName": "encryptionMode",
										"encrypted": false,
										"validList": [
											{
												"name": "NONE",
												"displayName": "NONE"
											},
											{
												"name": "PGPUNSIGNED",
												"displayName": "PGPUNSIGNED"
											},
											{
												"name": "PGPSIGNED",
												"displayName": "PGPSIGNED"
											}
										],
										"deprecated": false,
										"minRangeValue": null,
										"maxRangeValue": null,
										"attributeDisplayName": "Encryption Mode",
										"attributeValue": null,
										"minOccursValue": 1,
										"attributeDescription": null,
										"mandatory": true,
										"maxOccursValue": 1,
										"genericAttribute": false,
										"minLength": 0,
										"maxLength": 255,
										"tagList": null,
										"dynamicAttribute": false
									},
									"hidden": false,
									"enabled": true,
									"engineProperty": {
										"defaultValue": null,
										"engineType": null,
										"hidden": false,
										"editable": false
									},
									"refreshRequired": false,
									"attributeName": "Encryption Mode",
									"toolTip": "Select the encryption type you want to use to encrypt or decrypt the data."
								},
								{
									"attributeType": {
										"defaultValue": "",
										"size": 255,
										"attributeType": "STRING",
										"attributeName": "passPhrase",
										"encrypted": true,
										"validList": null,
										"deprecated": false,
										"minRangeValue": null,
										"maxRangeValue": null,
										"attributeDisplayName": "Private Key Passphrase",
										"attributeValue": null,
										"minOccursValue": 0,
										"attributeDescription": null,
										"mandatory": false,
										"maxOccursValue": 1,
										"genericAttribute": false,
										"minLength": 0,
										"maxLength": 255,
										"tagList": null,
										"dynamicAttribute": false
									},
									"hidden": false,
									"enabled": true,
									"engineProperty": {
										"defaultValue": null,
										"engineType": null,
										"hidden": false,
										"editable": false
									},
									"refreshRequired": false,
									"attributeName": "Private Key Passphrase",
									"toolTip": "Enter the passphrase that you used to encrypt the private key."
								},
								{
									"attributeType": {
										"defaultValue": "",
										"size": 500,
										"attributeType": "STRING",
										"attributeName": "customerPrivateKeyPath",
										"encrypted": false,
										"validList": null,
										"deprecated": false,
										"minRangeValue": null,
										"maxRangeValue": null,
										"attributeDisplayName": "Private Key Path",
										"attributeValue": null,
										"minOccursValue": 0,
										"attributeDescription": null,
										"mandatory": false,
										"maxOccursValue": 1,
										"genericAttribute": false,
										"minLength": 0,
										"maxLength": 500,
										"tagList": null,
										"dynamicAttribute": false
									},
									"hidden": false,
									"enabled": true,
									"engineProperty": {
										"defaultValue": null,
										"engineType": null,
										"hidden": false,
										"editable": false
									},
									"refreshRequired": false,
									"attributeName": "Private Key Path",
									"toolTip": "Enter the file path of the private key. You must store the private key in the machine on which the Secure Agent is installed."
								},
								{
									"attributeType": {
										"defaultValue": "",
										"size": 500,
										"attributeType": "STRING",
										"attributeName": "fusionPublicKeyPath",
										"encrypted": false,
										"validList": null,
										"deprecated": false,
										"minRangeValue": null,
										"maxRangeValue": null,
										"attributeDisplayName": "Fusion Public Key Path",
										"attributeValue": null,
										"minOccursValue": 0,
										"attributeDescription": null,
										"mandatory": false,
										"maxOccursValue": 1,
										"genericAttribute": false,
										"minLength": 0,
										"maxLength": 500,
										"tagList": null,
										"dynamicAttribute": false
									},
									"hidden": false,
									"enabled": true,
									"engineProperty": {
										"defaultValue": null,
										"engineType": null,
										"hidden": false,
										"editable": false
									},
									"refreshRequired": false,
									"attributeName": "Fusion Public Key Path",
									"toolTip": "Enter the file path of the fusion public key. You must store the fusion public key in the machine on which the Secure Agent is installed."
								},
								{
									"attributeType": {
										"defaultValue": false,
										"size": 0,
										"attributeType": "BOOLEAN",
										"attributeName": "submitExtract",
										"encrypted": false,
										"validList": null,
										"deprecated": false,
										"minRangeValue": null,
										"maxRangeValue": null,
										"attributeDisplayName": "Submit Extract",
										"attributeValue": null,
										"minOccursValue": 1,
										"attributeDescription": null,
										"mandatory": true,
										"maxOccursValue": 1,
										"genericAttribute": false,
										"minLength": 0,
										"maxLength": 0,
										"tagList": null,
										"dynamicAttribute": false
									},
									"hidden": false,
									"enabled": true,
									"engineProperty": {
										"defaultValue": null,
										"engineType": null,
										"hidden": false,
										"editable": false
									},
									"refreshRequired": false,
									"attributeName": "Submit Extract",
									"toolTip": "Enable the submit extract if you want to submit the HCM extract definitions with the parameter values that you provide in the request message."
								}
							],
							"groupDescription": null,
							"groupName": "Connection Section",
							"groupTitle": "Connection Section",
							"groupToolTip": "Specify the connection details."
						}
					]
				}
			],
			"dynamic": {
				"ucmURL": {},
				"hcmURL": {},
				"authenticationType": {},
				"username": {},
				"password": {},
				"schemaDirectory": {},
				"encryptionMode": {},
				"passPhrase": {},
				"customerPrivateKeyPath": {},
				"fusionPublicKeyPath": {},
				"submitExtract": {}
			},
			"id": {
				"authenticationType": 1,
				"customerPrivateKeyPath": 2,
				"encryptionMode": 3,
				"fusionPublicKeyPath": 4,
				"hcmURL": 5,
				"passPhrase": 6,
				"password": 7,
				"schemaDirectory": 8,
				"submitExtract": 9,
				"ucmURL": 10,
				"username": 11
			},
			"dynamciAttribute": {
				"name": null,
				"dynamicPresentationStrategy": null,
				"dynamicPresentation": null,
				"initialPresentationDynamic": false
			}
		}
	],
	"nmos": [
		{
			"name": "oraclehcmcloud",
			"patternName": "OracleHCMCloudOracleHCMCloud_OracleHCMCloud_Pattern",
			"metaDataPattern": {
				"attributes": [
					"Containers",
					"Fields",
					"Procedures"
				]
			},
			"templateID": null,
			"templateName": null,
			"extensionName": null,
			"connectionName": null,
			"supportsSimpleASO": false,
			"supportsComplexASO": false,
			"suportedConnectionTypes": [
				"com.informatica.adapter.oraclehcmcloud.connection.OracleHCMCloudConnectInfo"
			],
			"nullConnectionSupported": false,
			"supportsCustomQuery": false,
			"supportsPackageImport": false,
			"supportsMultiGroup": false,
			"enableUseSequenceField": false,
			"importOption": {
				"allowMultiSelect": null,
				"displayFilterByDesc": null,
				"displayFilterByName": null,
				"displayFilterByPath": false,
				"showEntity": null,
				"showHierarchy": null,
				"showRelatedRecords": null,
				"displaySkipDescriptions": null
			},
			"attributes": {
				"record": [],
				"field": []
			},
			"operations": [
				{
					"name": "OracleHCMCloudCall",
					"interactionPattern": "Connections",
					"supports": [
						"call"
					],
					"txSupport": {
						"dataformatters": {
							"projectionObject": {
								"dataTypes": [],
								"supportedFormat": []
							}
						}
					},
					"supportedEngineTypes": [],
					"enableEngineSpecificOperation": false,
					"enableUpdateStrategySupport": false,
					"multiSelectionSupported": false,
					"attributes": {
						"call": []
					},
					"dynamicAttribute": null,
					"partitionInfo": null
				}
			],
			"dataFormatSupport": {
				"dataFormats": [],
				"dataTypes": []
			},
			"createTarget": {
				"supportsCreate": false,
				"supportsUpdate": false,
				"supportsDelete": false,
				"overriddenOptions": [],
				"continueOnError": false,
				"displayDropAndCreate": false,
				"displayUpdateElseCreate": false,
				"createIfNotExist": false,
				"customOptions": []
			},
			"copyTaskInfos": [],
			"relationshipInfos": [],
			"nmoSubTypes": [],
			"metadataPatternName": "OracleHCMCloudOracleHCMCloud_OracleHCMCloud_Pattern"
		}
	],
	"meterInfo": null
}"""

def test_get_connectors():
    """Test connectors"""
    output = connector.get_connectors()
    print(output)
    assert output == CONNECTORS

def test_get_connector_details():
    """Test connector details"""
    output = connector.get_connector_details(connector_name="Oracle HCM Cloud V1")
    hcm_details = json.loads(HCM_CONNECTOR)
    assert output == hcm_details
