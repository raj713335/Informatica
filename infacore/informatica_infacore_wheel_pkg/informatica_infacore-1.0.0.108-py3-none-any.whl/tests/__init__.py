#
# Copyright (c) 1992-2022 Informatica Inc. All rights reserved.
#
# This file contains material proprietary to Informatica Inc. and
# may not be copied or distributed in any form
# without the written permission of Informatica Inc.
#
